#!/bin/bash

# Define variables
IMAGE="gauravp31/api-backend"
VERSION="v1.0.31" # Update this to match the pushed version
ENV_FILE="/home/ec2-user/.env"
PORT=80

echo "Pulling Docker image: $IMAGE:$VERSION"
docker pull $IMAGE:$VERSION

# Stop and remove any container using port $PORT
echo "Finding and stopping containers using port $PORT..."
EXISTING_CONTAINER=$(docker ps --filter "publish=$PORT" --format "{{.ID}}")

if [ -n "$EXISTING_CONTAINER" ]; then
  echo "Stopping container with ID $EXISTING_CONTAINER"
  docker stop $EXISTING_CONTAINER
  docker rm $EXISTING_CONTAINER
else
  echo "No existing container using port $PORT"
fi

echo "Checking for existing container with name 'api-backend'..."
CONTAINER_BY_NAME=$(docker ps -aq --filter "name=api-backend")
if [ -n "$CONTAINER_BY_NAME" ]; then
  echo "Removing container with name 'api-backend'"
  docker rm -f $CONTAINER_BY_NAME
fi

# Remove old images related to this app, keeping only the current version
echo "Cleaning up old images for $IMAGE..."
OLD_IMAGES=$(docker images "$IMAGE" --format "{{.ID}} {{.Tag}}" | grep -v "$VERSION" | awk '{print $1}')

if [ -n "$OLD_IMAGES" ]; then
  echo "Deleting old images..."
  echo "$OLD_IMAGES" | xargs docker rmi -f
else
  echo "No old images to delete."
fi

# Run the new container
echo "Running new container..."
docker run -d --env-file $ENV_FILE -p $PORT:3000 --name api-backend $IMAGE:$VERSION

# Display running containers
echo "Deployment complete. Running containers:"
docker ps
