
CREATE TABLE nautica_backend.accounts (
  id SERIAL PRIMARY KEY,
  shortcode varchar(15) NOT NULL,
  name varchar(255) NOT NULL,
  type varchar(20) NOT NULL,
  parent varchar(20) DEFAULT NULL,
  hpath varchar(100) NOT NULL,
  relationship varchar(100) DEFAULT NULL,
  oneDriveId varchar(255) DEFAULT NULL
);

CREATE TABLE nautica_backend.account_roles (
  id SERIAL PRIMARY KEY,
  accountId int,
  roles varchar(50) NOT NULL UNIQUE,
  description varchar(255) NOT NULL,
  FOREIGN KEY (accountId) REFERENCES nautica_backend.accounts (id)
);

CREATE TABLE nautica_backend.account_users (
  id SERIAL PRIMARY KEY,
  accountId int,
  userIdEmail varchar(100) NOT NULL UNIQUE,
  roleId int,
  name varchar(255) NOT NULL,
  passwordHash bytea NOT NULL,
  status smallint NOT NULL DEFAULT 1,
  updatedDate timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (accountId) REFERENCES nautica_backend.accounts (id),
  FOREIGN KEY (roleId) REFERENCES nautica_backend.account_roles (id)
);

CREATE TABLE nautica_backend.certificate_category (
  id SERIAL PRIMARY KEY,
  name varchar(255) NOT NULL
);


CREATE TABLE nautica_backend.certificates (
  id SERIAL PRIMARY KEY,
  vesselFilter varchar(100) DEFAULT NULL,
  adminSlNo varchar(20) DEFAULT NULL,
  vesselCode varchar(20) DEFAULT NULL,
  vesselName varchar(100) DEFAULT NULL,
  certificate varchar(255) DEFAULT NULL,
  certificateType varchar(50) DEFAULT NULL,
  isVesselCertificate smallint DEFAULT NULL,
  certificateCategory varchar(50) DEFAULT NULL,
  certificateNo varchar(255) DEFAULT NULL,
  status varchar(50) DEFAULT NULL,
  workflowStatus varchar(50) DEFAULT NULL,
  isSurveyLinked smallint DEFAULT NULL,
  dueStatus varchar(50) DEFAULT NULL,
  surveyedOn date DEFAULT NULL,
  addedOn timestamp DEFAULT NULL,
  addedBy varchar(100) DEFAULT NULL,
  lastModifiedOn timestamp DEFAULT NULL,
  lastModifiedBy varchar(100) DEFAULT NULL,
  expiryDate date DEFAULT NULL,
  extendedDate date DEFAULT NULL,
  fileLocation varchar(255) DEFAULT NULL,
  alertTolerance numeric(10,2) DEFAULT NULL,
  comments text,
  vesselId int DEFAULT NULL,
  renewalProcessStartDate date DEFAULT NULL,
  renewalProcessStartedOn date DEFAULT NULL,
  statusDate date DEFAULT NULL,
  history text,
  portOfInspection varchar(255) DEFAULT NULL,
  groupName1 varchar(255) DEFAULT NULL,
  groupName2 varchar(255) DEFAULT NULL,
  FOREIGN KEY (vesselId) REFERENCES nautica_backend.accounts (id)
);

CREATE TABLE nautica_backend.error_logs (
  id SERIAL PRIMARY KEY,
  timestamp timestamp NOT NULL,
  path varchar(255) NOT NULL,
  errorMessage text NOT NULL,
  stackTrace text NOT NULL
);


CREATE TABLE nautica_backend.ref_parts_action (
  id SERIAL PRIMARY KEY,
  accountId int DEFAULT NULL,
  manufacturer varchar(255) DEFAULT NULL,
  partId varchar(25) DEFAULT NULL,
  partName varchar(255) DEFAULT NULL,
  cat2 varchar(255) DEFAULT NULL,
  cat3 varchar(255) DEFAULT NULL,
  cat4 varchar(255) DEFAULT NULL,
  maxRunHoursToService int DEFAULT 0,
  maxXServicePeriods varchar(15) DEFAULT NULL,
  toleranceLevel numeric(10,2) DEFAULT NULL,
  collectRT smallint DEFAULT NULL,
  collectFreq varchar(20) DEFAULT NULL,
  inputType varchar(25) DEFAULT 'RT',
  critical varchar(1) DEFAULT '',
  FOREIGN KEY (accountId) REFERENCES nautica_backend.accounts (id)
);

CREATE TABLE nautica_backend.ship_main_parts (
  id SERIAL PRIMARY KEY,
  accountId int NOT NULL,
  mainPart varchar(255) DEFAULT NULL,
  mapsTo varchar(255) DEFAULT NULL,
  FOREIGN KEY (accountId) REFERENCES nautica_backend.accounts (id)
);

CREATE TABLE nautica_backend.ship_parts_action (
  id SERIAL PRIMARY KEY,
  sequenceNo int DEFAULT NULL,
  accountId int DEFAULT NULL,
  refPartsActionId int DEFAULT NULL,
  shipMainPartId int DEFAULT NULL,
  maxRunHoursToService int DEFAULT 0,
  maxXServicePeriods varchar(15) DEFAULT NULL,
  collectRT smallint DEFAULT NULL,
  collectFreq varchar(20) DEFAULT NULL,
  critical varchar(1) DEFAULT '',
  toleranceLevel numeric(10,2) DEFAULT NULL,
  lifeTimeRT numeric(16,2) DEFAULT NULL,
  rtSinceLastService numeric(16,2) DEFAULT NULL,
  lastRTUpdatedOn timestamp DEFAULT NULL,
  lastServiceDate date DEFAULT NULL,
  nextServiceDate date DEFAULT NULL,
  rtCurrentPeriod numeric(16,2) DEFAULT NULL,
  currentPeriodFrom date DEFAULT NULL,
  currentPeriodTo date DEFAULT NULL,
  responsibleRank varchar(16) DEFAULT NULL,
  FOREIGN KEY (accountId) REFERENCES nautica_backend.accounts (id),
  FOREIGN KEY (refPartsActionId) REFERENCES nautica_backend.ref_parts_action (id),
  FOREIGN KEY (shipMainPartId) REFERENCES nautica_backend.ship_main_parts (id)
);



CREATE TABLE nautica_backend.running_hours_log (
  id SERIAL PRIMARY KEY,
  vesselId int DEFAULT NULL,
  spaId int NOT NULL,
  fromDate date DEFAULT NULL,
  toDate date DEFAULT NULL,
  dueDate date DEFAULT NULL,
  currentRHReading numeric(20,2) DEFAULT NULL,
  currentRHReadingDate timestamp DEFAULT NULL,
  currentPeriodRH numeric(20,2) DEFAULT NULL,
  previousRHReading numeric(20,2) DEFAULT NULL,
  previousRHReadingDate timestamp DEFAULT NULL,
  status varchar(20) NOT NULL CHECK (status IN ('New', 'Pending', 'Saved', 'Submitted', 'Cancelled')),
  validated smallint NOT NULL DEFAULT 0,
  comments varchar(500) DEFAULT NULL,
  savedBy int DEFAULT NULL,
  savedOn timestamp DEFAULT NULL,
  submittedBy int DEFAULT NULL,
  submittedOn timestamp DEFAULT NULL,
  FOREIGN KEY (vesselId) REFERENCES nautica_backend.accounts (id),
  FOREIGN KEY (spaId) REFERENCES nautica_backend.ship_parts_action (id)
);

CREATE TABLE nautica_backend.ship_certificates_statistics (
  id SERIAL PRIMARY KEY,
  vesselId int NOT NULL,
  lastUpdatedOn timestamp NOT NULL,
  overdue0to1Week int NOT NULL,
  overdue1to4Week int NOT NULL,
  overdue4PlusWeek int NOT NULL,
  FOREIGN KEY (vesselId) REFERENCES nautica_backend.accounts (id)
);


CREATE TABLE nautica_backend.ship_runhours_statistics (
  id SERIAL PRIMARY KEY,
  vesselId int NOT NULL,
  lastUpdatedOn timestamp NOT NULL,
  overdue0to1Week int NOT NULL,
  overdue1to4Week int NOT NULL,
  overdue4PlusWeek int NOT NULL,
  FOREIGN KEY (vesselId) REFERENCES nautica_backend.accounts (id)
);


CREATE TABLE nautica_backend.ship_statistics (
  id SERIAL PRIMARY KEY,
  vesselId int NOT NULL,
  lastUpdatedOn timestamp NOT NULL,
  overdue0to1Week int NOT NULL,
  overdue1to4Week int NOT NULL,
  overdue4PlusWeek int NOT NULL,
  due0to1Week int NOT NULL,
  due1to4Week int NOT NULL,
  due4PlusWeek int NOT NULL,
  FOREIGN KEY (vesselId) REFERENCES nautica_backend.accounts (id)
);

CREATE TABLE nautica_backend.ship_work_order (
  id SERIAL PRIMARY KEY,
  spaId int DEFAULT NULL,
  dueDate date DEFAULT NULL,
  scheduledDate date DEFAULT NULL,
  runHrsAtService numeric(20,2) DEFAULT NULL,
  maxRHPassed smallint NOT NULL DEFAULT 0,
  alert smallint NOT NULL DEFAULT 0,
  alertCreatedOn timestamp DEFAULT NULL,
  status varchar(10) DEFAULT NULL CHECK (status IN ('Open', 'Closed')),
  workFlowStatus varchar(100) DEFAULT NULL,
  assignedToRank varchar(20) DEFAULT NULL,
  details text,
  ohDate timestamp DEFAULT NULL,
  rhAtOH numeric(20,2) DEFAULT NULL,
  hoursWorked numeric(10,2) DEFAULT NULL,
  workerCount int DEFAULT NULL,
  conditionBeforeOH varchar(100) DEFAULT NULL,
  errorState smallint NOT NULL DEFAULT 0,
  FOREIGN KEY (spaId) REFERENCES nautica_backend.ship_parts_action (id)
);

CREATE TABLE nautica_backend.work_order_errors (
  id SERIAL PRIMARY KEY,
  workOrderId int DEFAULT NULL,
  details text,
  createdOn date DEFAULT NULL,
  FOREIGN KEY (workOrderId) REFERENCES nautica_backend.ship_work_order (id)
);



