INSERT INTO aquanova.user_ranks (code, description) VALUES
('2E', '2ND ENGINEER'),
('3E', '3RD ENGINEER'),
('4E', '4TH ENGINEER'),
('CE', 'CHIEF ENGINEER'),
('EE', 'ELECT ENGINEER'),
('GE', 'GAS ENGINEER'),
('3O', '3RD OFFICER'),
('2O', '2ND OFFICER'),
('SO', 'SAFETY OFFICER'),
('CO', 'CHIEF OFFICER'),
('M', 'MASTER');