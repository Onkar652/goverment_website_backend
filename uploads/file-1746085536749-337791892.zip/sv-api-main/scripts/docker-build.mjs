import { existsSync, writeFileSync, readFileSync } from 'node:fs';
import { execSync } from 'node:child_process';
import dotenv from 'dotenv';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from .env
dotenv.config();

// Resolve the path to version.txt at the root level
const versionFile = path.resolve(__dirname, '../version.txt');
const repoName = 'api-backend';
const imageName = `gauravp31/${repoName}`;

// Function to run shell commands
const runCommand = (cmd) => {
  try {
    console.log(`Running: ${cmd}`);
    const output = execSync(cmd, { stdio: 'inherit' });
    return output;
  } catch (error) {
    console.error(`Command failed: ${cmd}`);
    console.error(`Error: ${error}`);
    process.exit(1);
  }
};

// Get or increment the version
const getVersion = () => {
  let version = 'v1.0.0';
  if (existsSync(versionFile)) {
    const currentVersion = readFileSync(versionFile, 'utf-8').trim();
    const [major, minor, patch] = currentVersion
      .replace('v', '')
      .split('.')
      .map(Number);
    version = `v${major}.${minor}.${patch + 1}`;
  }
  writeFileSync(versionFile, version);
  return version;
};

// Main function
const main = () => {
  const version = getVersion();
  console.log(`Building and pushing Docker image with version: ${version}`);

  // Docker login
  //   console.log('Logging into Docker...');
  //   runCommand(
  //     `echo "${dockerPassword}" | docker login -u "${dockerUsername}" --password-stdin`,
  //   );

  console.log('Docker login successful.');

  // Build the Docker image
  console.log('Building Docker image...');
  runCommand(`docker build -t ${imageName}:${version} .`);
  console.log(`Docker image ${imageName}:${version} built successfully.`);

  // Push the Docker image
  console.log('Pushing Docker image...');
  runCommand(`docker push ${imageName}:${version}`);
  console.log(`Docker image ${imageName}:${version} pushed successfully!`);
};

main();
