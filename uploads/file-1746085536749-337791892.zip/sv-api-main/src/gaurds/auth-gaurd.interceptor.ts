import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Observable } from 'rxjs';

@Injectable()
export class AuthAuditInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const request = context.switchToHttp().getRequest();

    if (request.user && ['POST', 'PUT', 'PATCH'].includes(request.method)) {
      request.body = {
        ...request.body,
        updatedOn: new Date(),
        updatedBy: request.user.sub,
      };
    }
    console.log('Request after modification:', request.body);
    return next.handle();
  }
}
// 9389e124-cc33-4694-bf6d-0974b9afba67