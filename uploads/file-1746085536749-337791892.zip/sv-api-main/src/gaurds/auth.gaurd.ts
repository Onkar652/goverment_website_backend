import {
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
  Injectable,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtPayload } from './auth.interface';
import { Request } from 'express';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private jwtService: JwtService,
    private reflector: Reflector,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const authGuardEnabled = process.env.AUTH_GUARD_KEY === 'true';

    if (!authGuardEnabled) {
      return true;
    }

    // const authEnabled = this.reflector.getAllAndOverride<boolean>(
    //   AUTH_GUARD_KEY,
    //   [context.getHandler(), context.getClass()],
    // );

    // if (authEnabled === false) return true;

    const request = context.switchToHttp().getRequest();
    if (
      request.originalUrl === '/api/auth/login' ||
      request.originalUrl === '/api/auth/register'
    ) {
      return true;
    }
    console.log('Before', request.user);
    const token = this.extractTokenFromHeader(request);

    if (!token) {
      throw new UnauthorizedException('Token not provided.');
    }

    try {
      const payload = await this.jwtService.verifyAsync<JwtPayload>(token);
      request.user = payload;
      console.log('After', request.user);
    } catch {
      throw new UnauthorizedException('Invalid or expired token.');
    }

    return true;
  }

  private extractTokenFromHeader(request: Request): string | undefined {
    const [type, token] = request.headers.authorization?.split(' ') ?? [];

    return type === 'Bearer' ? token : undefined;
  }
}
