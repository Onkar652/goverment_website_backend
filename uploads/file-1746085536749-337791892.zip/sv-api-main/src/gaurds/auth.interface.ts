export interface JwtPayload {
  email: string;
  role: Roles;
  id: string;
}

export enum Roles {
  ADMIN = 'admin',
  USER = 'user',
}
