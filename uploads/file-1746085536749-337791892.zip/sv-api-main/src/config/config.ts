export const RankMapping = {
  '2ND ENGINEER': '2E',
  '3RD ENGINEER': '3E',
  '4TH ENGINEER': '4E',
  'CHIEF ENGINEER': 'CE',
  'ELECT ENGINEER': 'EE',
  'GAS ENGINEER': 'GE',
  '3RD OFFICER': '3O',
  '2ND OFFICER': '2O',
  'SAFETY OFFICER': 'SO',
  'CHIEF OFFICER': 'CO',
  MASTER: 'M',
};
