import { DynamicModule } from '@nestjs/common';
import { TypeOrmModule, TypeOrmModuleOptions } from '@nestjs/typeorm';
import { resolve } from 'path';

export const databaseProvider = (): DynamicModule => {
  console.log('Initiaalizing datasource');

  const options: TypeOrmModuleOptions = {
    type: 'postgres',
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT),
    password: process.env.DB_PASSWORD,
    username: process.env.DB_USERNAME,
    database: process.env.DB_NAME,
    schema: process.env.DB_SCHEMA,
    entities: [resolve(__dirname, '..', 'entities', '**/*.entity{.ts,.js}')],
    synchronize: process.env.DB_SYNC === 'true',
    logging: ['log', 'error', 'warn'],
    ssl: process.env.DB_SSL === 'true',
    extra:
      process.env.DB_SSL === 'true'
        ? {
            ssl: {
              rejectUnauthorized:
                process.env.DB_SSL__REJECT_UNAUTHORIZED === 'true',
            },
          }
        : {},
  };

  return TypeOrmModule.forRoot(options);
};
