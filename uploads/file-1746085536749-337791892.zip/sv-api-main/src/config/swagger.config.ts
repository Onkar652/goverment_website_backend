import { INestApplication } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

const swaggerConfig = new DocumentBuilder()
  .setTitle('Backend Server')
  .setDescription('This is backend server')
  .setBasePath(process.env.BASE_PATH || '/api')
  .setVersion('1.0.0')
  .build();

export function initSwagger(app: INestApplication) {
  const document = SwaggerModule.createDocument(app, swaggerConfig);
  SwaggerModule.setup('api/api-docs', app, document);
}
