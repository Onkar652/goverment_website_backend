import { SetMetadata } from '@nestjs/common';

export const AUTH_GUARD_KEY = 'auth_guard_enabled';

export const AuthGuard = (enable: boolean) =>
  SetMetadata(AUTH_GUARD_KEY, enable);
