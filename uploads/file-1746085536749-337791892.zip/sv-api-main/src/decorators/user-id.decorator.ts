import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export interface Request {
  userId: string;
}
export const UserId = createParamDecorator((_, ctx: ExecutionContext) => {
  const request: Request = ctx.switchToHttp().getRequest<Request>();

  return request.userId;
});
