import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { ScheduleModule } from '@nestjs/schedule';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { databaseProvider } from './config/database.provider';
import { AuthGuard } from './gaurds/auth.gaurd';
import { AuthModule } from './modules/auth/auth.module';
import { BestPracticeReportModule } from './modules/best-practise-report/base-practise-report.module';
import { BunkerReportModule } from './modules/bunker-report/bunker-report.module';
import { CertificationsModule } from './modules/certifications/certifications.module';
import { CorrectiveActionModule } from './modules/corrective-action/corrective-actions.module';
import { FileStorageModule } from './modules/file-storage/file-storage.module';
import { LarpReportModule } from './modules/larp-report/larp-report.module';
import { MasterDataModule } from './modules/master-data/master-data.module';
import { NearMissReportModule } from './modules/near-miss-report/near-miss-reports.module';
import { PositionReportsModule } from './modules/position-reports/position-reports.module';
import { PreventiveActionModule } from './modules/preventive-action/preventive-actions.module';
import { RequisitionModule } from './modules/requisition/requisition.module';
import { RunningHoursModule } from './modules/running-hours/running-hours.module';
import { ShipComponentsModule } from './modules/ship-components/ship-components.module';
import { ShipsModule } from './modules/ships/ships.module';
import { SparesModule } from './modules/spares/spares.module';
import { TankConfigModule } from './modules/tank-config/tank-config.module';
import { AuthAuditInterceptor } from './gaurds/auth.interceptor';
import { VoyageModule } from './modules/voyage/voyage.module';
import { WorkOrdersModule } from './modules/work-orders/work-orders.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    databaseProvider(),
    AuthModule,
    WorkOrdersModule,
    ShipsModule,
    RunningHoursModule,
    ShipComponentsModule,
    LarpReportModule,
    CertificationsModule,
    SparesModule,
    ScheduleModule.forRoot(),
    FileStorageModule,
    RequisitionModule,
    BestPracticeReportModule,
    NearMissReportModule,
    MasterDataModule,
    PreventiveActionModule,
    CorrectiveActionModule,
    VoyageModule,
    TankConfigModule,
    PositionReportsModule,
    BunkerReportModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_GUARD,
      useClass: AuthGuard,
    },
    {
      provide: APP_INTERCEPTOR,
      useClass: AuthAuditInterceptor,
    },
  ],
})
export class AppModule {}
