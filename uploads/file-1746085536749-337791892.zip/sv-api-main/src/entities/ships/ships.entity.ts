import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { BunkerReportEntity } from '../bunker-reports/bunker-reports.entity';
import { CertificationEntity } from '../certifications/certification.entity';
import { Client } from '../client/client.entity';
import { SpareEntity } from '../inventory/spares.entity';
import { IncidentActivityEntity } from '../master-configs/incident-activity.entity';
import { LocationOnboardEntity } from '../master-configs/location-onboard.entity';
import { VesselActivityEntity } from '../master-configs/vessel-activity.entity';
import { VesselLocationEntity } from '../master-configs/vessel-location.entity';
import { ActiveEventReportEntity } from '../postion-book-reports/active-event-reports.entity';
import { PositionBookReportEntity } from '../postion-book-reports/postion-report.entity';
import { BasePracticeReportEntity } from '../qhse-reports/base-practice.entity';
import { CorrectiveActionEntity } from '../qhse-reports/corrective-measure.entity';
import { LarpReportEntity } from '../qhse-reports/larp-report.entity';
import { PreventiveActionEntity } from '../qhse-reports/preventive-measure.entity';
import { NearMissReportEntity } from '../qhse-reports/near-miss-report.entity';
import { RequisitionEntity } from '../requisitions/requisition.entity';
import { WorkOrder } from '../shipActions/work-order.entity';
import { WorkOrderConfig } from '../shipActions/workOrder-config.entity';
import { MainPart } from '../shipParts/main-parts.entity';
import { TankConfigurationEntity } from '../tank-config/tank-config.entity';
import { UserDetails } from '../users/user-details.entity';
import { VoyageEntity } from '../voyage/voyage.entity';

@Entity()
export class Ship {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  code: string;

  @ManyToOne(() => Client, (client) => client.ships)
  @JoinColumn({ name: 'client_id' })
  client: Client;

  @OneToMany(() => VoyageEntity, (voyage) => voyage.ship)
  voyages: VoyageEntity[];

  @OneToMany(() => NearMissReportEntity, (report) => report.ship)
  reports: NearMissReportEntity[];

  @Column()
  name: string;

  @Column({ default: false })
  disabled: boolean;

  @OneToMany(() => UserDetails, (userDetails) => userDetails.ship)
  userDetails: UserDetails[];

  @OneToMany(() => MainPart, (mainPart) => mainPart.ship)
  mainParts: MainPart[];

  @OneToMany(() => WorkOrder, (workOrder) => workOrder.ship)
  workOrders: WorkOrder[];

  @OneToMany(() => CertificationEntity, (certificate) => certificate.ship)
  certificates: CertificationEntity[];

  @OneToMany(() => SpareEntity, (certificate) => certificate.ship)
  spares: SpareEntity[];

  @OneToMany(() => RequisitionEntity, (requisition) => requisition.ship)
  requisitions: RequisitionEntity[];

  @OneToMany(() => WorkOrderConfig, (config) => config.ship)
  workOrderConfigs: WorkOrderConfig[];

  @OneToMany(() => TankConfigurationEntity, (tank) => tank.ship)
  tanks: TankConfigurationEntity[];

  @OneToMany(() => VesselLocationEntity, (location) => location.ship)
  vesselLocations: VesselLocationEntity[];

  @OneToMany(() => VesselActivityEntity, (activity) => activity.ship)
  vesselActivity: VesselActivityEntity[];

  @ManyToOne(() => LarpReportEntity, (larpReport) => larpReport.ship)
  larpReport: LarpReportEntity;

  @OneToMany(() => BasePracticeReportEntity, (baseReport) => baseReport.ship)
  baseReports?: BasePracticeReportEntity[];

  @OneToMany(() => LocationOnboardEntity, (location) => location.ship)
  locationOnBoard: LocationOnboardEntity[];

  @OneToMany(() => IncidentActivityEntity, (incident) => incident.ship)
  incidentActivities: IncidentActivityEntity[];

  @OneToMany(
    () => PositionBookReportEntity,
    (positionBookReport) => positionBookReport.ship,
  )
  positionBookReports: PositionBookReportEntity[];

  @OneToMany(
    () => CorrectiveActionEntity,
    (correctiveActions) => correctiveActions.ship,
  )
  correctiveActions?: CorrectiveActionEntity;

  @OneToMany(
    () => PreventiveActionEntity,
    (preventiveAction) => preventiveAction.ship,
  )
  preventiveAction?: PreventiveActionEntity;

  @OneToMany(() => BunkerReportEntity, (bunkerReport) => bunkerReport.ship)
  bunkerReports: BunkerReportEntity;

  @OneToMany(
    () => ActiveEventReportEntity,
    (activeEventReports) => activeEventReports.ship,
  )
  activeEventReports: ActiveEventReportEntity;
}
