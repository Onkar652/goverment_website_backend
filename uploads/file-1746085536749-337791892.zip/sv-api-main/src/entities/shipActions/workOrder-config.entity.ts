import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  OneToMany,
  JoinColumn,
} from 'typeorm';
import { MainPartComponent } from '../shipParts/main-part-components.entity';
import { UserRanks } from 'src/utils/models/common.types';
import { ChecklistConfig } from './wo-checklist-config.entity';
import { Ship } from '../ships/ships.entity';

@Entity()
export class WorkOrderConfig {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  jobId: number;

  @Column()
  description: string;

  @ManyToOne(() => MainPartComponent, (component) => component.workOrderConfig)
  component: MainPartComponent;

  @ManyToOne(() => Ship, (ship) => ship.workOrderConfigs, { nullable: true })
  @JoinColumn({ name: 'ship_id' })
  ship: Ship;

  @Column()
  reminderValue: number;

  @Column()
  reminderUnit: string;

  @Column({ nullable: true })
  maxRunHoursToService: number;

  @Column({ nullable: true })
  maxServicePeriod: string;

  @Column({ default: false })
  collectRunHours: boolean;

  @Column({ nullable: true, default: '1W' })
  collectFrequency: string;

  @Column({ nullable: true, type: 'timestamp' })
  nextServiceDate: Date;

  @Column({ nullable: true })
  lastReportedRunHours: number;

  @Column({
    type: 'enum',
    enum: UserRanks,
    default: UserRanks.CHIEF_ENGINEER,
  })
  responsibleRank: UserRanks;

  @Column({ type: 'text', nullable: true })
  jobDescription: string;

  @Column({ default: false })
  disabled: boolean; // For soft deletion of the config

  @Column({ nullable: true, type: 'timestamp' })
  lastGeneratedWorkOrder: Date;

  @Column({ type: 'float', nullable: true })
  plannedCost: number;

  @Column({ nullable: true })
  tmdsTemplateNumber: number;

  @Column({ nullable: true })
  tmdsTemplateName: string;

  @Column({ default: false })
  outOfTurn: boolean;

  @Column({ default: false })
  isDefect: boolean;

  @Column({ default: false })
  raRequired: boolean;

  @Column({ default: false })
  ptwRequired: boolean;

  @OneToMany(
    () => ChecklistConfig,
    (checklistConfig) => checklistConfig.workOrderConfig,
    {
      cascade: true,
    },
  )
  checklistItems: ChecklistConfig[];
}
