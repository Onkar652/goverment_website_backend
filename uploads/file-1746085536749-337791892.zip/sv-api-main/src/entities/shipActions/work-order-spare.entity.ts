import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { WorkOrder } from './work-order.entity';
import { SpareEntity } from '../inventory/spares.entity';

@Entity('work_order_spares')
export class WorkOrderSpareEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => WorkOrder, (workOrder) => workOrder.consumedSpares, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'work_order_id' })
  workOrder: WorkOrder;

  @ManyToOne(() => SpareEntity, (spare) => spare.usedInWorkOrders, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'spare_id' })
  spare: SpareEntity;

  @Column({ type: 'float', nullable: false })
  quantityUsed: number;

  @Column({ nullable: true })
  remarks: string;

  // Add jobId as a reference
  @Column({ nullable: false })
  jobId: string;
}
