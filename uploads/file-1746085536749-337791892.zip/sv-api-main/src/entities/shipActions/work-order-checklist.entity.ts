import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { WorkOrder } from './work-order.entity';

@Entity('work_order_checklist')
export class WorkOrderChecklist {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  description: string; // Description of the checklist item

  @Column({ type: 'timestamp', nullable: true })
  readingDate: Date; // Reading date (optional)

  @Column({ type: 'varchar', length: 50, nullable: true })
  result: string; // Stores the selected result value (e.g., "Good", "Fair", "Bad")

  @Column({ type: 'float', nullable: true })
  value: number; // Numerical value for the check (if applicable)

  @Column({ type: 'text', nullable: true })
  remarks: string; // Remarks for the checklist item

  @ManyToOne(() => WorkOrder, (workOrder) => workOrder.checklistItems, {
    onDelete: 'CASCADE', // Delete checklist items if the associated WorkOrder is deleted
  })
  @JoinColumn({ name: 'work_order_id' })
  workOrder: WorkOrder; // Relationship to WorkOrder
}
