import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { WorkOrderConfig } from './workOrder-config.entity';

@Entity('checklist_config')
export class ChecklistConfig {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  description: string;

  @Column({ type: 'timestamp', nullable: true })
  readingDate: Date;

  @Column({ nullable: true })
  result: string;

  @Column({ type: 'float', nullable: true })
  value: number;

  @Column({ nullable: true })
  remarks: string;

  @ManyToOne(
    () => WorkOrderConfig,
    (workOrderConfig) => workOrderConfig.checklistItems,
    {
      onDelete: 'CASCADE',
    },
  )
  @JoinColumn({ name: 'work_order_config_id' })
  workOrderConfig: WorkOrderConfig;
}
