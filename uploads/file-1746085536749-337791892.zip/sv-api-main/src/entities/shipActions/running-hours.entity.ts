import { UserRanks } from 'src/utils/models/common.types';
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { MainPart } from '../shipParts/main-parts.entity';

@Entity('running_hours')
export class RunningHoursEntity {
  @PrimaryGeneratedColumn()
  id: number;

  // @ManyToOne(() => MainPartComponent, (component) => component.runningHours)
  // component: MainPartComponent;
  @ManyToOne(() => MainPart, (mainPart) => mainPart.runningHours)
  mainPart: MainPart;

  @Column({ type: 'timestamp', nullable: true })
  dueDateForCounterReading: Date; // Next due date for counter reading

  @Column({ type: 'timestamp', nullable: true })
  lastReportedDate: Date; // Last date when the running hours were reported

  @Column({ type: 'float', nullable: true, default: 0 })
  lastReportedValue: number; // Most recent reading of the counter

  @Column({ type: 'float', nullable: true })
  actualValue: number; // Actual value of the running hours counter

  @Column({ type: 'float', nullable: true })
  dailyAverage: number; // Daily average increase in the running hours

  @Column({ nullable: true, default: '1W' })
  collectFrequency: string;

  @Column({ default: 0 })
  order: number;

  @Column({
    type: 'enum',
    enum: UserRanks,
    default: UserRanks.CHIEF_ENGINEER,
  })
  updatedByRank: UserRanks; // Rank of the user who last updated the record
}
