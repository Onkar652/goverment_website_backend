import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  OneToMany,
  OneToOne,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { MainPartComponent } from '../shipParts/main-part-components.entity';
import { WorkOrderConfig } from './workOrder-config.entity';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';
import { UserRanks } from 'src/utils/models/common.types';
import { Ship } from '../ships/ships.entity';
import { WorkOrderChecklist } from './work-order-checklist.entity';
import { WorkOrderSpareEntity } from './work-order-spare.entity';
import { CorrectiveActionEntity } from '../qhse-reports/corrective-measure.entity';
import { PreventiveActionEntity } from '../qhse-reports/preventive-measure.entity';
@Entity()
export class WorkOrder {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  jobId: string;

  @Column()
  title: string;

  @Column({ nullable: true })
  jobDescription: string;

  @Column({ nullable: true })
  feedback: string;

  @Column()
  status: string; // 'open', 'due', 'overdue', 'finished', 'closed','inWindow'

  @Column({ nullable: true })
  conditionBeforeOh: string;

  @Column({ default: false })
  disabled: boolean;

  @ManyToOne(() => MainPartComponent, (component) => component.workOrders)
  component: MainPartComponent;

  @Column({ nullable: true })
  manHours: number;

  @Column({ nullable: true })
  workerCount: number;

  @Column({ nullable: true })
  counterAtCreation: number;

  @Column({ nullable: true })
  counterAtEnd: number;

  @Column({ nullable: true })
  lastReportedRunHours: number;

  @Column({ type: 'float', nullable: true })
  plannedCost: number;

  @Column({ nullable: true })
  tmdsTemplateNumber: number;

  @Column({ nullable: true })
  tmdsTemplateName: string;

  @Column({ default: false })
  outOfTurn: boolean;

  @Column({ default: false })
  isDefect: boolean;

  @Column({ nullable: true, type: 'timestamp' })
  defectCapturedOn: Date;

  @Column({ default: false })
  raRequired: boolean;

  @Column({ default: false })
  ptwRequired: boolean;

  @Column({ nullable: true, type: 'timestamp' })
  dueDate: Date;

  @Column({ type: 'varchar', length: 50, nullable: true })
  jobInterval: string; // Periodic job interval like '1M', '6M', '1Y'

  @Column({ nullable: true })
  observation: string;

  // Counter-based Tracking
  @Column({ type: 'float', nullable: true })
  dueCounterAtNext: number; // For counter-based jobs

  @Column({ type: 'float', nullable: true })
  lastDoneCounter: number; // Last done counter at job completion

  @Column({ nullable: true, type: 'timestamp' })
  lastDoneDate: Date; // When the job was last completed

  @Column({ nullable: true, type: 'timestamp' })
  startDate: Date;

  @Column({ nullable: true, type: 'timestamp' })
  finishedDate: Date;

  @Column({ nullable: true, type: 'timestamp' })
  approvedDate: Date;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedOn: Date;

  @Column({
    type: 'enum',
    enum: UserRanks,
    default: UserRanks.CHIEF_ENGINEER,
  })
  responsibleRank: UserRanks;

  @Column({
    type: 'enum',
    enum: UserRanks,
    nullable: true,
  })
  jobDoneBy: UserRanks;

  @ManyToOne(() => WorkOrderConfig, (config) => config.id)
  config: WorkOrderConfig; // Reference to the template (config) from which the work order was generated

  @OneToOne(() => FileStorageEntity, { cascade: true, onDelete: 'CASCADE' }) // Cascades operations for PTW document
  @JoinColumn() // This decorates the side of the owner of the relationship
  ptwDocument: FileStorageEntity; // PTW document, one per work order

  @OneToOne(() => FileStorageEntity, { cascade: true, onDelete: 'CASCADE' }) // Cascades operations for RA document
  @JoinColumn()
  raDocument: FileStorageEntity; // RA document, one per work order

  @OneToMany(() => FileStorageEntity, (file) => file.otherDocumentWorkOrder, {
    cascade: true,
    onDelete: 'CASCADE',
  })
  otherDocuments: FileStorageEntity[]; // Array of other documents

  @OneToMany(() => FileStorageEntity, (file) => file.jobPhotoWorkOrder, {
    cascade: true,
    onDelete: 'CASCADE',
  })
  jobPhotos: FileStorageEntity[];

  @ManyToOne(() => Ship, (ship) => ship.workOrders)
  @JoinColumn({ name: 'ship_id' }) // This line is optional but recommended for clarity
  ship: Ship;

  @OneToMany(() => WorkOrderChecklist, (checklist) => checklist.workOrder, {
    cascade: true,
    onDelete: 'CASCADE', // Automatically save related checklist items
  })
  checklistItems: WorkOrderChecklist[];

  @OneToMany(
    () => WorkOrderSpareEntity,
    (workOrderSpare) => workOrderSpare.workOrder,
    { cascade: true, onDelete: 'CASCADE' },
  )
  consumedSpares: WorkOrderSpareEntity[];

  @ManyToOne(
    () => CorrectiveActionEntity,
    (corrective_measures) => corrective_measures.workOrder,
    { cascade: true, onDelete: 'CASCADE' },
  )
  correctiveAction: CorrectiveActionEntity;

  @OneToOne(
    () => PreventiveActionEntity,
    (preventiveMeasure) => preventiveMeasure.workOrder,
    { cascade: true, onDelete: 'CASCADE' },
  )
  preventiveMeasures: PreventiveActionEntity;
}
