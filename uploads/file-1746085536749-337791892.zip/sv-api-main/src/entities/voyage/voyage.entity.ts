import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';
import { PositionBookReportEntity } from '../postion-book-reports/postion-report.entity';
import { Ship } from '../ships/ships.entity';
import { UserDetails } from '../users/user-details.entity';
import { CharterEntity } from './charter.entity';
import { ItineraryPortEntity } from './itinerary-port.entity';
import { ZoneEntity } from './zones.entity';

@Entity('voyage')
export class VoyageEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  voyageId: string;

  @Column()
  voyageNumber: string;

  @Column({ type: 'timestamp', nullable: true })
  voyageStart: Date;

  @Column({ nullable: true })
  vesselStatus: string;

  @Column({ nullable: true })
  timezone: string;

  @Column({ default: 'draft' })
  status: string;

  @Column({ type: 'float', nullable: true })
  charterPartySpeed: number;

  @Column({ type: 'float', nullable: true })
  charterPartyConsumption: number;

  @Column({ type: 'text', nullable: true })
  remarks: string;

  @Column({ nullable: true })
  lastReportType: string;

  @OneToMany(() => ItineraryPortEntity, (port) => port.voyage, {
    cascade: true,
  })
  ports: ItineraryPortEntity[];

  @Column({ nullable: true })
  createdBy: string;

  @Column({ nullable: true })
  updatedBy: string;

  @Column({ type: 'timestamp', nullable: true })
  completionDate: Date;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;

  @OneToMany(() => UserDetails, (userDetails) => userDetails.voyage)
  userDetails: UserDetails[];

  @ManyToOne(() => Ship, (ship) => ship.voyages)
  @JoinColumn({ name: 'shipId' })
  ship: Ship;

  @OneToMany(() => ZoneEntity, (zone) => zone.voyage, { cascade: true })
  zones: ZoneEntity[];

  @OneToMany(() => CharterEntity, (charter) => charter.voyage, {
    cascade: true,
  })
  charters: CharterEntity[];

  @OneToMany(() => FileStorageEntity, (file) => file.voyage, {
    cascade: true,
  })
  attachments: FileStorageEntity[];

  @OneToMany(() => PositionBookReportEntity, (pbook) => pbook.voyage, {
    cascade: true,
  })
  positionBookReports: PositionBookReportEntity[];

  @Column({ default: false })
  disabled: boolean;
}
