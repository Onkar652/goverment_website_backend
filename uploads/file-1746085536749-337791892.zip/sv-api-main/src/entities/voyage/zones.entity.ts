import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { VoyageEntity } from './voyage.entity';

export enum ZoneType {
  ECA = 'ECA Area',
  EU_WATERS = 'EU Waters',
  PIRACY = 'Piracy Risk Zone',
  SENSITIVE_SEA = 'Sensitive Sea Areas',
  OTHER = 'Other',
}

@Entity('zones')
export class ZoneEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => VoyageEntity, (voyage) => voyage.zones, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'voyage_id' })
  voyage: VoyageEntity;

  @Column({ type: 'enum', enum: ZoneType })
  zoneType: ZoneType;

  @Column({ type: 'float', nullable: false })
  entryLatitude: number;

  @Column({ type: 'float', nullable: false })
  entryLongitude: number;

  @Column({ type: 'timestamp', nullable: false })
  entryEta: Date;

  @Column({ type: 'float', nullable: false })
  exitLatitude: number;

  @Column({ type: 'float', nullable: false })
  exitLongitude: number;

  @Column({ type: 'timestamp', nullable: false })
  exitEtd: Date;
}
