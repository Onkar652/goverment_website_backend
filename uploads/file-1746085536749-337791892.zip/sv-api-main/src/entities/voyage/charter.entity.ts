import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { VoyageEntity } from './voyage.entity';

@Entity('charters')
export class CharterEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => VoyageEntity, (voyage) => voyage.charters, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'voyage_id' })
  voyage: VoyageEntity;

  @Column()
  type: string;

  @Column({ nullable: false })
  name: string;

  @Column({ nullable: false })
  address1: string;

  @Column({ nullable: true })
  address2: string;

  @Column({ nullable: false })
  contactNumber: string;
}
