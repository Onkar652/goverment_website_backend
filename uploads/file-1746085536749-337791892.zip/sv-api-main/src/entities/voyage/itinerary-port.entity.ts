import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
  JoinColumn,
} from 'typeorm';
import { VoyageEntity } from './voyage.entity';
import { PortListEntity } from '../master-configs/port-list.entity';

@Entity('itinerary_ports')
export class ItineraryPortEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => VoyageEntity, (voyage) => voyage.ports, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'voyage_id' })
  voyage: VoyageEntity;

  @ManyToOne(() => PortListEntity, { nullable: false })
  @JoinColumn({ name: 'port_id' })
  port: PortListEntity;

  @Column({ type: 'varchar', length: 50 })
  timezone: string;

  @Column({ type: 'timestamp', nullable: true })
  eta: Date | null;

  @Column({ type: 'timestamp', nullable: true })
  etb: Date | null;

  @Column({ type: 'timestamp', nullable: true })
  etd: Date | null;

  @Column({ type: 'timestamp', nullable: true })
  actualArrival: Date | null; // EOSP

  @Column({ type: 'timestamp', nullable: true })
  arrivalDate: Date | null; // AB

  @Column({ type: 'timestamp', nullable: true })
  departureDate: Date | null; // DB

  @Column({ type: 'timestamp', nullable: true })
  actualDeparture: Date | null; // COSP

  @Column({ type: 'varchar', length: 255, nullable: true })
  agentName: string;

  @Column({ type: 'text', nullable: true })
  remarks: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;
}
