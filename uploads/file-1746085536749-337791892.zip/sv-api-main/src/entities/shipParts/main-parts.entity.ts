import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { SpareEntity } from '../inventory/spares.entity';
import { RunningHoursEntity } from '../shipActions/running-hours.entity';
import { Ship } from '../ships/ships.entity';
import { MainPartContentConsumptionEntity } from '../tank-config/main-part-consumption.entity';
import { MainPartComponent } from './main-part-components.entity';

enum ComponentCategoryEnum {
  ENGINE = 'engine',
  DECK = 'deck',
  CRITICAL = 'critical',
  // ELECTRICAL = 'electrical',
  // AUXILIARY = 'auxiliary',
  OTHER = 'other',
}

@Entity()
export class MainPart {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  name: string;

  @Column({
    type: 'enum',
    enum: ComponentCategoryEnum,
    default: ComponentCategoryEnum.OTHER,
  })
  category: ComponentCategoryEnum;

  @ManyToOne(() => Ship, (ship) => ship.mainParts)
  ship: Ship;

  @OneToMany(() => MainPartComponent, (component) => component.mainPart)
  components: MainPartComponent[];

  @Column({ default: false })
  disabled: boolean;

  @Column({ type: 'float', nullable: true, default: 0 })
  previousConsumption: number;

  @Column({ type: 'float', nullable: true, default: 0 })
  currentConsumption: number;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;

  @OneToMany(() => RunningHoursEntity, (runningHours) => runningHours.mainPart)
  runningHours: RunningHoursEntity[];

  @OneToMany(() => SpareEntity, (spare) => spare.mainPart)
  spares: SpareEntity[];

  @OneToMany(
    () => MainPartContentConsumptionEntity,
    (consumption) => consumption.mainPart,
  )
  contentConsumptions: MainPartContentConsumptionEntity[];
}
