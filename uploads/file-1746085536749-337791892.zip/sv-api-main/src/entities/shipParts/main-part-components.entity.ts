import {
  Column,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { WorkOrder } from '../shipActions/work-order.entity';
import { WorkOrderConfig } from '../shipActions/workOrder-config.entity';
import { MainPart } from './main-parts.entity';

export enum ComponentCategoryEnum {
  ENGINE = 'engine',
  DECK = 'deck',
  CRITICAL = 'critical',
  // ELECTRICAL = 'electrical',
  // AUXILIARY = 'auxiliary',
  OTHER = 'other',
}

@Entity()
export class MainPartComponent {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  partId: string;

  @Column({ nullable: true })
  maker: string;

  @Column({ nullable: true })
  model: string;

  // @OneToMany(() => RunningHoursEntity, (runningHours) => runningHours.component)
  // runningHours: RunningHoursEntity[];

  @OneToMany(() => WorkOrder, (workOrder) => workOrder.component)
  workOrders: WorkOrder[];

  @OneToMany(() => WorkOrderConfig, (template) => template.component)
  workOrderConfig: WorkOrderConfig[];

  @ManyToOne(() => MainPart, (mainPart) => mainPart.components)
  mainPart: MainPart;

  //   @ManyToMany(() => SparePart, (sparePart) => sparePart.components)
  //   @JoinTable()
  //   spareParts: SparePart[];

  @Column({ default: false })
  disabled: boolean; // For soft deletion
}
