import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { RequisitionEntity } from './requisition.entity';
import { SpareEntity } from '../inventory/spares.entity';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';

@Entity('requisition_items')
export class RequisitionItemEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => RequisitionEntity, (requisition) => requisition.items, {
    onDelete: 'CASCADE',
  })
  requisition: RequisitionEntity;

  @ManyToOne(
    () => SpareEntity,
    (inventoryItem) => inventoryItem.requisitionItems,
    { nullable: true },
  )
  inventoryItem: SpareEntity;

  @Column({ nullable: true })
  description: string;

  @Column({ nullable: true })
  partNumber: string;

  @Column({ nullable: true })
  itemNumber: string;

  @Column({ nullable: true })
  drawingNumber: string;

  @Column({ type: 'float', nullable: true })
  rob: number;

  @Column({ type: 'float' })
  requestedQuantity: number;

  @Column({ type: 'float', nullable: true })
  quantityInUse: number;

  @Column({ nullable: true })
  uom: string;

  @Column({ nullable: true })
  remarks: string;

  @Column({ nullable: true })
  commentToVendor: string;

  @Column({ nullable: true })
  commentToBuyer: string;

  @ManyToOne(() => FileStorageEntity, { nullable: true, onDelete: 'SET NULL' })
  file: FileStorageEntity;
}
