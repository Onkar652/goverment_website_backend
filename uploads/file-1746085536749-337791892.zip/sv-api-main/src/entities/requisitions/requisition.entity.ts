import {
  InventoryType,
  RequisitionStatus,
} from 'src/utils/models/common.types';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { RequisitionPriority } from '../../utils/models/common.types';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';
import { CorrectiveActionEntity } from '../qhse-reports/corrective-measure.entity';
import { PreventiveActionEntity } from '../qhse-reports/preventive-measure.entity';
import { MainPart } from '../shipParts/main-parts.entity';
import { Ship } from '../ships/ships.entity';
import { RequisitionItemEntity } from './requisition-item.entity';

@Entity('requisitions')
export class RequisitionEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  prNumber: string;

  @Column({
    type: 'enum',
    enum: InventoryType,
    default: InventoryType.SPARE,
  })
  type: InventoryType;

  @Column()
  description: string;

  @Column()
  portOfSupply: string;

  @Column({
    type: 'enum',
    enum: RequisitionPriority,
    default: RequisitionPriority.NORMAL,
  })
  priority: RequisitionPriority;

  @Column({
    type: 'enum',
    enum: RequisitionStatus,
    default: RequisitionStatus.DRAFT,
  })
  status: RequisitionStatus;

  @Column({ nullable: true })
  modelName: string;

  @Column({ nullable: true })
  makerName: string;

  @Column({ nullable: true })
  commentToVendor: string;

  @Column({ nullable: true })
  commentToBuyer: string;

  @Column({ nullable: true, type: 'timestamp' })
  requiredDate: Date;

  @CreateDateColumn()
  createdOn: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedOn: Date;

  @ManyToOne(() => MainPart, { nullable: true })
  @JoinColumn({ name: 'mainPartId' })
  mainPart: MainPart;

  @OneToMany(() => RequisitionItemEntity, (item) => item.requisition, {
    cascade: true,
  })
  items: RequisitionItemEntity[];

  @ManyToOne(() => Ship, (ship) => ship.requisitions, { nullable: false })
  @JoinColumn({ name: 'ship_id' })
  ship: Ship;

  @OneToMany(() => FileStorageEntity, (file) => file.requisition, {
    cascade: true,
  })
  documents: FileStorageEntity[];

  @ManyToOne(
    () => CorrectiveActionEntity,
    (correctiveAction) => correctiveAction.purchaseRequisitions,
    {
      cascade: true,
    },
  )
  correctiveAction: CorrectiveActionEntity;

  @ManyToOne(
    () => PreventiveActionEntity,
    (preventiveAction) => preventiveAction.purchaseRequisitions,
  )
  preventiveAction: PreventiveActionEntity;
}
