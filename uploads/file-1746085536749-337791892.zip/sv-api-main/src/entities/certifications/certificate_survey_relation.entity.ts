import { Entity, PrimaryGeneratedColumn, ManyToOne, JoinColumn } from 'typeorm';
import { PredefinedCertificatesEntity } from './certificate-list.entity';
import { PredefinedSurveyEntity } from './survey_list.entity';

@Entity('certificate_survey_link')
export class CertificateSurveyLinkEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => PredefinedCertificatesEntity, (cert) => cert.surveys)
  @JoinColumn({ name: 'certificate_id' })
  certificate: PredefinedCertificatesEntity;

  @ManyToOne(() => PredefinedSurveyEntity, (survey) => survey.certificates)
  @JoinColumn({ name: 'survey_id' })
  survey: PredefinedSurveyEntity;
}
