import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { PredefinedCertificatesEntity } from './certificate-list.entity';

@Entity('certificate_category')
export class CertificateCategoryEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @OneToMany(
    () => PredefinedCertificatesEntity,
    (predefinedCertificate) => predefinedCertificate.category,
  )
  predefinedCertificates: PredefinedCertificatesEntity[];
}
