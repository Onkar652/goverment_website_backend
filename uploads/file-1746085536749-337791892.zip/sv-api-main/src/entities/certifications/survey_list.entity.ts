import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { CertificateSurveyLinkEntity } from './certificate_survey_relation.entity';

@Entity('survey_list')
export class PredefinedSurveyEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @OneToMany(
    () => CertificateSurveyLinkEntity,
    (certificateSurvey) => certificateSurvey.survey,
  )
  certificates: CertificateSurveyLinkEntity[];
}
