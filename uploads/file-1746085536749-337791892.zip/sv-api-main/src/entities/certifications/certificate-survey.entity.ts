import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  OneToMany,
  JoinColumn,
} from 'typeorm';
import { CertificationEntity } from './certification.entity';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';
import { SurveyStatus } from 'src/utils/models/common.types';

@Entity('certificate_survey')
export class CertificateSurveyEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ nullable: true })
  type: string;

  @Column({ nullable: true })
  authority: string;

  @Column({ nullable: true })
  surveyedBy: string;

  @Column({ nullable: true })
  locationPort: string;

  @Column({ nullable: true })
  dueRange: string; // This could be a string that describes the range or a more complex type if needed

  @Column({ type: 'date', nullable: true })
  dueDate: Date;

  @Column({ type: 'date', nullable: true })
  extendedDate: Date;

  @Column({ type: 'date', nullable: true })
  completedDate: Date;

  @Column({ type: 'enum', enum: SurveyStatus })
  status: SurveyStatus;

  @ManyToOne(() => CertificationEntity, (certificate) => certificate.surveys)
  @JoinColumn()
  certificate: CertificationEntity;

  @OneToMany(() => FileStorageEntity, (file) => file.survey, { cascade: true })
  documents: FileStorageEntity[];
}
