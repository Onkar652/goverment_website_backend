import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  OneToMany,
} from 'typeorm';
import { CertificateCategoryEntity } from './certificate-category.entity';
import { CertificateSurveyLinkEntity } from './certificate_survey_relation.entity';

@Entity('certificate_list')
export class PredefinedCertificatesEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  adminSiNo: string;

  @Column()
  name: string;

  @Column({ nullable: true })
  issuingAuthority: string;

  @ManyToOne(
    () => CertificateCategoryEntity,
    (category) => category.predefinedCertificates,
  )
  @JoinColumn()
  category: CertificateCategoryEntity;

  // @OneToMany(() => PredefinedSurveyEntity, (survey) => survey.certificate, {
  //   cascade: true,
  // })
  // surveys: PredefinedSurveyEntity[];

  @OneToMany(
    () => CertificateSurveyLinkEntity,
    (certificateSurvey) => certificateSurvey.certificate,
  )
  surveys: CertificateSurveyLinkEntity[];
}
