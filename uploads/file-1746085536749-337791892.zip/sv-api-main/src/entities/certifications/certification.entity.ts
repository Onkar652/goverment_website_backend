import { CertificateStatus } from 'src/utils/models/common.types';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';
import { Ship } from '../ships/ships.entity';
import { CertificateSurveyEntity } from './certificate-survey.entity';

@Entity('certifications')
@Unique('UQ_certificate_name_ship', ['certificateName', 'ship'])
export class CertificationEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  adminSiNo: string;

  @ManyToOne(() => Ship, (ship) => ship.certificates)
  @JoinColumn({ name: 'ship_id' })
  ship: Ship;

  @Column()
  certificateName: string;

  @Column()
  certificateNo: string;

  @Column()
  type: string;

  @Column()
  issuedOn: Date;

  @Column()
  surveyedOn: Date;

  @Column()
  expiryDate: Date;

  @Column({ nullable: true })
  extendedDate: Date;

  @Column()
  issuedBy: string;

  @Column()
  issuingAuthority: string;

  @Column()
  originalOnBoard: boolean;

  @Column({
    type: 'enum',
    enum: CertificateStatus,
    default: CertificateStatus.Draft,
  })
  status: CertificateStatus;

  @Column({ nullable: true })
  dueStatus: string;

  @Column({ default: false })
  disabled: boolean;

  @OneToMany(() => FileStorageEntity, (document) => document.certificate, {
    cascade: true,
  })
  documents: FileStorageEntity[];

  @OneToMany(() => CertificateSurveyEntity, (survey) => survey.certificate, {
    cascade: true,
  })
  surveys: CertificateSurveyEntity[];

  // @ManyToOne(
  //   () => PreventiveActionEntity,
  //   (preventive) => preventive.certificates,
  // )
  // preventiveMeasures: PreventiveActionEntity;

  // @ManyToOne(
  //   () => CorrectiveActionEntity,
  //   (corrective_measures) => corrective_measures.certificates,
  //   {
  //     onDelete: 'CASCADE',
  //   },
  // )
  // correctiveAction: CorrectiveActionEntity;

  @Column({ nullable: true })
  createdBy: string;

  @Column({ nullable: true })
  updatedBy: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdOn: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedOn: Date;
}
