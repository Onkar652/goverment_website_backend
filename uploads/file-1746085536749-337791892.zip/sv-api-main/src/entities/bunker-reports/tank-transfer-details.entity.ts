import {
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { ContentEntity } from '../tank-config/content.entity';
import { TankConfigurationEntity } from '../tank-config/tank-config.entity';
import { BunkerReportEntity } from './bunker-reports.entity';

@Entity('tank_transfer_details')
export class TankTransferDetailsEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => BunkerReportEntity, (report) => report.transferDetails, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'bunker_report_id' })
  bunkerReport: BunkerReportEntity;

  @ManyToOne(() => TankConfigurationEntity, { nullable: false })
  @JoinColumn({ name: 'from_tank_id' })
  fromTank: TankConfigurationEntity;

  @ManyToOne(() => TankConfigurationEntity, { nullable: false })
  @JoinColumn({ name: 'to_tank_id' })
  toTank: TankConfigurationEntity;

  @ManyToOne(() => ContentEntity, { nullable: false })
  @JoinColumn({ name: 'content_id' })
  content: ContentEntity;

  @Column({ type: 'float', nullable: false })
  transferFromTankROB: number; // Initial ROB of from-tank

  @Column({ type: 'float', nullable: false })
  transferToTankROB: number; // Initial ROB of to-tank

  @Column({ type: 'float', nullable: false })
  transferQty: number; // Amount transferred

  @Column({ type: 'text', nullable: true })
  comments: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
