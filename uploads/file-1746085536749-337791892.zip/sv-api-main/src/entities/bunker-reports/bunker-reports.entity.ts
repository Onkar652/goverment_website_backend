import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  OneToMany,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';
import { Ship } from '../ships/ships.entity';
import { BunkerReportDetailsEntity } from './bunker-report-details.entity';
import { TankTransferDetailsEntity } from './tank-transfer-details.entity';
import { BunkerTransactionType } from 'src/utils/models/common.types';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';

@Entity('bunker_reports')
export class BunkerReportEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Index()
  @Column({ unique: true })
  reportNumber: string; // e.g. VJ-BCGR24000014

  @ManyToOne(() => Ship, (ship) => ship.bunkerReports, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'shipId' })
  ship: Ship;

  @Column()
  reportDate: Date;

  @Column()
  reportTime: string; // In HHmm format (e.g. "2130")

  @Column({
    type: 'enum',
    enum: BunkerTransactionType,
  })
  transactionType: BunkerTransactionType;

  @Column({ default: 'draft' })
  status: string; // Draft, Approved

  @Column()
  bunkeredAt: string; // e.g., "FUJAIRAH"

  @Column({ nullable: true })
  companyName: string; // For surveys

  @Column({ nullable: true })
  surveyorName: string; // For surveys

  @Column({ nullable: true })
  bargeName: string; // For bunker

  @Column({ nullable: true })
  supplierName: string; // For bunker

  @Column({ nullable: true })
  comments: string;

  @Column({ nullable: true })
  timezone: string;

  @OneToMany(
    () => BunkerReportDetailsEntity,
    (details) => details.bunkerReport,
    {
      cascade: true,
    },
  )
  details: BunkerReportDetailsEntity[];

  @OneToMany(
    () => TankTransferDetailsEntity,
    (details) => details.bunkerReport,
    {
      cascade: true,
    },
  )
  transferDetails: TankTransferDetailsEntity[];

  @Column({ type: 'boolean', default: false })
  isShore: boolean;

  @Column({ type: 'boolean', default: false })
  isShoreTask: boolean;

  @Column({ type: 'boolean', default: false })
  isCorrection: boolean;

  @Column({ type: 'boolean', default: false })
  isDeleted: boolean;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @OneToMany(() => FileStorageEntity, (file) => file.bunkerReport, {
    cascade: true,
  })
  attachments: FileStorageEntity[];
}
