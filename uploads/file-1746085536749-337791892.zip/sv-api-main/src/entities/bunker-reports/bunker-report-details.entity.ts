import {
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { ContentEntity } from '../tank-config/content.entity';
import { TankConfigurationEntity } from '../tank-config/tank-config.entity';
import { BunkerReportEntity } from './bunker-reports.entity';

@Entity('bunker_report_details')
export class BunkerReportDetailsEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => BunkerReportEntity, (report) => report.details, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'bunker_report_id' })
  bunkerReport: BunkerReportEntity;

  @ManyToOne(() => TankConfigurationEntity, { nullable: false })
  @JoinColumn({ name: 'tank_id' })
  tank: TankConfigurationEntity;

  @ManyToOne(() => ContentEntity, { nullable: false })
  @JoinColumn({ name: 'content_id' })
  content: ContentEntity;

  @Column({ type: 'float', nullable: false })
  initialQty: number; // Populated from TankConfig.lastReportROB

  @Column({ type: 'float', nullable: true, default: 0 })
  bunkeredQty: number; // Null or zero in case of surveys

  @Column({ type: 'float', nullable: true, default: 0 })
  shortSupply: number; // For bunkering, not used in survey

  @Column({ type: 'float', nullable: false })
  finalQty: number; // Surveyed final quantity

  @Column({ type: 'float', nullable: true })
  difference: number; // Difference in quantities for surveys

  @Column({ type: 'float', nullable: true })
  consumption: number; // Consumption during bunkering

  @Column({ type: 'text', nullable: true })
  comments: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
