import {
  Entity,
  PrimaryGeneratedColumn,
  OneToOne,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { PositionBookReportEntity } from './postion-report.entity';

@Entity('speed_distance_weather')
export class SpeedDistanceWeatherEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @OneToOne(
    () => PositionBookReportEntity,
    (report) => report.speedDistanceWeather,
  )
  report: PositionBookReportEntity;

  @Column({ nullable: true })
  trueCourse: string;

  @Column({ type: 'float', nullable: true })
  engine_distance: number;

  @Column({ type: 'float', nullable: true })
  observed_distance: number;

  @Column({ type: 'float', nullable: true })
  steaming_time: number;

  @Column({ type: 'float', nullable: true })
  time_spent_at_anchorage: number;

  @Column({ type: 'float', nullable: true })
  speed: number;

  @Column({ type: 'float', nullable: true })
  slip: number;

  @Column({ type: 'float', nullable: true })
  distance_to_go: number;

  @Column({ type: 'float', nullable: true })
  distanceTraveled: number;

  @Column({ nullable: true })
  windDirection: string;

  @Column({ type: 'float', nullable: true })
  windForce: number;

  @Column({ nullable: true })
  true_wind: string;

  @Column({ nullable: true })
  weatherCondition: string;

  @Column({ nullable: true })
  swell_direction: string;

  @Column({ nullable: true })
  swell_height: string;

  @Column({ nullable: true })
  visibility: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;
}
