import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { PositionBookReportEntity } from './postion-report.entity';

@Entity('cargo_details')
export class CargoDetailsEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  cargoName: string;

  @Column()
  storageUnitName: string;

  @Column({ type: 'float' })
  maximumCapacity: number;

  @Column({ type: 'float', default: 0 })
  initialQuantity: number;

  @Column({ type: 'float', default: 0 })
  loaded: number;

  @Column({ type: 'float', default: 0 })
  discharged: number;

  @Column({ type: 'float', default: 0 })
  totalCargo: number;

  @ManyToOne(() => PositionBookReportEntity, (report) => report.cargoDetails, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'report_id' })
  report: PositionBookReportEntity;

  @CreateDateColumn({ type: 'timestamp' })
  createdOn: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedOn: Date;
}
