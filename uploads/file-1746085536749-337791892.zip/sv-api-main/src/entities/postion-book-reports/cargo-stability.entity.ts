import {
  Entity,
  PrimaryGeneratedColumn,
  OneToOne,
  CreateDateColumn,
  UpdateDateColumn,
  Column,
  OneToMany,
} from 'typeorm';
import { PositionBookReportEntity } from './postion-report.entity';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';

@Entity('cargo_stability')
export class CargoStabilityEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @OneToOne(() => PositionBookReportEntity, (report) => report.cargoStability)
  report: PositionBookReportEntity;

  @Column({ default: false })
  is_cargo_activity: boolean;

  @Column({ nullable: true })
  vessel_activity: string;

  @Column({ type: 'float', nullable: true })
  displacement: number;

  @Column({ type: 'float', nullable: true })
  gm: number;

  @Column({ type: 'float', nullable: true })
  draft_fwd: number;

  @Column({ type: 'float', nullable: true })
  draft_aft: number;

  @Column({ type: 'float', nullable: true })
  no_of_containers: number;

  @Column({ type: 'float', nullable: true })
  refer_conatiners: number;

  @Column({ type: 'float', nullable: true })
  drifting_hrs: number;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;

  @OneToMany(() => FileStorageEntity, (document) => document.cargo, {
    cascade: true,
  })
  documents: FileStorageEntity[];
}
