import {
  Entity,
  PrimaryGeneratedColumn,
  OneToOne,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { PositionBookReportEntity } from './postion-report.entity';

@Entity('engine_data')
export class EngineDataEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @OneToOne(() => PositionBookReportEntity, (report) => report.engineData)
  report: PositionBookReportEntity;

  @Column({ type: 'float', nullable: true })
  me1_rpm: number;

  @Column({ nullable: true })
  me2_rpm: number;

  @Column({ type: 'float', nullable: true })
  me_tc1_rpm: number;

  @Column({ type: 'float', nullable: true })
  me_tc2_rpm: number;

  @Column({ type: 'float', nullable: true })
  me_tc3_rpm: number;

  @Column({ type: 'float', nullable: true })
  me_tc4_rpm: number;

  @Column({ type: 'float', nullable: true })
  exhaust_max_temp: number;

  @Column({ type: 'float', nullable: true })
  exhaust_min_temp: number;

  @Column({ type: 'float', nullable: true })
  actual_mcr: number;

  @Column({ type: 'float', nullable: true })
  actual_rpm: number;

  @Column({ type: 'float', nullable: true })
  me_daily_rh: number;

  @Column({ type: 'float', nullable: true })
  me_output_by_foc: number;

  @Column({ type: 'float', nullable: true })
  me_output: number;

  @Column({ type: 'float', nullable: true })
  speed_adjusted: number;

  @Column({ type: 'float', nullable: true })
  thermal_load: number;

  @Column({ type: 'float', nullable: true })
  ballas_water_quantity: number;

  @Column({ type: 'float', nullable: true })
  scavenge_pressure: number;

  @Column({ type: 'float', nullable: true })
  ae1_rh: number;

  @Column({ type: 'float', nullable: true })
  ae2_rh: number;

  @Column({ type: 'float', nullable: true })
  ae3_rh: number;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;
}
