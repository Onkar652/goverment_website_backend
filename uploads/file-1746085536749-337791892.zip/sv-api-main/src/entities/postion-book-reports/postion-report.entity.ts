import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  OneToOne,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany,
} from 'typeorm';
import { Ship } from '../ships/ships.entity';
import { VoyageEntity } from '../voyage/voyage.entity';
import { CargoStabilityEntity } from './cargo-stability.entity';
import { EngineDataEntity } from './engine-data.entity';
import { SpeedDistanceWeatherEntity } from './speed-distance-weather.entity';
import { CargoDetailsEntity } from './cargo_details.entity';
import { ROBTrackingEntity } from '../tank-config/rob-tank-tracking.entity';

@Entity('position_book_reports')
export class PositionBookReportEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  reportId: string;

  @ManyToOne(() => VoyageEntity, (voyage) => voyage.positionBookReports, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'voyage_id' })
  voyage: VoyageEntity;

  @ManyToOne(() => Ship, (ship) => ship.positionBookReports, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'ship_id' })
  ship: Ship;

  @Column({ type: 'date', nullable: true })
  reportDate: Date;

  @Column({ type: 'varchar', length: 4, nullable: true })
  reportTime: string;

  @Column({ type: 'timestamp', nullable: true })
  reportTimestamp: Date;

  @Column({ nullable: true })
  report_name: string;

  @Column()
  timezone: string;

  @Column()
  from_port: string;

  @Column()
  to_port: string;

  @Column({ nullable: true })
  berth: string;

  @Column({ nullable: true })
  vessel_location: string;

  @Column({ nullable: true })
  latitude: string;

  @Column({ nullable: true })
  longitude: string;

  @Column({ default: false })
  isShore: boolean;

  @Column({ default: 'draft' })
  status: string;

  @Column({ type: 'text', nullable: true })
  remarks: string;

  @OneToOne(() => SpeedDistanceWeatherEntity, (weather) => weather.report, {
    cascade: true,
  })
  @JoinColumn()
  speedDistanceWeather: SpeedDistanceWeatherEntity;

  @OneToOne(() => EngineDataEntity, (engineData) => engineData.report, {
    cascade: true,
  })
  @JoinColumn()
  engineData: EngineDataEntity;

  @OneToOne(
    () => CargoStabilityEntity,
    (cargoStability) => cargoStability.report,
    {
      cascade: true,
    },
  )
  @JoinColumn()
  cargoStability: CargoStabilityEntity;

  @OneToMany(() => CargoDetailsEntity, (cargo) => cargo.report, {
    cascade: true,
  })
  cargoDetails: CargoDetailsEntity[];

  @OneToMany(() => ROBTrackingEntity, (rob) => rob.report, {
    cascade: true,
  })
  @JoinColumn()
  tankROBDetails: ROBTrackingEntity[];

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;
}
