import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Ship } from '../ships/ships.entity';

@Entity('active_event_reports')
export class ActiveEventReportEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({
    type: 'enum',
    enum: ['bunker_report', 'position_book_report'],
  })
  reportType: string; // Specifies the type of active report (bunker or position book)

  @Column({ unique: true })
  reportId: string; // The unique ID of the report (e.g., "ARK-BR-25002")

  @ManyToOne(() => Ship, (ship) => ship.activeEventReports, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'ship_id' })
  ship: Ship;

  @Column({
    type: 'enum',
    enum: ['active', 'completed'],
  })
  reportStage: string;

  @Column({ type: 'timestamp', nullable: true })
  utcTime: Date;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;
}
