import {
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { PositionBookReportEntity } from '../postion-book-reports/postion-report.entity';
import { ContentEntity } from './content.entity';
import { MainPart } from '../shipParts/main-parts.entity';

@Entity('content_rob_tracking')
export class ContentROBTrackingEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => ContentEntity, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'content_id' })
  content: ContentEntity;

  @ManyToOne(() => PositionBookReportEntity, {
    nullable: false,
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'report_id' })
  report: PositionBookReportEntity;

  @ManyToOne(() => MainPart, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'main_part_id' })
  mainPart: MainPart;

  @Column({ type: 'float', nullable: true })
  openingBalance: number;

  @Column({ type: 'float', nullable: true })
  closingBalance: number;

  @Column({ type: 'float' })
  consumed: number;

  @Column({ type: 'text', nullable: true })
  comments: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdOn: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedOn: Date;
}
