import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { TankConfigurationEntity } from './tank-config.entity';
import { PositionBookReportEntity } from '../postion-book-reports/postion-report.entity';

@Entity('rob_tracking')
export class ROBTrackingEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => TankConfigurationEntity, {
    nullable: false,
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'tank_id' })
  tank: TankConfigurationEntity;

  @ManyToOne(
    () => PositionBookReportEntity,
    (report) => report.tankROBDetails,
    {
      nullable: false,
      onDelete: 'CASCADE',
    },
  )
  @JoinColumn({ name: 'report_id' })
  report: PositionBookReportEntity;

  @Column({ type: 'float' })
  openingBalance: number;

  @Column({ type: 'float' })
  closingBalance: number;

  @Column({ type: 'float' })
  consumed: number;

  @Column({ type: 'text', nullable: true })
  comments: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdOn: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedOn: Date;
}
