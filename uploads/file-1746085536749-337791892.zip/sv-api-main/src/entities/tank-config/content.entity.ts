import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Ship } from '../ships/ships.entity';
import { MainPartContentConsumptionEntity } from './main-part-consumption.entity';
import { TankConfigurationEntity } from './tank-config.entity';

@Entity('content')
export class ContentEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  contentCode: string;

  @Column({ unique: true })
  name: string; // E.g., HSFO, LSMGO, Lube Oil 1, Freshwater

  @Column({ type: 'varchar' })
  type: string; // FUEL, LUBE, WATER

  @Column({ type: 'float', nullable: true })
  sulphurContent: number;

  @Column({ type: 'float', nullable: true })
  viscosity: number;

  @Column({ type: 'float', nullable: true })
  density: number;

  @Column({ type: 'float', nullable: true })
  currentROB: number;

  @Column({ type: 'float', nullable: true })
  lastROB: number;

  @Column({ type: 'boolean', default: false })
  disabled: boolean;

  @Column({ default: 0 })
  order: number;

  @Column({ default: 0 })
  typeOrder: number;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;

  @ManyToOne(() => Ship, (ship) => ship.tanks, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'ship_id' })
  ship: Ship;

  @OneToMany(
    () => MainPartContentConsumptionEntity,
    (consumption) => consumption.content,
  )
  mainPartConsumptions: MainPartContentConsumptionEntity[];

  @OneToMany(() => TankConfigurationEntity, (tank) => tank.content, {
    cascade: true,
  })
  tanks: TankConfigurationEntity[];
}
