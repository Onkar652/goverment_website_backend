import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  JoinColumn,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Ship } from '../ships/ships.entity';
import { ContentEntity } from './content.entity';

@Entity('tank_configurations')
export class TankConfigurationEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  tankCode: string;

  @Column()
  tankName: string;

  @Column({ type: 'float' })
  capacity: number;

  @ManyToOne(() => ContentEntity, { nullable: false })
  @JoinColumn({ name: 'content_id' })
  content: ContentEntity;

  @Column({ type: 'varchar' })
  unitOfMeasure: string;

  @Column({ type: 'float', nullable: true })
  openingBalance: number;

  @Column({ type: 'timestamp', nullable: true })
  robDate: Date;

  @Column({ type: 'json', nullable: true })
  additionalInfo: Record<string, any>;

  @Column({ default: false })
  isInitialized: boolean;

  @Column({ nullable: true })
  comment: string;

  @Column({ type: 'float', nullable: true })
  currentROB: number;

  @Column({ type: 'float', nullable: true })
  lastReportROB: number;

  @Column({ type: 'float', nullable: true, default: 0 })
  sulphurContent: number;

  @Column({ type: 'float', nullable: true, default: 0 })
  viscosity: number;

  @Column({ type: 'float', nullable: true, default: 0 })
  density: number;

  @ManyToOne(() => Ship, (ship) => ship.tanks, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'ship_id' })
  ship: Ship;

  @CreateDateColumn({ type: 'timestamp' })
  createdOn: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedOn: Date;
}
