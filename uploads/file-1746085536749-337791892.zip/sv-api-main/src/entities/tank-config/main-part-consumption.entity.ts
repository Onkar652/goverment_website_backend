import {
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { MainPart } from '../shipParts/main-parts.entity';
import { ContentEntity } from './content.entity';

@Entity('main_part_content_consumption')
export class MainPartContentConsumptionEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => MainPart, (mainPart) => mainPart.contentConsumptions, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'main_part_id' })
  mainPart: MainPart;

  @ManyToOne(() => ContentEntity, (content) => content.mainPartConsumptions, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'content_id' })
  content: ContentEntity;

  @Column({ type: 'float', nullable: true, default: 0 })
  previousConsumption: number;

  @Column({ type: 'float', nullable: true, default: 0 })
  currentConsumption: number;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;
}
