import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { User } from './users.entity';
import { Ship } from '../ships/ships.entity';
import { VoyageEntity } from '../voyage/voyage.entity';

@Entity()
export class UserDetails {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User, (user) => user.userDetails)
  @JoinColumn({ name: 'user_id' })
  user: User;

  @Column()
  email_id: string;

  @Column()
  password: string;

  @Column({ default: true })
  active: boolean;

  @ManyToOne(() => Ship, (ship) => ship.userDetails)
  @JoinColumn({ name: 'ship_id' })
  ship: Ship;

  @ManyToOne(() => VoyageEntity, (voyage) => voyage.userDetails, {
    nullable: true,
  })
  @JoinColumn({ name: 'voyage_id' })
  voyage: VoyageEntity;
}
