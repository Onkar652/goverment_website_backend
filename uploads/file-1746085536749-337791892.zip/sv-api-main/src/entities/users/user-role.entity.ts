import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { User } from './users.entity';

@Entity()
export class UserRole {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true, name: 'code' })
  code: string;

  @Column({ name: 'description' })
  description: string;

  @OneToMany(() => User, (user) => user.role)
  users: User[];
}
