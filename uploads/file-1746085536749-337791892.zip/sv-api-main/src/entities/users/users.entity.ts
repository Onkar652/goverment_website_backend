import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  OneToMany,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { UserDetails } from './user-details.entity';
import { Client } from '../client/client.entity';
import { UserRole } from './user-role.entity';
import { UserRanksEntity } from './user-ranks.entity';

@Entity()
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @ManyToOne(() => UserRole, (role) => role.users)
  @JoinColumn({ name: 'role_id' })
  role: UserRole;

  @ManyToOne(() => UserRanksEntity, (rank) => rank.users)
  @JoinColumn({ name: 'rank_id' })
  rank: UserRanksEntity;

  @Column({ type: 'date' })
  onboarding_date: Date;

  @Column({ default: false })
  disabled: boolean;

  @ManyToOne(() => Client, (client) => client.users)
  @JoinColumn({ name: 'client_id' })
  client: Client;

  @OneToMany(() => UserDetails, (userDetails) => userDetails.user)
  userDetails: UserDetails[];
}
