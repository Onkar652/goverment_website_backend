import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { User } from './users.entity';

@Entity('user_ranks')
export class UserRanksEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  code: string; // e.g., "CE"

  @Column()
  description: string; // e.g., "Chief Engineer"

  @OneToMany(() => User, (user) => user.rank)
  users: User[];
}
