import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
  JoinColumn,
  OneToMany,
} from 'typeorm';
import { MainPart } from '../shipParts/main-parts.entity';
import { SpareCategory } from 'src/utils/models/common.types';
import { Ship } from '../ships/ships.entity';
import { SpareTransaction } from './spare-transaction.entity';
import { RequisitionItemEntity } from '../requisitions/requisition-item.entity';
import { WorkOrderSpareEntity } from '../shipActions/work-order-spare.entity';

@Entity('spares')
export class SpareEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  description: string;

  @Column({ nullable: true })
  partNumber: string;

  @Column({ nullable: true })
  makerRef: string;

  @Column({ nullable: true })
  drawingNo: string;

  @Column({ nullable: true })
  positionNo: string;

  @Column({ nullable: true })
  makerName: string;

  @Column({ nullable: true })
  modelName: string;

  @Column({ type: 'float', nullable: true })
  minimumLevel: number;

  @Column({ type: 'float' })
  rob: number;

  @Column({ nullable: true })
  unitOfMeasure: string;

  @Column({
    type: 'enum',
    enum: ['spare', 'store'], // Define the allowed values for the column
    default: 'spare', // Default value is 'spare'
  })
  type: 'spare' | 'store';

  @Column({
    type: 'enum',
    enum: SpareCategory,
    default: SpareCategory.NORMAL,
  })
  category: SpareCategory;

  @ManyToOne(() => MainPart, (component) => component.spares, {
    nullable: true,
  })
  mainPart: MainPart;

  @Column({ nullable: true })
  createdBy: string;

  @Column({ nullable: true })
  updatedBy: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdOn: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedOn: Date;

  @ManyToOne(() => Ship, (ship) => ship.spares)
  @JoinColumn({ name: 'ship_id' })
  ship: Ship;

  @OneToMany(() => SpareTransaction, (transaction) => transaction.spare, {
    cascade: true,
  })
  transactions: SpareTransaction[];

  @OneToMany(
    () => RequisitionItemEntity,
    (requisitionItem) => requisitionItem.inventoryItem,
  )
  requisitionItems: RequisitionItemEntity[];

  @OneToMany(
    () => WorkOrderSpareEntity,
    (workOrderSpare) => workOrderSpare.spare,
    {
      cascade: true,
    },
  )
  usedInWorkOrders: WorkOrderSpareEntity[];
}
