import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { SpareEntity } from './spares.entity';

export enum TransactionReason {
  PURCHASE = 'purchase',
  CONSUME = 'consume',
  LOST = 'lost',
  FOUND = 'found',
}

@Entity('spare_transactions')
export class SpareTransaction {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => SpareEntity, (spare) => spare.transactions, {
    onDelete: 'CASCADE',
  })
  spare: SpareEntity;

  @Column({ type: 'enum', enum: TransactionReason })
  reason: TransactionReason;

  @Column({ type: 'float' })
  quantity: number;

  @Column({ type: 'text', nullable: true })
  remark: string;

  @Column({ nullable: true })
  updatedBy: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdOn: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedOn: Date;
}
