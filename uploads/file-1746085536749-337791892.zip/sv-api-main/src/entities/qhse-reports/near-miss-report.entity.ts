import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';
import { LogEntity } from '../master-configs/log.entity';
import { LossPotentialEntity } from '../potential-loss/potential-loss.entity';
import { Ship } from '../ships/ships.entity';
import { CauseAnalysisEntity } from './cause-analysis.entity';
import { CorrectiveActionEntity } from './corrective-measure.entity';
import { PreventiveActionEntity } from './preventive-measure.entity';

@Entity('near_miss_report')
export class NearMissReportEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'text', nullable: true })
  nearMissReportId: string;

  @Column({ type: 'timestamp', nullable: true })
  incidentDate: Date;

  @Column({ type: 'varchar', length: 50, nullable: true })
  timezone: string;

  @Column({ default: 1 })
  serialNumber: number;

  @Column({ type: 'text', nullable: true })
  vesselActivity: string;

  @Column({ type: 'text', nullable: true })
  vesselLocation: string;

  @Column({ type: 'text', nullable: true })
  vesselStatus: string;

  @Column({ type: 'time', nullable: true })
  incidentTime: string;

  @Column({ type: 'text', nullable: true })
  activityAtTimeOfIncident: string;

  @Column({ type: 'text', nullable: true })
  locationOnboard: string;

  @Column({ type: 'timestamp', nullable: true })
  targetCompletionDate: Date;

  @Column({ type: 'text', nullable: true })
  reportTitle: string;

  @Column({ default: 'Draft' })
  status: string;

  @Column({ type: 'text', nullable: true })
  reviewerName: string;

  @Column({ type: 'text', nullable: true })
  name: string;

  @Column({ type: 'text', nullable: true })
  rank: string;

  @ManyToOne(() => Ship, (ship) => ship.reports)
  @JoinColumn({ name: 'shipId' })
  ship: Ship;

  @Column({ type: 'text', nullable: true })
  createdBy: string;

  @Column({ type: 'text', nullable: true })
  updatedBy: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;

  @Column({ type: 'text', nullable: true, default: '' })
  eventDetails: string;

  @Column({ type: 'text', nullable: true, default: '' })
  consequentialCategory: string;

  @Column({ default: false })
  disabled: boolean;

  @OneToMany(() => LossPotentialEntity, (file) => file.nearMissReport, {
    cascade: true,
  })
  lossPotential: LossPotentialEntity[];

  // @OneToOne(
  //   () => RiskPotentialEntity,
  //   (potentialSecurityLoss) => potentialSecurityLoss.nearMissReport,
  //   { cascade: true },
  // )
  // potentialSecurityLoss: RiskPotentialEntity;

  @OneToOne(
    () => CauseAnalysisEntity,
    (causeAnalysis) => causeAnalysis.nearMissReport,
    { cascade: true },
  )
  causeAnalysis: CauseAnalysisEntity;

  @OneToMany(() => FileStorageEntity, (file) => file.nearMissReport, {
    cascade: true,
  })
  attachments: FileStorageEntity[];

  @OneToOne(
    () => CorrectiveActionEntity,
    (corrective) => corrective.nearMissReport,
    { cascade: true },
  )
  correctiveAction: CorrectiveActionEntity;

  @OneToOne(
    () => PreventiveActionEntity,
    (preventive) => preventive.nearMissReport,
    { cascade: true },
  )
  preventiveAction: PreventiveActionEntity;

  @OneToOne(() => LogEntity, (logs) => logs.nearMissReport)
  logs: LogEntity;
}
