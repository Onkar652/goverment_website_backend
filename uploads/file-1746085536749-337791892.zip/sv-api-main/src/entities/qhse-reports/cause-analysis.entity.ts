import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { DirectCauseEntity } from '../master-configs/direct-cause.entity';
import { InDirectCauseEntity } from '../master-configs/indirect-cause.entity';
import { RootCauseEntity } from '../master-configs/root-cause.entity';
import { NearMissReportEntity } from './near-miss-report.entity';

@Entity('cause_analysis')
export class CauseAnalysisEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: false, nullable: true })
  causeId: string;

  @Column({ nullable: true })
  directCauseDescription: string;

  @Column({ nullable: true })
  indirectCauseDescription: string;

  @Column({ nullable: true })
  rootCauseDescription: string;

  @ManyToOne(() => DirectCauseEntity, { eager: true })
  @JoinColumn({ name: 'directCauseId' })
  directCause: DirectCauseEntity;

  @ManyToOne(() => InDirectCauseEntity, { eager: true })
  @JoinColumn({ name: 'indirectCauseId' })
  indirectCause: InDirectCauseEntity;

  @ManyToOne(() => RootCauseEntity, { eager: true })
  @JoinColumn({ name: 'rootCauseId' })
  rootCause: RootCauseEntity;

  @OneToOne(() => NearMissReportEntity, (report) => report.causeAnalysis)
  @JoinColumn({ name: 'nearMissReportId' })
  nearMissReport: NearMissReportEntity;
}
