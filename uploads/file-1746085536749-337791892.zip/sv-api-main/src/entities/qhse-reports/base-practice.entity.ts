import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';
import { LogEntity } from '../master-configs/log.entity';
import { Ship } from '../ships/ships.entity';

@Entity()
export class BasePracticeReportEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ nullable: true })
  basePracticeReportId: string;

  @Column({ default: 1 })
  serialNumber: number;

  @Column({ nullable: true })
  vesselLocationForSF?: string;

  @Column({ nullable: true })
  vesselLocationForBP?: string;

  @Column({ nullable: true })
  name?: string;

  @Column({ nullable: true })
  department?: string;

  @Column({ nullable: true })
  categoriesOfBPorSFI?: string;

  @Column({ type: 'date', nullable: true })
  bestPracticeAdoptedDate?: string;

  @Column({ nullable: true })
  bestPracticeSuggestedBy?: string;

  @Column({ nullable: true })
  bestPracticeIdentifiedFrom?: string;

  @Column({ nullable: true })
  description?: string;

  @Column({ nullable: true })
  comment?: string;

  @Column({ nullable: true })
  status?: string;

  @Column({ nullable: true })
  timeZone?: string;

  @Column({ nullable: true })
  reportedDate?: string;

  @Column({ nullable: true })
  reviewerName?: string;

  @Column({ nullable: true })
  reportTitle?: string;

  @ManyToOne(() => Ship, (ship) => ship.baseReports)
  @JoinColumn({ name: 'shipId' })
  ship: Ship;

  @OneToOne(() => LogEntity, (log) => log.baseReport, { nullable: true })
  @JoinColumn({ name: 'logId' })
  logs: LogEntity;

  @OneToMany(
    () => FileStorageEntity,
    (attachments) => attachments.basePracticeReport,
    {
      cascade: true,
      eager: true,
    },
  )
  attachments: FileStorageEntity[];

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;
}
