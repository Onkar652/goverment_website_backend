import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';
import { Ship } from '../ships/ships.entity';
import { CauseAnalysisEntity } from './cause-analysis.entity';
import {
  LarpReportInfo,
  LastReportDetailsEntity,
} from './larp-report-info.entity';
import { MainAreaOfConcern } from './main-area.entity';

@Entity('larp')
export class LarpReportEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'text', unique: false })
  larpReportId: string;

  @Column({ default: 1 })
  serialNumber: number;

  @Column({ nullable: true })
  status?: string;

  @OneToOne(
    () => LarpReportInfo,
    (larpReportInfo) => larpReportInfo.larpReport,
    {
      eager: true,
    },
  )
  @JoinColumn()
  larpReportInfo: LarpReportInfo;

  @ManyToOne(
    () => LastReportDetailsEntity,
    (larpReportDetails) => larpReportDetails.larpReport,
    {
      nullable: true,
    },
  )
  larpReportDetails: LastReportDetailsEntity;

  @ManyToOne(() => MainAreaOfConcern, { nullable: true })
  mainAreaOfConcern: MainAreaOfConcern;

  // @OneToOne(() => LogEntity, (logs) => logs.larpReport, {
  //   cascade: true,
  // })
  // logs: LogEntity;

  @OneToMany(() => FileStorageEntity, (attachments) => attachments.larpReport, {
    cascade: true,
  })
  attachments: FileStorageEntity[];

  @ManyToOne(() => Ship, (ship) => ship.larpReport)
  @JoinColumn({ name: 'shipId' })
  ship: Ship;

  @ManyToOne(() => CauseAnalysisEntity, { nullable: true })
  causeAnalysis: CauseAnalysisEntity;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;
}
