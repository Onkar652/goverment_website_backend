import { CertificateStatus } from 'src/utils/models/common.types';
import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';
import { AreaEntity } from '../master-configs/area.entity';
import { RequisitionEntity } from '../requisitions/requisition.entity';
import { WorkOrder } from '../shipActions/work-order.entity';
import { Ship } from '../ships/ships.entity';
import { NearMissReportEntity } from './near-miss-report.entity';

@Entity('preventive_action')
export class PreventiveActionEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 255, nullable: true })
  preventiveActionId: string;

  @Column({ type: 'varchar', length: 255, nullable: true }) // Make nullable
  initiatedFrom: string;

  @Column({ type: 'text', unique: true, nullable: true }) // Make nullable
  findingReportId: string;

  @OneToMany(() => AreaEntity, (area) => area.preventiveMeasures, {
    nullable: true,
  })
  relatedAreaList: AreaEntity[];

  @Column({ type: 'text', nullable: true })
  preventiveActionsPlan: string;

  @Column({ type: 'text', nullable: true })
  actionCarriedOut: string;

  @Column({ type: 'boolean', default: false, nullable: true }) // Make nullable
  isEvidenceRequired: boolean;

  @Column({ type: 'date', nullable: true })
  nearMissReportIncidentDate: string;

  @Column({ type: 'date', nullable: true })
  targetDate: string;

  @Column({ nullable: true })
  status: CertificateStatus;

  @Column({ nullable: true })
  personInCharge: string;

  @OneToMany(
    () => FileStorageEntity,
    (attachments) => attachments.preventiveAction,
    {
      cascade: true,
      eager: true,
    },
  )
  attachments: FileStorageEntity[];

  @OneToOne(() => WorkOrder, (workOrder) => workOrder.preventiveMeasures, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'work_order_id' })
  workOrder: WorkOrder;

  @Column({ type: 'varchar', length: 255, nullable: true })
  purchaseOrders: string;

  @OneToMany(
    () => RequisitionEntity,
    (requisition) => requisition.preventiveAction,
  )
  purchaseRequisitions: RequisitionEntity;

  @ManyToOne(() => Ship, (ship) => ship.preventiveAction)
  @JoinColumn({ name: 'shipId' })
  ship: Ship;

  @ManyToOne(
    () => NearMissReportEntity,
    (nearMissReport) => nearMissReport.preventiveAction,
    {
      onDelete: 'CASCADE',
    },
  )
  nearMissReport: NearMissReportEntity;
}
