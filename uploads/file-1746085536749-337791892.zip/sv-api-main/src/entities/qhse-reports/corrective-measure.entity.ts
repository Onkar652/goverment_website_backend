import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { FileStorageEntity } from '../fileStorage/file-storage.entity';
import { AreaEntity } from '../master-configs/area.entity';
import { RequisitionEntity } from '../requisitions/requisition.entity';
import { WorkOrder } from '../shipActions/work-order.entity';
import { Ship } from '../ships/ships.entity';
import { NearMissReportEntity } from './near-miss-report.entity';

@Entity('corrective_action')
export class CorrectiveActionEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 255, nullable: true })
  correctiveActionId: string;

  @Column({ type: 'varchar', length: 255, nullable: true }) // Make nullable
  initiatedFrom: string;

  @Column({ type: 'text', unique: true, nullable: true }) // Make nullable
  findingReportId: string;

  @OneToMany(() => AreaEntity, (area) => area.correctiveAction, {
    nullable: true,
  })
  relatedAreaList: AreaEntity[];

  @Column({ type: 'text', nullable: true })
  correctiveActionsPlan: string;

  @Column({ type: 'text', nullable: true })
  actionCarriedOut: string;

  @Column({ type: 'boolean', default: false, nullable: true }) // Make nullable
  isEvidenceRequired: boolean;

  @Column({ type: 'date', nullable: true })
  nearMissReportIncidentDate: string;

  @Column({ type: 'date', nullable: true })
  targetDate: string;

  @Column({ nullable: true })
  status: string;

  @Column({ nullable: true })
  personInCharge: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @OneToMany(
    () => FileStorageEntity,
    (attachments) => attachments.correctiveAction,
    {
      cascade: true,
      eager: true,
    },
  )
  attachments: FileStorageEntity[];

  @OneToMany(() => WorkOrder, (workOrder) => workOrder.correctiveAction, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'work_order_id' })
  workOrder: WorkOrder;

  @Column({ type: 'varchar', length: 255, nullable: true })
  purchaseOrders: string;

  @OneToMany(
    () => RequisitionEntity,
    (requisition) => requisition.correctiveAction,
  )
  purchaseRequisitions: RequisitionEntity;

  @ManyToOne(() => Ship, (ship) => ship.correctiveActions)
  @JoinColumn({ name: 'shipId' })
  ship: Ship;

  @ManyToOne(
    () => NearMissReportEntity,
    (nearMissReport) => nearMissReport.correctiveAction,
    {
      onDelete: 'CASCADE',
    },
  )
  nearMissReport: NearMissReportEntity;
}
