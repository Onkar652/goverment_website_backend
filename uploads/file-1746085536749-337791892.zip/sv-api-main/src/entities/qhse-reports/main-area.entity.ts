import {
  Column,
  Entity,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { SubCategoryOfMainArea } from './larp-report-info.entity';
import { LarpReportEntity } from './larp-report.entity';

@Entity('main_area_of_concern')
export class MainAreaOfConcern {
  @PrimaryGeneratedColumn()
  id: number | string;

  @ManyToOne(
    () => LarpReportEntity,
    (larpReport) => larpReport.mainAreaOfConcern,
    {
      onDelete: 'CASCADE',
    },
  )
  larpReport: LarpReportEntity;

  @Column({ type: 'text', nullable: true })
  ppe: string;

  @Column({ type: 'text', nullable: true })
  ppeCategory: string;

  @OneToOne(
    () => SubCategoryOfMainArea,
    (ppeSubCategory) => ppeSubCategory.mainAreaOfConcern,
  )
  ppeSubCategory: SubCategoryOfMainArea;

  @Column({ type: 'text', nullable: true })
  permitWork: boolean;

  @Column({ type: 'text', nullable: true })
  permitWorkCategory: string;

  @Column({ type: 'text', nullable: true })
  workingEquipment: boolean;

  @Column({ type: 'text', nullable: true })
  houseKeeping: boolean;

  @Column({ type: 'text', nullable: true })
  workPosition: boolean;

  @Column({ type: 'text', nullable: true })
  safetyDevice: boolean;

  @Column({ type: 'text', nullable: true })
  workEnvironment: boolean;
}
