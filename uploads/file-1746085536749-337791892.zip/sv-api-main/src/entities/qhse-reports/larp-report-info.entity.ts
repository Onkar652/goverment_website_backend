import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { LarpReportEntity } from './larp-report.entity';
import { MainAreaOfConcern } from './main-area.entity';
import { Ship } from '../ships/ships.entity';

@Entity('larp_report_info')
export class LarpReportInfo {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'timestamp', nullable: true })
  dateOfOccurrence: string;

  @Column({ type: 'timestamp', nullable: true })
  timeOfOccurrence: string;

  @Column({ default: 'draft' })
  status: string;

  @Column({ type: 'text', nullable: true })
  reviewerName: string;

  @Column({ type: 'text', nullable: true })
  timeZone: string;

  @Column({ type: 'text', nullable: true })
  vesselName: string;

  @Column({ type: 'text', nullable: true })
  DisplayName: string;

  @Column({ type: 'text', nullable: true })
  Rank: boolean;

  @Column({ type: 'text', nullable: true })
  RName: string;

  @Column({ type: 'text', nullable: true })
  RRank: string;

  @OneToOne(() => LarpReportEntity, (larpReport) => larpReport.larpReportInfo)
  larpReport: LarpReportEntity;
}

@Entity('larp_report_details')
export class LastReportDetailsEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'text', nullable: true })
  larpCategory: string;

  @Column({ type: 'text', nullable: true })
  whatHappened: string;

  @Column({ type: 'text', nullable: true })
  activityObserved: string;

  @Column({ type: 'text', nullable: true })
  workStopped: boolean;

  @Column({ type: 'text', nullable: true })
  immediateCorrectiveAction: string;

  @Column({ type: 'text', nullable: true })
  potentialIncidentPrevent: string;

  @Column({ type: 'text', nullable: true })
  locationOfTheIncident: string;

  @ManyToOne(
    () => LarpReportEntity,
    (larpReport) => larpReport.mainAreaOfConcern,
    {
      onDelete: 'CASCADE',
    },
  )
  larpReport: LarpReportEntity;

  @ManyToOne(() => Ship, (ship) => ship.reports)
  @JoinColumn({ name: 'shipId' })
  ship: Ship;
}

@Entity('sub_category')
export class SubCategoryOfMainArea {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'text', nullable: true })
  code: number;

  @Column({ type: 'text', nullable: true })
  description: string;

  @ManyToOne(
    () => MainAreaOfConcern,
    (mainAreaOfConcern) => mainAreaOfConcern.larpReport,
    {
      cascade: true,
    },
  )
  mainAreaOfConcern: MainAreaOfConcern;
}
