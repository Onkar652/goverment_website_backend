import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { BunkerReportEntity } from '../bunker-reports/bunker-reports.entity';
import { CertificateSurveyEntity } from '../certifications/certificate-survey.entity';
import { CertificationEntity } from '../certifications/certification.entity';
import { CargoStabilityEntity } from '../postion-book-reports/cargo-stability.entity';
import { NearMissReportEntity } from '../qhse-reports/near-miss-report.entity';
import { RequisitionEntity } from '../requisitions/requisition.entity';
import { WorkOrder } from '../shipActions/work-order.entity';
import { VoyageEntity } from '../voyage/voyage.entity';
import { CorrectiveActionEntity } from '../qhse-reports/corrective-measure.entity';
import { PreventiveActionEntity } from '../qhse-reports/preventive-measure.entity';
import { LarpReportEntity } from '../qhse-reports/larp-report.entity';
import { BasePracticeReportEntity } from '../qhse-reports/base-practice.entity';

@Entity('file_storage')
export class FileStorageEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'bytea' })
  data: Buffer;

  @Column()
  mimeType: string;

  @Column()
  fileName: string;

  @ManyToOne(() => WorkOrder, (workOrder) => workOrder.otherDocuments)
  otherDocumentWorkOrder: WorkOrder;

  @ManyToOne(() => WorkOrder, (workOrder) => workOrder.jobPhotos)
  jobPhotoWorkOrder: WorkOrder;

  @ManyToOne(() => CertificationEntity, (certificate) => certificate.documents)
  certificate: CertificationEntity;

  @ManyToOne(() => CertificateSurveyEntity, (survey) => survey.documents)
  survey: CertificateSurveyEntity;

  @ManyToOne(() => RequisitionEntity, (requisition) => requisition.documents, {
    onDelete: 'CASCADE',
  })
  requisition: RequisitionEntity;

  @ManyToOne(() => VoyageEntity, (voyage) => voyage.attachments, {
    onDelete: 'CASCADE',
  })
  voyage: VoyageEntity;

  @ManyToOne(() => NearMissReportEntity, (report) => report.attachments, {
    onDelete: 'CASCADE',
  })
  nearMissReport: NearMissReportEntity;

  @ManyToOne(() => LarpReportEntity, (larpReport) => larpReport.attachments, {
    onDelete: 'CASCADE',
  })
  larpReport: LarpReportEntity;

  @ManyToOne(
    () => BasePracticeReportEntity,
    (basePractice) => basePractice.attachments,
    {
      onDelete: 'CASCADE',
    },
  )
  basePracticeReport: BasePracticeReportEntity;

  @ManyToOne(
    () => CorrectiveActionEntity,
    (corrective_measures) => corrective_measures.attachments,
    {
      onDelete: 'CASCADE',
    },
  )
  correctiveAction: CorrectiveActionEntity;

  @ManyToOne(
    () => PreventiveActionEntity,
    (preventiveAction) => preventiveAction.attachments,
  )
  preventiveAction: PreventiveActionEntity;

  @ManyToOne(() => CargoStabilityEntity, (cargo) => cargo.documents, {
    onDelete: 'CASCADE',
  })
  cargo: CargoStabilityEntity;

  @ManyToOne(() => BunkerReportEntity, (bunker) => bunker.attachments, {
    onDelete: 'CASCADE',
  })
  bunkerReport: BunkerReportEntity;

  @CreateDateColumn({ type: 'timestamp' })
  createdOn: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedOn: Date;
}
