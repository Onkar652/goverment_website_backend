import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { Ship } from '../ships/ships.entity';
import { User } from '../users/users.entity';

@Entity()
export class Client {
  @PrimaryGeneratedColumn('uuid')
  client_id: string;

  @Column()
  client_name: string;

  @Column()
  short_code: string;

  @Column({ default: false })
  disabled: boolean;

  @OneToMany(() => Ship, (ship) => ship.client)
  ships: Ship[];

  @OneToMany(() => User, (user) => user.client)
  users: User[];
}
