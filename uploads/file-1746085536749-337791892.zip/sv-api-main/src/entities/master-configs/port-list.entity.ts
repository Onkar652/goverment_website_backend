import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { ItineraryPortEntity } from '../voyage/itinerary-port.entity';

@Entity('port_list')
export class PortListEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 50, unique: true })
  code: string;

  @Column({ type: 'varchar', length: 255 })
  name: string;

  @Column({ type: 'varchar', length: 50 })
  countryRegionCode: string;

  @Column({ type: 'boolean' })
  euPort: boolean;

  @OneToMany(() => ItineraryPortEntity, (itineraryPort) => itineraryPort.port)
  itineraryPorts: ItineraryPortEntity[];
}
