import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('indirect_cause')
export class InDirectCauseEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  category: string;

  @Column()
  subcategory: string;

  @Column()
  descriptionOfInDirectCause: string;
}
