import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
@Entity('root_cause')
export class RootCauseEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  category: string;

  @Column({ nullable: true })
  subcategory: string;

  @Column({ nullable: true })
  rootCauseId: string;
}
