import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('direct_cause')
export class DirectCauseEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  category: string;

  @Column()
  subcategory: string;

  @Column()
  descriptionOfDirectCause: string;
}
