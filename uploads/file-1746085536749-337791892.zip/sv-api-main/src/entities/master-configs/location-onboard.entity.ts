import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { Ship } from '../ships/ships.entity';
@Entity('location_on_board')
export class LocationOnboardEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  locationOnboardId: string;

  @Column()
  name: string;

  @ManyToOne(() => Ship, (ship) => ship.locationOnBoard)
  @JoinColumn({ name: 'shipId' })
  ship: Ship;
}
