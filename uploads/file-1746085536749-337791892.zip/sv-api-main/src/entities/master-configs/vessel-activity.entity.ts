import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { Ship } from '../ships/ships.entity';
@Entity('vessel_activity')
export class VesselActivityEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  vesselActivityId: string;

  @Column()
  name: string;

  @ManyToOne(() => Ship, (ship) => ship.vesselActivity)
  @JoinColumn({ name: 'shipId' }) // Join column for the foreign key
  ship: Ship;
}
