import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('timezones')
export class TimezoneEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  timezone_id: string;

  @Column({ unique: true })
  name: string; // e.g., "India Standard Time"

  @Column({ type: 'float' })
  utcOffset: number; // e.g., 5.5 for "+05:30"

  @Column()
  description: string; // e.g., "(UTC+05:30) Chennai, Kolkata, Mumbai, New Delhi"
}
