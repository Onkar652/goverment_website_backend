import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Ship } from '../ships/ships.entity';
@Entity('vessel_location')
export class VesselLocationEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  vesselLocationId: string;

  @Column()
  name: string;

  @ManyToOne(() => Ship, (ship) => ship.vesselLocations)
  @JoinColumn({ name: 'shipId' })
  ship: Ship;
}
