import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Ship } from '../ships/ships.entity';
@Entity('incident_activity')
export class IncidentActivityEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  incidentActivityId: string;

  @Column({ nullable: true })
  name: string;

  @ManyToOne(() => Ship, (ship) => ship.incidentActivities)
  @JoinColumn({ name: 'shipId' })
  ship: Ship;
}
