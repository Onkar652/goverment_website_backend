import { Column, Entity, OneToOne, PrimaryGeneratedColumn } from 'typeorm';
import { NearMissReportEntity } from '../qhse-reports/near-miss-report.entity';
import { BasePracticeReportEntity } from '../qhse-reports/base-practice.entity';

@Entity('logs')
export class LogEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ nullable: true })
  createdBy?: string;

  @Column({ nullable: true })
  createdOn?: string;

  @Column({ nullable: true })
  lastModifiedBy?: string;

  @Column({ nullable: true })
  lastModifiedOn?: string;

  @Column({ nullable: true })
  closedBy?: string;

  @Column({ nullable: true })
  closedOn?: string;

  @OneToOne(() => BasePracticeReportEntity, { nullable: true })
  baseReport: BasePracticeReportEntity;

  @OneToOne(() => NearMissReportEntity, { nullable: true })
  nearMissReport: NearMissReportEntity;

  // @OneToOne(() => LarpReportEntity, { nullable: true })
  // larpReport: LarpReportEntity;
}
