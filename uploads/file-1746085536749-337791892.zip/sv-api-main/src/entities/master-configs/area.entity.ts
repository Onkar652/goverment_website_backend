import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { CorrectiveActionEntity } from '../qhse-reports/corrective-measure.entity';
import { PreventiveActionEntity } from '../qhse-reports/preventive-measure.entity';

@Entity('areas')
export class AreaEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @OneToMany(
    () => CorrectiveActionEntity,
    (correctiveMeasure) => correctiveMeasure.relatedAreaList,
  )
  correctiveAction: CorrectiveActionEntity;

  @OneToMany(
    () => PreventiveActionEntity,
    (preventiveMeasures) => preventiveMeasures.relatedAreaList,
  )
  preventiveMeasures: PreventiveActionEntity;
}
