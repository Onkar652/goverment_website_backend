import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { ItineraryPortEntity } from '../voyage/itinerary-port.entity';

@Entity('ports')
export class PortEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 255 })
  portName: string;

  @Column({ type: 'varchar', length: 50, unique: true })
  portCode: string;

  @Column({ type: 'varchar', length: 255 })
  country: string;

  @OneToMany(() => ItineraryPortEntity, (itineraryPort) => itineraryPort.port)
  itineraryPorts: ItineraryPortEntity[];
}
