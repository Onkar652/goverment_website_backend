import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export class LossType {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ default: false })
  isToggled: boolean;
}
