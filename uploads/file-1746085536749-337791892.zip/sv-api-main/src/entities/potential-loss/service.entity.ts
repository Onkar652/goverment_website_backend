import { Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn } from 'typeorm';
import { RiskPotentialEntity } from './potential-risk.entity';

@Entity('service')
export class Service {
  @PrimaryGeneratedColumn()
  id: number;

  @OneToOne(() => RiskPotentialEntity, { cascade: true })
  @JoinColumn()
  disruptionOfBusiness: RiskPotentialEntity;

  @OneToOne(() => RiskPotentialEntity, { cascade: true })
  @JoinColumn()
  regulatoryCompliance: RiskPotentialEntity;

  @OneToOne(() => RiskPotentialEntity, { cascade: true })
  @JoinColumn()
  reputationDamage: RiskPotentialEntity;
}
