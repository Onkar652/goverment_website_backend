import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('properties')
export class Property {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'text', nullable: true })
  incidentClassification: string;

  @Column({ type: 'text', nullable: true })
  incidentSubClassification: string;
}
