import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { NearMissReportEntity } from '../qhse-reports/near-miss-report.entity';
import { EnvironmentLossEntity } from './environment-loss.entity';
import { RiskPotentialEntity } from './potential-risk.entity';
import { Property } from './property.entity';
import { Service } from './service.entity';

export enum PotentialLossType {
  INJURY = 'injury',
  ENVIRONMENT = 'environment',
  SECURITY = 'security',
  PROPERTY = 'property',
  SERVICE = 'service',
}

@Entity('loss_potential')
export class LossPotentialEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'enum', enum: PotentialLossType })
  type: PotentialLossType;

  @OneToOne(() => RiskPotentialEntity, { nullable: true, cascade: true })
  @JoinColumn()
  potentialRisk: RiskPotentialEntity;

  @OneToMany(
    () => EnvironmentLossEntity,
    (environmentLoss) => environmentLoss.environment,
    { cascade: true },
  )
  environmentLosses: EnvironmentLossEntity[];

  @OneToOne(() => Property, { cascade: true, nullable: true })
  @JoinColumn()
  properties: Property;

  @OneToOne(() => Service, { cascade: true, nullable: true })
  @JoinColumn()
  services: Service;

  @ManyToOne(() => NearMissReportEntity, (report) => report.lossPotential, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'nearMissReportId' })
  nearMissReport: NearMissReportEntity;
}
