import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { LossPotentialEntity } from './potential-loss.entity';

@Entity('environment_loss')
export class EnvironmentLossEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(
    () => LossPotentialEntity,
    (environment) => environment.environmentLosses,
  )
  environment: LossPotentialEntity;

  @Column({ type: 'text', nullable: true })
  typeOfPollution: string;

  @Column({ type: 'text', nullable: true })
  environmentImpact: string;

  @Column({ type: 'boolean', nullable: true })
  isSpillage: boolean;

  @Column({ type: 'float', nullable: true })
  quantityOfSpillage: number;

  @Column({ type: 'text', nullable: true })
  remarks: string;
}
