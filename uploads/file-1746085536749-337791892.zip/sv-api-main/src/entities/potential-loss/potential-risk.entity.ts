import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('potential_risk')
export class RiskPotentialEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'text', nullable: true })
  likelihood: string;

  @Column({ type: 'text', nullable: true })
  consequence: string;

  @Column({ type: 'text', nullable: true })
  riskLevel: string;
}
