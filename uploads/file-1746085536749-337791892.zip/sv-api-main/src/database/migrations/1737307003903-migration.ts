import { MigrationInterface, QueryRunner } from "typeorm";

export class Migration1737307003903 implements MigrationInterface {
    name = 'Migration1737307003903'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "aquanova"."main_part" DROP CONSTRAINT "FK_3b074b17c110062d6afb9c64d49"`);
        await queryRunner.query(`CREATE TABLE "aquanova"."main_part_content_consumption" ("id" SERIAL NOT NULL, "previousConsumption" double precision DEFAULT '0', "currentConsumption" double precision DEFAULT '0', "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "main_part_id" integer, "content_id" integer, CONSTRAINT "PK_55bbc423e77f7b0bbef5eec8a54" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "aquanova"."main_part" DROP COLUMN "content_id"`);
        await queryRunner.query(`ALTER TABLE "aquanova"."content" ADD "density" double precision`);
        await queryRunner.query(`ALTER TABLE "aquanova"."main_part_content_consumption" ADD CONSTRAINT "FK_783878137419f1ba043a1c17ec8" FOREIGN KEY ("main_part_id") REFERENCES "aquanova"."main_part"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "aquanova"."main_part_content_consumption" ADD CONSTRAINT "FK_80cf4c3b84a2eb5ec2a4c96c8c9" FOREIGN KEY ("content_id") REFERENCES "aquanova"."content"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "aquanova"."main_part_content_consumption" DROP CONSTRAINT "FK_80cf4c3b84a2eb5ec2a4c96c8c9"`);
        await queryRunner.query(`ALTER TABLE "aquanova"."main_part_content_consumption" DROP CONSTRAINT "FK_783878137419f1ba043a1c17ec8"`);
        await queryRunner.query(`ALTER TABLE "aquanova"."content" DROP COLUMN "density"`);
        await queryRunner.query(`ALTER TABLE "aquanova"."main_part" ADD "content_id" integer`);
        await queryRunner.query(`DROP TABLE "aquanova"."main_part_content_consumption"`);
        await queryRunner.query(`ALTER TABLE "aquanova"."main_part" ADD CONSTRAINT "FK_3b074b17c110062d6afb9c64d49" FOREIGN KEY ("content_id") REFERENCES "aquanova"."content"("id") ON DELETE SET NULL ON UPDATE NO ACTION`);
    }

}
