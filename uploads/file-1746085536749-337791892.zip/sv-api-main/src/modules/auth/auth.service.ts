import {
  BadRequestException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { DataSource } from 'typeorm';
import { UserLoginDto } from './dto/login.dto';
import { RegisterUserDto } from './dto/register.dto';
import { UserDetails } from 'src/entities/users/user-details.entity';
import { UserRanksEntity } from 'src/entities/users/user-ranks.entity';
import { Client } from 'src/entities/client/client.entity';
import { UserRole } from 'src/entities/users/user-role.entity';
import { Ship } from 'src/entities/ships/ships.entity';
import { User } from 'src/entities/users/users.entity';

@Injectable()
export class AuthService {
  private userRepository;
  private userDetailsRepository;
  private clientRepository;
  private roleRepository;
  private rankRepository;
  private shipRepositiory;
  constructor(
    private readonly jwtService: JwtService,
    private readonly dataSource: DataSource,
  ) {
    this.userRepository = this.dataSource.getRepository(User);
    this.userDetailsRepository = this.dataSource.getRepository(UserDetails);
    this.clientRepository = this.dataSource.getRepository(Client);
    this.roleRepository = this.dataSource.getRepository(UserRole);
    this.rankRepository = this.dataSource.getRepository(UserRanksEntity);
    this.rankRepository = this.dataSource.getRepository(UserRanksEntity);
    this.shipRepositiory = this.dataSource.getRepository(Ship);
  }

  async login(userLoginDto: UserLoginDto) {
    const { username, password } = userLoginDto;
    const userDetailsRepository =
      await this.dataSource.getRepository(UserDetails);
    const userDetails = await userDetailsRepository.findOne({
      where: { email_id: username, active: true },
      relations: ['user', 'user.role', 'user.rank', 'ship'],
    });
    if (!userDetails) {
      throw new UnauthorizedException('Invalid credentials');
    }

    // Validate password
    const isPasswordValid = await bcrypt.compare(
      password,
      userDetails.password,
    );
    if (!isPasswordValid) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const payload = {
      sub: userDetails.user.id,
      email: userDetails.email_id,
      role: userDetails.user.role,
      rank: userDetails.user.rank,
      client: userDetails.user.client
        ? {
            name: userDetails.user.client.client_name,
            client_id: userDetails.user.client.client_id,
          }
        : null,
      ship: userDetails.ship
        ? {
            name: userDetails.ship.name,
            id: userDetails.ship.id,
          }
        : null,
    };
    const accessToken = this.jwtService.sign(payload, { expiresIn: '60m' });
    const refreshToken = this.jwtService.sign(payload, { expiresIn: '24h' });
    return {
      access_token: accessToken,
      refresh_token: refreshToken,
      user: {
        ...payload,
        id: userDetails.user.id,
        name: userDetails.user.name,
      },
    };
  }

  async registerNewUser(registerUserDto: RegisterUserDto) {
    const { name, email, password, roleId, rankId, clientId, shipId } =
      registerUserDto;

    const existingUser = await this.userDetailsRepository.findOne({
      where: { email_id: email, active: true },
    });

    if (existingUser) {
      throw new BadRequestException('Email already registered');
    }

    const rank = await this.rankRepository.findOne({
      where: {
        id: rankId,
      },
    });

    if (!rank) {
      throw new BadRequestException('Invalid rank ID');
    }

    const client = await this.clientRepository.findOne({
      where: { client_id: clientId },
    });
    if (!client) {
      throw new BadRequestException('Client not found');
    }
    const ship = await this.shipRepositiory.findOne({
      where: { id: shipId },
    });
    if (!ship) {
      throw new BadRequestException('Ship not found');
    }

    const role = await this.roleRepository.findOne({ where: { id: roleId } });
    if (!role) {
      throw new BadRequestException('Role not found');
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new User entity
    const newUser = this.userRepository.create({
      name,
      rank,
      onboarding_date: new Date(),
      client: client,
      role: role,
      disabled: false,
    });

    const savedUser = await this.userRepository.save(newUser);

    // Create associated UserDetails
    const userDetails = this.userDetailsRepository.create({
      user: savedUser,
      email_id: email,
      password: hashedPassword,
      ship: ship,
      active: true,
    });

    const savedUserDetails = await this.userDetailsRepository.save(userDetails);
    return {
      message: 'User registered Successfully',
      user: savedUserDetails,
    };
  }
}
