import { ApiProperty } from '@nestjs/swagger';
import {
  IsEmail,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  IsUUID,
  MinLength,
} from 'class-validator';

export class RegisterUserDto {
  @ApiProperty({
    example: 'John Doe',
    description: 'The name of the user',
  })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({
    example: 'john.doe@example.com',
    description: 'The email address of the user',
  })
  @IsEmail()
  @IsNotEmpty()
  email: string;

  @ApiProperty({
    example: 'password123',
    description: 'The password for the user account',
  })
  @IsString()
  @MinLength(6)
  @IsNotEmpty()
  password: string;

  @ApiProperty({
    example: 1,
    description: 'The ID of the rank assigned to the user',
  })
  @IsOptional()
  rankId?: number;

  @ApiProperty({
    example: 1,
    description: 'The ID of the role assigned to the user',
  })
  @IsNumber()
  @IsNotEmpty()
  roleId: number;

  @ApiProperty({
    example: 1,
    description: 'The ID of the ship assigned to the user',
  })
  @IsNumber()
  @IsNotEmpty()
  shipId: number; // Accepts ship ID

  @ApiProperty({
    example: '9e8c7e3c-d1a2-4d4f-bd68-e64d0f3e87b9',
    description: 'The ID of the client the user is assigned to',
  })
  @IsUUID()
  @IsNotEmpty()
  clientId: string;
}
