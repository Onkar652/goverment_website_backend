import { Body, Controller, HttpCode, HttpStatus, Post } from '@nestjs/common';
import { ApiBody, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { CustomResponse } from 'src/utils/dto/custom-response.dto';
import { AuthService } from './auth.service';
import { UserLoginDto } from './dto/login.dto';
import { RegisterUserDto } from './dto/register.dto';

@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('login')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Login and get access and refresh tokens' }) // Operation description
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Login success',
    type: CustomResponse, // Response type defined as DTO
  })
  @ApiResponse({
    status: HttpStatus.UNAUTHORIZED,
    description: 'Incorrect username or password',
  })
  @ApiBody({
    description: 'User login credentials',
    type: UserLoginDto, // Body type defined as DTO
  })
  async login(@Body() userLoginDto: UserLoginDto) {
    return this.authService.login(userLoginDto);
  }

  @Post('register')
  @ApiOperation({ summary: 'Register a new user' }) // Describes the operation
  @ApiResponse({ status: 200, description: 'User registered successfully' }) // Successful response
  @ApiResponse({ status: 409, description: 'User already exists' }) // Conflict response
  @ApiResponse({ status: 400, description: 'Invalid input' }) // Bad request response
  async register(@Body() registerUserDto: RegisterUserDto) {
    return await this.authService.registerNewUser(registerUserDto);
  }
}
