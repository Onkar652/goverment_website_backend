import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class InitiateLarpReportDTO {
  @ApiProperty({
    description: 'ID of the ship to associate with the larp report',
    example: 1,
  })
  @IsNotEmpty()
  @IsNumber()
  shipId: number;
}
