import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import {
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiQuery,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { BasePracticeReportEntity } from 'src/entities/qhse-reports/base-practice.entity';
import { BestPracticeReportService } from './base-practise-report.service';
import { CreateBasePracticeReportDto } from './dto/create-bp-report-dto';
import { InitiateBasePracticeReportDTO } from './dto/initiate-base-Practice-report.dto';
@Controller('base-practice-report')
@ApiTags('BasePracticeReport')
export class BestPracticeReportController {
  constructor(
    private readonly bestPracticeReportService: BestPracticeReportService,
  ) {}

  @ApiOperation({
    summary:
      'Initiate a Base Practice report and generate a BasePracticeReportCode',
  })
  @ApiResponse({
    status: 201,
    description: 'Base Practice Report initiated successfully',
  })
  @ApiBody({
    description:
      'Ship ID for which the Base Practice report is being initiated',
    schema: {
      type: 'object',
      properties: {
        shipId: {
          type: 'integer',
          description: 'ID of the ship',
          example: 1,
        },
      },
    },
  })
  @Post('/initiate-base-practice-report')
  async initiateBasePracticeReport(
    @Body() initiateBasePracticeReportDTO: InitiateBasePracticeReportDTO,
  ): Promise<CreateBasePracticeReportDto> {
    return await this.bestPracticeReportService.initiateBasePracticeReport(
      initiateBasePracticeReportDTO,
    );
  }

  @Get()
  @ApiOperation({ summary: 'Get a list of base Practice reports' })
  @ApiResponse({
    status: 200,
    description: 'List of base Practice reports with pagination details',
    schema: {
      type: 'object',
      properties: {
        data: {
          type: 'array',
          items: { $ref: '#/components/schemas/Re' },
        },
        total: {
          type: 'number',
          description:
            'Total number of base Practice reports matching the query',
        },
      },
    },
  })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship to filter base Practice reports by',
    example: 1,
  })
  @ApiQuery({
    name: 'status',
    required: false,
    type: String,
    description:
      'Filter base Practice reports by their status (e.g., active, draft)',
    example: 'active',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    type: Number,
    description: 'The page number for pagination',
    example: 1,
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    description: 'The number of base Practice reports to return per page',
    example: 10,
  })
  async getReports(
    @Query('shipId') shipId: number,
    @Query('status') status?: string,
    @Query('page') page = 1,
    @Query('limit') limit = 10,
  ) {
    if (!shipId) {
      throw new BadRequestException('shipId is required');
    }
    return await this.bestPracticeReportService.getBasePracticeReports({
      shipId,
      status,
      page,
      limit,
    });
  }

  @Get(':basePracticeReportId')
  @ApiOperation({ summary: 'Get base Practice report details by ID' })
  @ApiResponse({
    status: 200,
    description: 'base Practice Report details',
    type: BasePracticeReportEntity,
  })
  @ApiResponse({ status: 404, description: 'base Practice Report not found' })
  async getReportById(
    @Param('basePracticeReportId') basePracticeReportId: string,
  ): Promise<BasePracticeReportEntity> {
    return await this.bestPracticeReportService.getBasePracticeReportById(
      basePracticeReportId,
    );
  }

  @Post('/save-draft')
  @ApiOperation({ summary: 'Update Base Practice report details' })
  @ApiResponse({
    status: 200,
    description: 'Base Practice Report updated successfully',
    type: BasePracticeReportEntity,
  })
  @ApiResponse({ status: 404, description: 'Base Practice Report not found' })
  async saveReport(
    @Body() createBasePracticeReportDto: CreateBasePracticeReportDto,
  ) {
    return await this.bestPracticeReportService.saveBasePracticeReport(
      createBasePracticeReportDto,
    );
  }

  @Post(':basePracticeReportId/attachments')
  @UseInterceptors(FilesInterceptor('files'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Upload multiple attachments for a Base Practice Report',
    schema: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  async uploadAttachmentsForBasePracticeReport(
    @Param('basePracticeReportId') basePracticeReportId: string,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<{
    message: string;
    attachments: { fileId: string; fileName: string; mimeType: string }[];
  }> {
    const attachments =
      await this.bestPracticeReportService.uploadAttachmentsForBasePracticeReport(
        basePracticeReportId,
        files,
      );
    return { message: 'Attachments uploaded successfully', attachments };
  }
}
