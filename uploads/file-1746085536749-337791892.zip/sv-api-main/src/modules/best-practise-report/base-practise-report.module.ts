import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { LogEntity } from 'src/entities/master-configs/log.entity';
import { BasePracticeReportEntity } from 'src/entities/qhse-reports/base-practice.entity';
import { ShipValidationService } from '../common/ship-validation.service';
import { BestPracticeReportController } from './base-practise-report.controller';
import { BestPracticeReportService } from './base-practise-report.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      BasePracticeReportEntity,
      LogEntity,
      FileStorageEntity,
    ]),
  ],
  controllers: [BestPracticeReportController],
  providers: [BestPracticeReportService, ShipValidationService],
  exports: [BestPracticeReportService],
})
export class BestPracticeReportModule {}
