import {
  BadRequestException,
  ConflictException,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { LogEntity } from 'src/entities/master-configs/log.entity';
import { BasePracticeReportEntity } from 'src/entities/qhse-reports/base-practice.entity';
import { CertificateStatus } from 'src/utils/models/common.types';
import { DataSource, EntityManager, Repository } from 'typeorm';
import { ShipValidationService } from '../common/ship-validation.service';
import { CreateBasePracticeReportDto } from './dto/create-bp-report-dto';
import { LogEntityDto } from './dto/create-log.dto';
import { InitiateBasePracticeReportDTO } from './dto/initiate-base-Practice-report.dto';

@Injectable()
export class BestPracticeReportService {
  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FileStorageEntity)
    private readonly fileStorageRepository: Repository<FileStorageEntity>,
    @InjectRepository(BasePracticeReportEntity)
    private readonly basePracticeReportRepository: Repository<BasePracticeReportEntity>,
    private shipValidationService: ShipValidationService,
  ) {}

  async initiateBasePracticeReport(
    queryParams: InitiateBasePracticeReportDTO,
  ): Promise<CreateBasePracticeReportDto> {
    const { shipId } = queryParams;
    if (!shipId) {
      throw new BadRequestException('Ship ID is missing');
    }
    // Validate Ship
    console.log('ndvsksdvknksdv');
    const ship = await this.shipValidationService.getShipById(shipId);
    // console.log('snnkvsankjsav', ship);
    const existingDraft = await this.basePracticeReportRepository.findOne({
      where: { ship: { id: shipId }, status: CertificateStatus.Draft },
    });

    if (existingDraft) {
      throw new ConflictException(
        `There is already a draft report in progress. Please complete it before creating a new one.`,
      );
    }
    // Generate a unique base Practice report ID
    const basePracticeReportId = await this.generateBasePracticeReportCode(
      ship.code,
      ship.id,
    );

    // Create the report
    const draftBasePracticeReport = this.basePracticeReportRepository.create({
      basePracticeReportId,
      ship,
      status: 'Draft',
      timeZone: null,
      reportedDate: null,
      reportTitle: null,
      reviewerName: null,
      comment: null,
      description: null,
      vesselLocationForBP: null,
      vesselLocationForSF: null,
      name: null,
      department: null,
      categoriesOfBPorSFI: null,
      bestPracticeAdoptedDate: null,
      bestPracticeSuggestedBy: null,
      bestPracticeIdentifiedFrom: null,
    });

    const savedReport = await this.basePracticeReportRepository.save(
      draftBasePracticeReport,
    );

    return {
      ...savedReport,
      shipId: savedReport.ship.id,
      basePracticeReportId: savedReport.basePracticeReportId,
    };
  }

  async saveBasePracticeReport(
    createBasePracticeReportDto: CreateBasePracticeReportDto,
  ) {
    const { basePracticeReportId, shipId } = createBasePracticeReportDto;

    // Validate Base Practice Report ID
    if (!basePracticeReportId) {
      throw new BadRequestException(
        'BP Report ID is required for updating a report.',
      );
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Find the existing base practice report by ID
      const basePracticeReport =
        await this.basePracticeReportRepository.findOne({
          where: { basePracticeReportId },
          relations: ['attachments', 'ship', 'logs'],
        });

      if (!basePracticeReport) {
        throw new NotFoundException(
          `Report with ID ${basePracticeReportId} not found.`,
        );
      }

      // If shipId exists in DTO, we need to find the ship and assign it
      if (shipId) {
        const ship = await this.shipValidationService.getShipById(shipId);
        if (!ship) {
          throw new NotFoundException('Ship not found');
        }
        basePracticeReport.ship = ship; // Update ship relation
      }

      // Handle other fields from DTO and update the report
      const updatedReport = await this.handleBaseReport(
        basePracticeReport,
        createBasePracticeReportDto,
        queryRunner.manager,
      );

      // Save the updated report
      await queryRunner.manager.save(BasePracticeReportEntity, updatedReport);

      // Commit the transaction
      await queryRunner.commitTransaction();

      return updatedReport;
    } catch (error) {
      // Rollback transaction on error
      await queryRunner.rollbackTransaction();
      throw new InternalServerErrorException(
        `Failed to update report: ${error.message}`,
      );
    } finally {
      // Release query runner
      await queryRunner.release();
    }
  }

  private async handleBaseReport(
    baseReport: BasePracticeReportEntity,
    baseReportDto: CreateBasePracticeReportDto,
    manager: EntityManager,
  ): Promise<BasePracticeReportEntity> {
    const updatedReport = this.basePracticeReportRepository.merge(
      baseReport,
      baseReportDto,
    );

    const savedReport = await manager.save(
      BasePracticeReportEntity,
      updatedReport,
    );
    if (baseReportDto.logs) {
      await this.saveLog(savedReport, baseReportDto.logs, manager);
    }
    return savedReport;
  }

  private async saveLog(
    baseReport: BasePracticeReportEntity,
    log: LogEntityDto,
    manager: EntityManager,
  ) {
    await manager.delete(LogEntity, {
      baseReport: { id: baseReport.id },
    });

    const newLog = manager.create(LogEntity, log);
    newLog.baseReport = baseReport;
    const savedLog = await manager.save(newLog);
    baseReport.logs = savedLog;
    await manager.save(baseReport);
  }

  async generateBasePracticeReportCode(
    shipCode: string,
    shipId: number,
  ): Promise<string> {
    const currentYear = new Date().getFullYear().toString().slice(-2); // Get last two digits of the current year

    // Find the latest report for the given ship, sorted by basePracticeReportId in descending order
    let shipMetadata = await this.basePracticeReportRepository.findOne({
      where: {
        ship: { id: shipId },
      },
    });

    // Calculate the next serial number based on the latest report (or start with 1 if none exists)
    if (!shipMetadata) {
      shipMetadata = this.basePracticeReportRepository.create({
        ship: { id: shipId },
        serialNumber: 1, // Starting serial number
      });
      await this.basePracticeReportRepository.save(shipMetadata);
    } else {
      // Increment the serial number
      shipMetadata.serialNumber += 1;
      await this.basePracticeReportRepository.save(shipMetadata); // Save the updated serial number
    }
    // Format the serial number to be 4 digits and generate the unique larp report ID
    const paddedSerial = shipMetadata.serialNumber.toString().padStart(4, '0');
    const uniqueId = `BP-${shipCode}-${currentYear}${paddedSerial}`;

    return uniqueId;
  }

  async getBasePracticeReports(query: {
    shipId: number;
    status?: string;
    page: number;
    limit: number;
  }) {
    const { shipId, status, page = 1, limit = 10 } = query;

    const ship = await this.shipValidationService.getShipById(shipId);

    const queryBuilder = this.basePracticeReportRepository
      .createQueryBuilder('base_practice_report')
      .where('base_practice_report.shipId = :shipId', { shipId: ship.id });

    if (status) {
      queryBuilder.andWhere('base_practice_report.status = :status', {
        status,
      });
    }

    const [data, total] = await queryBuilder
      .orderBy('base_practice_report.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return { data, total };
  }

  async getBasePracticeReportById(
    basePracticeReportId: string,
  ): Promise<BasePracticeReportEntity> {
    const basePracticeReport = await this.basePracticeReportRepository
      .createQueryBuilder('base_practice_report')
      .leftJoinAndSelect('base_practice_report.ship', 'ship')
      .leftJoin('base_practice_report.logs', 'logs')
      .leftJoin('base_practice_report.attachments', 'attachments')
      .addSelect([
        'attachments.id',
        'attachments.fileName',
        'attachments.mimeType',
        'attachments.createdOn',
      ])
      .addSelect([
        'logs.createdBy',
        'logs.createdOn',
        'logs.lastModifiedBy',
        'logs.lastModifiedOn',
        'logs.closedBy',
        'logs.closedOn',
      ])
      .where(
        'base_practice_report.basePracticeReportId = :basePracticeReportId',
        { basePracticeReportId },
      )
      .getOne();

    if (!basePracticeReport) {
      throw new NotFoundException(
        `BP Report with ID ${basePracticeReportId} not found.`,
      );
    }

    return basePracticeReport;
  }

  async uploadAttachmentsForBasePracticeReport(
    basePracticeReportId: string,
    files: Express.Multer.File[],
  ): Promise<{ fileId: string; fileName: string; mimeType: string }[]> {
    const basePracticeReport = await this.basePracticeReportRepository.findOne({
      where: { basePracticeReportId },
    });

    if (!basePracticeReport) {
      throw new NotFoundException(
        `Base Practice Report with ID ${basePracticeReportId} not found.`,
      );
    }

    const attachments = files.map((file) =>
      this.fileStorageRepository.create({
        data: file.buffer,
        mimeType: file.mimetype,
        fileName: file.originalname,
        basePracticeReport,
      }),
    );

    const savedAttachments = await this.fileStorageRepository.save(attachments);

    return savedAttachments.map((file) => ({
      fileId: file.id,
      fileName: file.fileName,
      mimeType: file.mimeType,
    }));
  }
}
