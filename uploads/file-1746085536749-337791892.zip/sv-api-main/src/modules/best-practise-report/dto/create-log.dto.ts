import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsOptional, IsString } from 'class-validator';

export class LogEntityDto {
  @ApiProperty({
    description: 'Name of the user who created the log',
    example: 'John Doe',
    required: false,
  })
  @IsOptional()
  @IsString()
  createdBy?: string;

  @ApiProperty({
    description: 'Date when the log was created',
    example: '2025-02-13T10:00:00Z',
    required: false,
  })
  @IsOptional()
  @IsDateString()
  createdOn?: string;

  @ApiProperty({
    description: 'Name of the user who last modified the log',
    example: 'Jane Smith',
    required: false,
  })
  @IsOptional()
  @IsString()
  lastModifiedBy?: string;

  @ApiProperty({
    description: 'Date when the log was last modified',
    example: '2025-02-14T12:00:00Z',
    required: false,
  })
  @IsOptional()
  @IsDateString()
  lastModifiedOn?: string;

  @ApiProperty({
    description: 'Name of the user who closed the log',
    example: 'James Lee',
    required: false,
  })
  @IsOptional()
  @IsString()
  closedBy?: string;

  @ApiProperty({
    description: 'Date when the log was closed',
    example: '2025-02-15T14:00:00Z',
    required: false,
  })
  @IsOptional()
  @IsDateString()
  closedOn?: string;
}
