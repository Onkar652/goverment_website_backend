import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class InitiateBasePracticeReportDTO {
  @ApiProperty({ example: 1 })
  @IsNotEmpty()
  @IsNumber()
  shipId: number;
}
