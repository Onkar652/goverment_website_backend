import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsDateString,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { GetBunkerReportDto } from 'src/modules/bunker-report/dto/get-bunker-report.dto';
import { LogEntityDto } from './create-log.dto';

export class CreateBasePracticeReportDto {
  @ApiProperty({
    description:
      'Unique identifier for the base practice report (auto-generated)',
    example: 'BP-1234',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  basePracticeReportId?: string; //1

  @ApiProperty({
    description: 'ID of the ship associated with the voyage',
    example: 1,
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsNumber()
  shipId?: number; //2

  @ApiProperty({
    description: 'Status of the certificate for the Base Practice Report',
    example: 'Draft',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  status?: string = 'Draft'; //11

  @ApiProperty({
    description: 'Location of the vessel when the Base Practice was recorded',
    example: 'Port of Rotterdam',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  vesselLocation?: string; //3

  @ApiProperty({
    description: 'Name of the person or entity submitting the report',
    example: 'John Doe',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  name?: string; //4

  @ApiProperty({
    description: 'Department responsible for submitting the report',
    example: 'Safety Department',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  department?: string; //5

  @ApiProperty({
    description: 'Time zone of the vessel',
    example: 'UTC',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  timeZone?: string; //12

  @ApiProperty({
    description: 'Date when the report was created or submitted',
    example: '2025-02-11T10:00:00Z',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsDateString()
  reportedDate?: string; //

  @ApiProperty({
    description: 'Title of the report',
    example: 'Best Practice Report',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  reportTitle?: string; //

  @ApiProperty({
    description: 'Name of the reviewer',
    example: 'John Doe',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  reviewerName?: string; //

  @ApiProperty({
    description: 'Categories of best practices for the report',
    example: 'Safety, Maintenance',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  categoriesOfBP?: string; //5

  @ApiProperty({
    description: 'Categories of best practices for the report',
    example: 'Safety, Maintenance',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  bestPracticeAdoptedDate?: string; //6

  @ApiProperty({
    description: 'Name of the person suggesting the best practice',
    example: 'Jane Smith',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  bestPracticeSuggestedBy?: string; //7

  @ApiProperty({
    description: 'Source from which the best practice was identified',
    example: 'Industry Standards',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  bestPracticeIdentifiedFrom?: string; //8

  @ApiProperty({
    description: 'Detailed description of the best practice',
    example: 'This is a practice to improve vessel safety.',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  description?: string; //9

  @ApiProperty({
    description: 'Serial number of the report',
    example: 1,
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsNumber()
  serialNumber?: number; //9

  @ApiProperty({
    description: 'Additional comments about the best practice',
    example: 'This practice should be implemented on all vessels.',
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @IsString()
  comment?: string; //10

  @ApiProperty({
    description: 'Log associated with the base report',
    type: LogEntityDto,
    required: false, // Mark as optional
  })
  @IsOptional() // Make optional
  @ValidateNested()
  @Type(() => LogEntityDto)
  logs?: LogEntityDto;
}
export class getBasePracticeReportDto extends GetBunkerReportDto {}

export class queryBasePracticeReport {
  @ApiProperty({
    description: 'ID of the ship to associate with the larp report',
    example: 1,
  })
  @IsNotEmpty()
  @IsNumber()
  shipId: number;
}
