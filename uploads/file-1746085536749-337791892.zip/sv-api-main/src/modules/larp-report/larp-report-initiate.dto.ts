import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsNumber } from 'class-validator';
import { CertificateStatus } from 'src/utils/models/common.types';

export class InitiateLarpReportDTO {
  @ApiProperty({
    description: 'ID of the ship to associate with the larp report',
    example: 1,
  })
  @IsNotEmpty()
  @IsNumber()
  shipId: number;

  @ApiProperty({
    description: 'Status of the certificate for the Base Practice Report',
    enum: CertificateStatus,
    example: CertificateStatus.Draft,
  })
  @IsEnum(CertificateStatus)
  status: CertificateStatus;
}
