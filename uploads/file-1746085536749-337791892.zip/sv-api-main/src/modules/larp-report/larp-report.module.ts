import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LarpReportEntity } from 'src/entities/qhse-reports/larp-report.entity';
import {
  LarpReportInfo,
  LastReportDetailsEntity,
  SubCategoryOfMainArea,
} from 'src/entities/qhse-reports/larp-report-info.entity';
import { MainAreaOfConcern } from 'src/entities/qhse-reports/main-area.entity';
import { LarpReportController } from './larp-report.controller';
import { LarpReportService } from './larp-report.service';
import { ShipValidationService } from '../common/ship-validation.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      LarpReportEntity,
      LarpReportInfo,
      LastReportDetailsEntity,
      MainAreaOfConcern,
      SubCategoryOfMainArea,
    ]),
  ],
  controllers: [LarpReportController],
  providers: [LarpReportService, ShipValidationService],
  exports: [LarpReportService],
})
export class LarpReportModule {}
