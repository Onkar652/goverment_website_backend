import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsBoolean,
  IsDateString,
  IsNumber,
  IsObject,
  IsOptional,
  IsString,
} from 'class-validator';
import { GetBunkerReportsDto } from 'src/modules/bunker-report/dto/get-bunker-reports.dto';
import { CreateCauseAnalysisDto } from 'src/modules/near-miss-report/dto/initiate-near-miss-report.dto';

export class MainAreaOfConcernDto {}

export class LarpReportInfoDto {
  @IsOptional()
  @IsDateString()
  dateOfOccurrence: string;

  @IsOptional()
  @IsDateString()
  timeOfOccurrence: string;

  @IsOptional()
  @IsString()
  status: string;

  @IsOptional()
  @IsString()
  reviewerName: string;

  @IsOptional()
  @IsString()
  timeZone: string;

  @IsOptional()
  @IsString()
  vesselName: string;

  @IsOptional()
  @IsString()
  displayName: string;

  @IsOptional()
  @IsString()
  rank: string;

  @IsOptional()
  @IsString()
  rName: string;

  @IsOptional()
  @IsString()
  rRank: string;
}

export class LarpReportDetailsDto {
  @IsOptional()
  @IsString()
  larpCategory: string;

  @IsOptional()
  @IsString()
  whatHappened: string;

  @IsOptional()
  @IsString()
  activityObserved: string;

  @IsOptional()
  @IsBoolean()
  workStopped: boolean;

  @IsOptional()
  @IsString()
  immediateCorrectiveAction: string;

  @IsOptional()
  @IsString()
  potentialIncidentPrevent: string;

  @IsOptional()
  @IsString()
  locationOfTheIncident: string;

  @IsOptional()
  shipId: number;
}

export class CreateLarpReportDto {
  @ApiProperty({
    description: 'ID of the ship associated with the larp report',
    example: 1,
  })
  @IsOptional()
  @IsNumber()
  shipId?: number;

  @ApiPropertyOptional({
    description: 'Status of the report',
    example: 'draft',
  })
  @IsOptional()
  @IsString()
  status?: string = 'Draft';

  @ApiProperty({
    description: 'page of the ship associated with the larp report',
    example: '1',
  })
  @IsOptional()
  @IsNumber()
  page?: number;

  @ApiProperty({
    description: 'limit of the ship associated with the larp report',
    example: '10',
  })
  @IsOptional()
  @IsNumber()
  limit?: number;

  @ApiProperty({
    description: 'Unique identifier for the incident report (auto-generated)',
    example: 'INC-ARK-32001',
  })
  @IsString()
  larpReportId: string;

  @ApiProperty({
    description: 'Serial number of the report',
    example: 1,
  })
  @IsOptional()
  @IsNumber()
  serialNumber?: number;

  @ApiProperty({
    description: 'Title of the report',
    example: 'Collision Report',
  })
  @IsString()
  reportTitle: string;

  @ApiProperty({
    description: 'Location onboard the vessel where the incident occurred',
    example: 'Deck 5',
  })
  @IsString()
  locationOnboard: string;

  @ApiProperty({
    description: 'Target completion date for the report',
    example: '2025-02-28',
  })
  @IsOptional()
  @IsDateString()
  targetCompletionDate: Date;

  @ApiProperty({
    description: 'Incident date',
    example: '2025-01-15',
  })
  @IsOptional()
  @IsDateString()
  incidentDate: Date;

  @ApiProperty({
    description: 'Incident time',
    example: '14:30:00',
  })
  @IsOptional()
  @IsString()
  incidentTime: string;

  @ApiProperty({
    description: 'Vessel activity at the time of the incident',
    example: 'Navigating through the channel',
  })
  @IsOptional()
  @IsString()
  vesselActivity: string;

  @ApiProperty({
    description: 'Location of the vessel',
    example: 'Port of Singapore',
  })
  @IsString()
  vesselLocation: string;

  @ApiProperty({
    description: 'Current status of the vessel',
    example: 'Underway',
  })
  @IsString()
  vesselStatus: string;

  @ApiProperty({
    description: 'Timezone associated with the report',
    example: 'Asia/Kolkata',
  })
  @IsString()
  timezone: string;

  @ApiProperty({
    description: 'Activity at the time of the incident',
    example: 'Preparing to dock',
  })
  @IsOptional()
  @IsString()
  activityAtTimeOfIncident: string;

  @ApiProperty({
    description: 'Activity at the time of the incident',
    example: 'Preparing to dock',
  })
  @IsOptional()
  @IsString()
  causeAnalysisDto?: CreateCauseAnalysisDto;

  @ApiProperty({
    description: 'ID of the related LARP Report Info entity',
    example: '12345',
  })
  @IsOptional()
  @IsObject()
  larpReportInfoDto?: LarpReportInfoDto;

  @ApiProperty({
    description: 'corrective Actions',
    example: 'Preparing to Actions',
  })
  @IsOptional()
  @IsObject()
  mainAreaOfConcernDto?: MainAreaOfConcernDto;

  @ApiProperty({
    description: 'ID of the related LARP Report details entity',
    example: '12345',
  })
  @IsOptional()
  @IsObject()
  larpReportDetailsDto?: LarpReportDetailsDto;
}

export class getLarpReportDto extends GetBunkerReportsDto {}

export class SubCategoryOfMainAreaDto {
  @IsOptional()
  @IsNumber()
  code: number;

  @IsOptional()
  @IsString()
  description: string;

  @IsOptional()
  mainAreaOfConcernId: number;
}
