import {
  BadRequestException,
  HttpStatus,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { CauseAnalysisEntity } from 'src/entities/qhse-reports/cause-analysis.entity';
import {
  LarpReportInfo,
  LastReportDetailsEntity,
} from 'src/entities/qhse-reports/larp-report-info.entity';
import { LarpReportEntity } from 'src/entities/qhse-reports/larp-report.entity';
import { MainAreaOfConcern } from 'src/entities/qhse-reports/main-area.entity';
import { ShipValidationService } from 'src/modules/common/ship-validation.service';
import { DataSource, EntityManager, Repository } from 'typeorm';
import {
  CreateLarpReportDto,
  LarpReportDetailsDto,
  LarpReportInfoDto,
  MainAreaOfConcernDto,
} from './dto/create-larp-report-dto';
import { ReportStatus } from '../position-reports/dto/save-content-report.dto';
import { CreateCauseAnalysisDto } from '../near-miss-report/dto/initiate-near-miss-report.dto';

@Injectable()
export class LarpReportService {
  private larpReportRepository: Repository<LarpReportEntity>;
  private fileStorageRepository: Repository<FileStorageEntity>;
  private causeAnalysisRepository: Repository<CauseAnalysisEntity>;
  private larpReportInfoRepository: Repository<LarpReportInfo>;
  private larpReportDetailsRepository: Repository<LastReportDetailsEntity>;
  private mainAreaOfConcernRepository: Repository<MainAreaOfConcern>;
  constructor(
    private readonly dataSource: DataSource,
    private shipValidationService: ShipValidationService,
  ) {
    this.larpReportRepository = this.dataSource.getRepository(LarpReportEntity);
    this.fileStorageRepository =
      this.dataSource.getRepository(FileStorageEntity);
    this.causeAnalysisRepository =
      this.dataSource.getRepository(CauseAnalysisEntity);
    this.larpReportInfoRepository =
      this.dataSource.getRepository(LarpReportInfo);
    this.larpReportDetailsRepository = this.dataSource.getRepository(
      LastReportDetailsEntity,
    );
    this.mainAreaOfConcernRepository =
      this.dataSource.getRepository(MainAreaOfConcern);
  }

  async initiateLarpReport(
    shipId: number,
  ): Promise<Partial<CreateLarpReportDto>> {
    //validate Ship
    const ship = await this.shipValidationService.getShipById(shipId);
    // Generate a unique larp report ID
    const LarpReportCode = await this.generateLarpReportCode(
      ship.code,
      ship.id,
    );
    const mainAreaOfConcern = await this.mainAreaOfConcernRepository.create({
      larpReport: null,
      ppe: null,
      ppeCategory: null,
      ppeSubCategory: null,
      permitWork: null,
      permitWorkCategory: null,
      workingEquipment: null,
      houseKeeping: null,
      workPosition: null,
      safetyDevice: null,
      workEnvironment: null,
    });
    // Create a larp report with default values
    const draftLarPReport = this.larpReportRepository.create({
      larpReportId: LarpReportCode,
      ship,
      status: ReportStatus.DRAFT,
      attachments: null,
      causeAnalysis: null,
      larpReportInfo: null,
      larpReportDetails: null,
      mainAreaOfConcern,
    });

    // Save and return the report
    const savedReport = await this.larpReportRepository.save(draftLarPReport);
    // Update the report with the newly created entities
    await this.larpReportRepository.save(savedReport);

    return {
      ...savedReport,
      shipId: savedReport.ship.id,
      larpReportId: savedReport.larpReportId,
    };
  }

  private async saveCauseAnalysis(
    causeAnalysisDto: CreateCauseAnalysisDto,
    report: LarpReportEntity,
    manager: EntityManager,
  ) {
    let causeAnalysis = report.causeAnalysis;

    if (causeAnalysis) {
      // Merge the updated values
      this.causeAnalysisRepository.merge(causeAnalysis, causeAnalysisDto);
    } else {
      // Create a new cause analysis if it doesn't exist
      causeAnalysis = this.causeAnalysisRepository.create({
        ...causeAnalysisDto,
        nearMissReport: report, // Link the cause analysis to the report
      });
    }

    // Save the cause analysis entity
    const savedCauseAnalysis = await manager.save(
      CauseAnalysisEntity,
      causeAnalysis,
    );

    // Update the report's causeAnalysis reference
    report.causeAnalysis = savedCauseAnalysis;
    await manager.save(LarpReportEntity, report);

    return savedCauseAnalysis;
  }
  private async saveLarpReportInfo(
    larpReportInfoDto: LarpReportInfoDto,
    report: LarpReportEntity,
    manager: EntityManager,
  ) {
    let larpReportInfo = report.larpReportInfo;

    if (larpReportInfoDto) {
      // Merge the updated values
      this.larpReportInfoRepository.merge(larpReportInfo, larpReportInfoDto);
    } else {
      // Create a new cause analysis if it doesn't exist
      larpReportInfo = this.larpReportInfoRepository.create({
        ...larpReportInfo,
        larpReport: report, // Link the cause analysis to the report
      });
    }

    // Save the cause analysis entity
    const saveLarpReportInfo = await manager.save(
      LarpReportEntity,
      larpReportInfo,
    );

    // Update the report's causeAnalysis reference
    report.larpReportInfo = saveLarpReportInfo;
    await manager.save(LarpReportEntity, report);

    return saveLarpReportInfo;
  }
  private async saveLarpReportDetails(
    larpReportDetailsDto: LarpReportDetailsDto,
    report: LarpReportEntity,
    manager: EntityManager,
  ) {
    let larpReportDetails = report.larpReportDetails;

    if (larpReportDetailsDto) {
      // Merge the updated values
      this.larpReportDetailsRepository.merge(
        larpReportDetails,
        larpReportDetailsDto,
      );
    } else {
      // Create a new cause analysis if it doesn't exist
      larpReportDetails = this.larpReportDetailsRepository.create({
        ...larpReportDetails,
        larpReport: report, // Link the cause analysis to the report
      });
    }

    // Save the cause analysis entity
    const saveLarpReportDetails = await manager.save(
      LarpReportEntity,
      larpReportDetails,
    );

    // Update the report's causeAnalysis reference
    report.larpReportDetails = saveLarpReportDetails;
    await manager.save(LarpReportEntity, report);

    return saveLarpReportDetails;
  }
  private async saveMainAreaOfConcern(
    mainAreaOfConcernDTO: MainAreaOfConcernDto,
    report: LarpReportEntity,
    manager: EntityManager,
  ) {
    let mainAreaOfConcern = report.mainAreaOfConcern;

    if (mainAreaOfConcernDTO) {
      // Merge the updated values
      this.mainAreaOfConcernRepository.merge(
        mainAreaOfConcern,
        mainAreaOfConcernDTO,
      );
    } else {
      // Create a new cause analysis if it doesn't exist
      mainAreaOfConcern = this.mainAreaOfConcernRepository.create({
        ...mainAreaOfConcern,
        larpReport: report, // Link the cause analysis to the report
      });
    }

    // Save the cause analysis entity
    const saveMainAreaOfConcern = await manager.save(
      MainAreaOfConcern,
      mainAreaOfConcern,
    );

    // Update the report's causeAnalysis reference
    report.mainAreaOfConcern = saveMainAreaOfConcern;
    await manager.save(MainAreaOfConcern, report);

    return saveMainAreaOfConcern;
  }

  async saveLarpReport(
    createLarpReportDto: CreateLarpReportDto,
  ): Promise<{ status: HttpStatus; message: string }> {
    const { larpReportId } = createLarpReportDto;
    if (!larpReportId) {
      throw new BadRequestException(
        'LARP Report ID is required for updating a report.',
      );
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Fetch the existing report
      const larpReport = await this.larpReportRepository.findOne({
        where: { larpReportId },
        relations: [
          'cause_Analysis',
          'larp_report_info',
          'larp_report_details',
          'main_area_of_concern',
        ],
      });

      if (!larpReport) {
        throw new NotFoundException(`Report with ID ${larpReport} not found.`);
      }

      if (createLarpReportDto.causeAnalysisDto) {
        await this.saveCauseAnalysis(
          createLarpReportDto.causeAnalysisDto,
          larpReport,
          queryRunner.manager,
        );
      }

      if (createLarpReportDto.larpReportInfoDto) {
        await this.saveLarpReportInfo(
          createLarpReportDto.larpReportInfoDto,
          larpReport,
          queryRunner.manager,
        );
      }

      if (createLarpReportDto.larpReportDetailsDto) {
        await this.saveLarpReportDetails(
          createLarpReportDto.larpReportDetailsDto,
          larpReport,
          queryRunner.manager,
        );
      }

      if (createLarpReportDto.mainAreaOfConcernDto) {
        await this.saveMainAreaOfConcern(
          createLarpReportDto.mainAreaOfConcernDto,
          larpReport,
          queryRunner.manager,
        );
      }

      const updatedReport = this.larpReportRepository.merge(
        larpReport,
        createLarpReportDto,
      );

      await queryRunner.manager.save(LarpReportEntity, updatedReport);
      await queryRunner.commitTransaction();

      return {
        status: HttpStatus.OK,
        message: 'LARP report saved successfully',
      };
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw new InternalServerErrorException(
        `Failed to update report: ${error.message}`,
      );
    } finally {
      await queryRunner.release();
    }
  }

  async generateLarpReportCode(
    shipCode: string,
    shipId: number,
  ): Promise<string> {
    const currentYear = new Date().getFullYear().toString().slice(-2);

    // Fetch the latest report for the ship, ordered by serialNumber in descending order
    let shipMetadata = await this.larpReportRepository.findOne({
      where: {
        ship: { id: shipId },
      },
    });

    // Calculate the next serial number based on the latest report (or start with 1 if none exists)
    if (!shipMetadata) {
      shipMetadata = this.larpReportRepository.create({
        ship: { id: shipId },
        serialNumber: 1, // Starting serial number
      });
      await this.larpReportRepository.save(shipMetadata);
    } else {
      // Increment the serial number
      shipMetadata.serialNumber += 1;
      await this.larpReportRepository.save(shipMetadata); // Save the updated serial number
    }
    // Format the serial number to be 4 digits and generate the unique larp report ID
    const paddedSerial = shipMetadata.serialNumber.toString().padStart(4, '0');
    const uniqueId = `LA-${shipCode}-${currentYear}${paddedSerial}`;

    return uniqueId;
  }

  async getLarpReports(query: {
    shipId: number;
    status?: string;
    page: number;
    limit: number;
  }) {
    const { shipId, status, page = 1, limit = 10 } = query;

    const ship = await this.shipValidationService.getShipById(shipId);

    const queryBuilder = this.larpReportRepository
      .createQueryBuilder('larp_report')
      .where('larp_report.shipId = :shipId', { shipId: ship.id });

    if (status) {
      queryBuilder.andWhere('larp_report.status = :status', { status });
    }

    const [data, total] = await queryBuilder
      .orderBy('larp_report.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return { data, total };
  }

  async getLarpReportById(larpReportId: string): Promise<LarpReportEntity> {
    const larpReport = await this.larpReportRepository
      .createQueryBuilder('larp_report')
      .leftJoinAndSelect('larp_report.ship', 'ship')
      .leftJoin('larp_report.attachments', 'attachments')
      .leftJoinAndSelect('larp_report.causeAnalysis', 'causeAnalysis')
      .leftJoinAndSelect('larp_report.larpReportInfo', 'larp_report_info') // Make sure alias is 'larpReportInfo'
      .leftJoinAndSelect('larp_report.larpReportDetails', 'larpReportDetails')
      .leftJoinAndSelect('larp_report.mainAreaOfConcern', 'mainAreaOfConcern')
      .where('larp_report.larpReportId = :larpReportId', { larpReportId })
      .addSelect([
        'attachments.id',
        'attachments.fileName',
        'attachments.mimeType',
        'attachments.createdOn',
      ])
      .getOne();

    if (!larpReport) {
      throw new NotFoundException(
        `Larp Report with ID ${larpReportId} not found.`,
      );
    }

    return larpReport;
  }

  async uploadAttachmentsForLarPReport(
    larpReportId: string,
    files: Express.Multer.File[],
  ): Promise<{ fileId: string; fileName: string }[]> {
    const larpReport = await this.larpReportRepository.findOne({
      where: { larpReportId },
    });

    if (!larpReport) {
      throw new NotFoundException(
        `Larp Report with ID ${larpReportId} not found.`,
      );
    }

    const attachments = files.map((file) =>
      this.fileStorageRepository.create({
        data: file.buffer,
        mimeType: file.mimetype,
        fileName: file.originalname,
        larpReport,
      }),
    );

    const savedAttachments = await this.fileStorageRepository.save(attachments);

    return savedAttachments.map((file) => ({
      fileId: file.id,
      fileName: file.fileName,
      mimeType: file.mimeType,
    }));
  }
}
