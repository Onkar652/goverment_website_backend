import {
  BadRequestException,
  Body,
  Controller,
  Get,
  HttpStatus,
  Param,
  Post,
  Query,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import {
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiQuery,
  ApiResponse,
} from '@nestjs/swagger';
import { LarpReportEntity } from 'src/entities/qhse-reports/larp-report.entity';
import { CreateLarpReportDto } from './dto/create-larp-report-dto';
import { LarpReportService } from './larp-report.service';
@Controller('larpReport')
export class LarpReportController {
  constructor(private readonly larpReportService: LarpReportService) {}

  @Post('/initiate')
  @ApiOperation({
    summary: 'Initiate a Larp report and generate a LarpReportCode',
  })
  @ApiResponse({
    status: 201,
    description: 'Larp Report initiated successfully',
  })
  @ApiBody({
    description: 'Ship ID for which the Larp report is being initiated',
    schema: {
      type: 'object',
      properties: {
        shipId: {
          type: 'integer',
          description: 'ID of the ship',
          example: 1,
        },
      },
    },
  })
  async initiateLarpReport(@Body('shipId') shipId: number) {
    return await this.larpReportService.initiateLarpReport(shipId);
  }

  @Get()
  @ApiOperation({ summary: 'Get a list of larp reports' })
  @ApiResponse({
    status: 200,
    description: 'List of larp reports with pagination details',
    schema: {
      type: 'object',
      properties: {
        data: {
          type: 'array',
          items: { $ref: '#/components/schemas/Re' },
        },
        total: {
          type: 'number',
          description: 'Total number of larp reports matching the query',
        },
      },
    },
  })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship to filter larp reports by',
    example: 1,
  })
  @ApiQuery({
    name: 'status',
    required: false,
    type: String,
    description: 'Filter larp reports by their status (e.g., active, draft)',
    example: 'active',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    type: Number,
    description: 'The page number for pagination',
    example: 1,
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    description: 'The number of larp reports to return per page',
    example: 10,
  })
  async getReports(
    @Query('shipId') shipId: number,
    @Query('status') status?: string,
    @Query('page') page = 1,
    @Query('limit') limit = 10,
  ) {
    if (!shipId) {
      throw new BadRequestException('shipId is required');
    }
    return await this.larpReportService.getLarpReports({
      shipId,
      status,
      page,
      limit,
    });
  }

  @Get(':larpReportId')
  @ApiOperation({ summary: 'Get larp report details by ID' })
  @ApiResponse({
    status: 200,
    description: 'larp Report details',
    type: LarpReportEntity,
  })
  @ApiResponse({ status: 404, description: 'larp Report not found' })
  async getReportById(
    @Param('larpReportId') larpReportId: string,
  ): Promise<LarpReportEntity> {
    return await this.larpReportService.getLarpReportById(larpReportId);
  }

  @Post('save-draft')
  @ApiOperation({ summary: 'Update larp report details' })
  @ApiResponse({
    status: 200,
    description: 'Larp Report updated successfully',
    type: LarpReportEntity,
  })
  @ApiResponse({ status: 404, description: 'larp Report not found' })
  async saveReport(
    @Body() CreateLarpReportDto: CreateLarpReportDto,
  ): Promise<{ status: HttpStatus; message: string }> {
    return await this.larpReportService.saveLarpReport(CreateLarpReportDto);
  }

  @Post(':larpReportId/attachments')
  @UseInterceptors(FilesInterceptor('files'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Upload multiple attachments for a Larp Report',
    schema: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  async uploadAttachmentsForLarPReport(
    @Param('larpReportId') larpReportId: string,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<{
    message: string;
    attachments: { fileId: string; fileName: string }[];
  }> {
    console.log('Request body in the handler:');
    const attachments =
      await this.larpReportService.uploadAttachmentsForLarPReport(
        larpReportId,
        files,
      );
    return { message: 'Attachments uploaded successfully', attachments };
  }
}
