import {
  BadRequestException,
  Controller,
  Get,
  Post,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { SeedConfigService } from './seed-config.service';
import { ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import * as path from 'path';
import * as fs from 'fs';

@ApiTags('seed-config')
@Controller('seed-config')
export class SeedConfigController {
  constructor(private readonly seedConfigService: SeedConfigService) {}

  @Get()
  async initializeTimeZoneandport() {
    await this.seedConfigService.seedPorts();
    await this.seedConfigService.seedTimezones();
    return 'imported successfully';
  }

  @Post('upload/port-list')
  @ApiOperation({ summary: 'Upload Excel file to import port list data' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Excel file',
    schema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          format: 'binary',
          description: 'Excel file containing port list data',
        },
      },
    },
  })
  @UseInterceptors(FileInterceptor('file'))
  uploadExcel(@UploadedFile() file: Express.Multer.File) {
    if (!file) {
      throw new BadRequestException('No file uploaded');
    }

    // Save the file temporarily
    const uploadsDir = path.join(__dirname, 'uploads');
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir);
    }
    const filePath = path.join(uploadsDir, file.originalname);
    fs.writeFileSync(filePath, file.buffer);

    // Process the file in the background
    setImmediate(async () => {
      try {
        await this.seedConfigService.importFromExcel(filePath);
      } catch (error) {
        // Log the error (you could also implement a more sophisticated logging mechanism)
        console.error('Error processing file:', error);
      } finally {
        // Clean up the temporary file
        fs.unlinkSync(filePath);
      }
    });

    // Immediately return a response so the HTTP connection can close
    return {
      success: true,
      message: 'File received and processing started in background.',
    };
  }
}
