import { Module } from '@nestjs/common';
import { SeedConfigService } from './seed-config.service';
import { SeedConfigController } from './seed-config.controller';
import { PortListEntity } from 'src/entities/master-configs/port-list.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([PortListEntity])],
  controllers: [SeedConfigController],
  providers: [SeedConfigService],
})
export class SeedConfigModule {}
