import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import path from 'path';
import { portList } from 'src/config-data/ports';
import { timezonList } from 'src/config-data/timezone';
import { PortListEntity } from 'src/entities/master-configs/port-list.entity';
import { PortEntity } from 'src/entities/master-configs/port.entity';
import { TimezoneEntity } from 'src/entities/master-configs/timezone.entity';
import { DataSource, In, Repository } from 'typeorm';
import * as XLSX from 'xlsx';
import * as fs from 'fs';

@Injectable()
export class SeedConfigService {
  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PortListEntity)
    private readonly portListRepository: Repository<PortListEntity>,
  ) {}
  async seedTimezones() {
    const repository = this.dataSource.getRepository(TimezoneEntity);

    for (const tz of timezonList) {
      const timezone = new TimezoneEntity();
      timezone.name = tz.value; // "India Standard Time"
      timezone.utcOffset = tz.offset; // "IST"
      timezone.description = tz.text;

      await repository.save(timezone);
    }

    console.log('Timezones seeded successfully');
  }

  async seedPorts() {
    const portRepository = this.dataSource.getRepository(PortEntity);
    for (const port of portList) {
      const existingPort = await portRepository.findOne({
        where: { portCode: port.portCode },
      });
      if (!existingPort) {
        const newPort = portRepository.create(port);
        await portRepository.save(newPort);
      }
    }
  }

  async importFromExcel(filePath: string): Promise<void> {
    // 1. Parse Excel
    const workbook = XLSX.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rows: any[] = XLSX.utils.sheet_to_json(sheet);

    // 2. Convert each row to a plain object
    //    Adjust keys to match your columns in the Excel
    const portRows = rows.map((row) => ({
      code: row['Code'],
      name: row['Name'],
      countryRegionCode: row['Country/Region Code'],
      // "TRUE"/"FALSE" or boolean => convert to boolean
      euPort: row['EU Port'] === 'TRUE' || row['EU Port'] === true,
    }));

    // 3. Check for duplicates in Excel data itself
    //    We can track codes in a Set, see if any code repeats
    const seenCodes = new Set<string>();
    const duplicatesInExcel: string[] = [];

    for (const item of portRows) {
      if (seenCodes.has(item.code)) {
        duplicatesInExcel.push(item.code);
      } else {
        seenCodes.add(item.code);
      }
    }

    // 4. Check for duplicates in DB
    //    (Any code that already exists in the table is a conflict)
    const allCodes = portRows.map((r) => r.code);
    const batchSize = 1000; // Adjust as needed
    const duplicatesInDBSet = new Set<string>();

    for (let i = 0; i < allCodes.length; i += batchSize) {
      const batchCodes = allCodes.slice(i, i + batchSize);
      const existingRecords = await this.portListRepository.find({
        where: { code: In(batchCodes) },
        select: ['code'],
      });
      existingRecords.forEach((record) => duplicatesInDBSet.add(record.code));
    }

    const duplicatesInDB = Array.from(duplicatesInDBSet);

    // 5. If duplicates found, log them and throw an error
    if (duplicatesInExcel.length > 0 || duplicatesInDB.length > 0) {
      // Create a log file (or append) with duplicates
      const logFilePath = path.join(__dirname, 'duplicates.log');
      const logLines = [];

      if (duplicatesInExcel.length > 0) {
        logLines.push(`Duplicates in Excel (${duplicatesInExcel.length}):`);
        logLines.push(...duplicatesInExcel);
      }
      if (duplicatesInDB.length > 0) {
        logLines.push(`Duplicates in DB (${duplicatesInDB.length}):`);
        logLines.push(...duplicatesInDB);
      }

      fs.writeFileSync(logFilePath, logLines.join('\n'), { flag: 'w' });

      // Throw an error to stop the import
      throw new Error(
        `Duplicate port codes found. See duplicates.log for details.`,
      );
    }

    // 6. If no duplicates, insert all data in a single transaction
    //    with batched inserts
    const BATCH_SIZE = 1000; // you can tweak the size
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();

    try {
      await queryRunner.startTransaction();

      // Insert in chunks
      for (let i = 0; i < portRows.length; i += BATCH_SIZE) {
        const batch = portRows.slice(i, i + BATCH_SIZE);

        // If you want the speed of raw insert:
        //   await queryRunner.manager.insert(PortListEntity, batch);
        // Or if you want to do a plain query, you could do that as well.

        await queryRunner.manager.insert(PortListEntity, batch);
      }

      // Commit if all inserts succeed
      await queryRunner.commitTransaction();
    } catch (error) {
      // Roll back on any error (including unique constraint violation)
      await queryRunner.rollbackTransaction();

      // Log or re-throw
      const logFilePath = path.join(__dirname, 'duplicates.log');
      fs.writeFileSync(
        logFilePath,
        `Transaction failed: ${error.message || error}\n`,
        { flag: 'a' },
      );
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
