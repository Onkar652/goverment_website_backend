import { Test, TestingModule } from '@nestjs/testing';
import { SeedConfigService } from './seed-config.service';

describe('SeedConfigService', () => {
  let service: SeedConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [SeedConfigService],
    }).compile();

    service = module.get<SeedConfigService>(SeedConfigService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
