import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { componentList } from 'src/config-data/components';
import { shipComponents } from 'src/config-data/components-updated';
import { Ship } from 'src/entities/ships/ships.entity';
import { DataSource, Repository } from 'typeorm';
import {
  ComponentCategoryEnum,
  MainPartComponent,
} from '../../entities/shipParts/main-part-components.entity';
import { MainPart } from '../../entities/shipParts/main-parts.entity';
import { VoyageEntity } from 'src/entities/voyage/voyage.entity';
import { WorkOrder } from 'src/entities/shipActions/work-order.entity';
import { ActiveEventReportEntity } from 'src/entities/postion-book-reports/active-event-reports.entity';
import { CertificationEntity } from 'src/entities/certifications/certification.entity';

@Injectable()
export class ShipsService {
  private shipRepo: Repository<Ship>;
  private mainPartRepository: Repository<MainPart>;
  private componentRepository: Repository<MainPartComponent>;
  private voyageRepository: Repository<VoyageEntity>;
  private workOrderRepository: Repository<WorkOrder>;
  private activeReportRepository: Repository<ActiveEventReportEntity>;
  private certificationRepository: Repository<CertificationEntity>; // Add this line
  constructor(private readonly dataSource: DataSource) {
    this.shipRepo = this.dataSource.getRepository(Ship);
    this.mainPartRepository = this.dataSource.getRepository(MainPart);
    this.workOrderRepository = this.dataSource.getRepository(WorkOrder);
    this.activeReportRepository = this.dataSource.getRepository(
      ActiveEventReportEntity,
    );
    this.certificationRepository =
      this.dataSource.getRepository(CertificationEntity); // Add this line
    this.workOrderRepository = this.dataSource.getRepository(WorkOrder);
    this.voyageRepository = this.dataSource.getRepository(VoyageEntity);
  }

  async getShipsByClientId(clientId: string): Promise<Ship[]> {
    return await this.shipRepo.find({
      where: { client: { client_id: clientId }, disabled: false },
      relations: ['client'], // Assuming you need the client relation
    });
  }

  // Function to get a single ship by shipId
  async getShipById(shipId: number): Promise<Ship> {
    const ship = await this.shipRepo.findOne({
      where: { id: shipId, disabled: false },
      relations: ['client', 'voyages', 'userDetails', 'mainParts'], // Include any relations needed
    });
    if (!ship) {
      throw new NotFoundException('Ship not found');
    }
    return ship;
  }

  async insertMainParts(
    mainParts: { MainPart: string; Category: string }[],
    shipId: number,
  ) {
    const allowedCategories = ['engine', 'deck', 'critical', 'other'];
    const ship = await this.getShipById(shipId);
    if (!ship) {
      throw new NotFoundException('Ship not found');
    }
    try {
      for (const part of mainParts) {
        const existingPart = await this.mainPartRepository.findOne({
          where: { name: part.MainPart },
        });

        if (!existingPart) {
          const category = allowedCategories.includes(
            part.Category.toLowerCase(),
          )
            ? (part.Category.toLowerCase() as ComponentCategoryEnum)
            : ('other' as ComponentCategoryEnum);
          const newMainPart = this.mainPartRepository.create({
            name: part.MainPart,
            category: category,
            ship: ship, // Link to the specific ship
            disabled: false,
          });
          await this.mainPartRepository.save(newMainPart);
        }
      }
    } catch (error) {
      throw new BadRequestException(error);
    }
  }

  async insertComponents(shipId: number): Promise<void> {
    const ship = await this.getShipById(shipId);
    if (!ship) {
      throw new NotFoundException('Ship not found');
    }

    const queryRunner = this.dataSource.createQueryRunner();

    // Start a transaction
    await queryRunner.startTransaction();

    try {
      // Insert the main part components associated with the found main part
      for (const component of componentList) {
        const mainPart = await this.mainPartRepository.findOne({
          where: {
            name: component.mainPart.name,
            ship: { id: shipId }, // Assuming ship is linked via ManyToOne relationship
          },
          relations: ['ship'], // Load ship relationship
        });

        if (!mainPart) {
          throw new NotFoundException(
            `Main part "${component.mainPart.name}" not found for ship with ID ${shipId}`,
          );
        }
        const mainPartComponent = this.componentRepository.create({
          name: component.name,
          partId: component.partId,
          maker: component.maker,
          model: component.model,
          mainPart, // Link to the validated main part
          disabled: component.disabled,
        });
        await queryRunner.manager.save(MainPartComponent, mainPartComponent);
      }

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw new BadRequestException(
        'Error inserting components: ' + error.message,
      );
    } finally {
      await queryRunner.release();
    }
  }

  async insertComp(shipId: number): Promise<void> {
    const allowedCategories = ['engine', 'deck', 'critical', 'other'];

    const ship = await this.getShipById(shipId);
    if (!ship) {
      throw new NotFoundException('Ship not found');
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      for (const item of shipComponents) {
        const componentType = item['Component type'];
        const componentName = item.Component;
        // let mainPart = await this.mainPartRepository.findOne({
        //   where: { name: componentType, ship },
        //   relations: ['ship'],
        // });
        let mainPart = await queryRunner.manager.findOne(MainPart, {
          where: { name: componentType, ship },
          relations: ['ship'],
        });

        if (!mainPart) {
          const category = allowedCategories.includes(
            item.Department.toLowerCase(),
          )
            ? (item.Department.toLowerCase() as ComponentCategoryEnum)
            : ('other' as ComponentCategoryEnum);

          mainPart = this.mainPartRepository.create({
            name: componentType,
            category: category,
            ship: ship,
            disabled: false,
          });
          await queryRunner.manager.save(mainPart);
        }

        const mainPartComponent = this.componentRepository.create({
          name: componentName,
          partId: item.Code,
          maker: item.Maker || null,
          model: item.Model || null,
          mainPart,
          disabled: false,
        });

        await queryRunner.manager.save(mainPartComponent);
      }

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw new BadRequestException(
        'Error inserting main parts and components: ' + error.message,
      );
    } finally {
      await queryRunner.release();
    }
  }

  async getDashboardMetrics(shipId: number) {
    // Validate Ship
    await this.getShipById(shipId);

    // 1️⃣ Count Work Orders by Status
    const workOrderCounts = await this.workOrderRepository
      .createQueryBuilder('workOrder')
      .select('workOrder.status, COUNT(workOrder.id) as count')
      .where('workOrder.ship_id = :shipId', { shipId })
      .groupBy('workOrder.status')
      .getRawMany();

    // 2️⃣ Count Certifications by Status
    const certificationCounts = await this.certificationRepository
      .createQueryBuilder('certification')
      .select('certification.status, COUNT(certification.id) as count')
      .where('certification.ship_id = :shipId', { shipId })
      .groupBy('certification.status')
      .getRawMany();

    // 3️⃣ Fetch Active Voyage
    const activeVoyage = await this.voyageRepository.findOne({
      where: { ship: { id: shipId }, status: 'active' },
    });

    // 4️⃣ Count Open Requisitions
    // const openRequisitionCount = await this.requisitionRepository.count({
    //   where: { ship: { id: shipId }, status: 'open' },
    // });

    // 5️⃣ Count Active Reports
    const activeReportsCount = await this.activeReportRepository.findOne({
      where: { ship: { id: shipId }, reportStage: 'active' },
    });

    return {
      workOrders: workOrderCounts,
      certifications: certificationCounts,
      activeVoyage,
      // openRequisitions: openRequisitionCount,
      activeReports: activeReportsCount,
    };
  }
}
