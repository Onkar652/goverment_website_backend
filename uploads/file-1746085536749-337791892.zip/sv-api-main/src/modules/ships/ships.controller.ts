import {
  BadRequestException,
  Body,
  Controller,
  Get,
  NotFoundException,
  Param,
  Post,
} from '@nestjs/common';
import { ApiBody, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { shipMainParts } from 'src/config-data/main-parts';
import { InsertMainPartComponentDto } from './dto/ship-parts.dto';
import { ShipsService } from './ships.service';

@ApiTags('ship')
@Controller('ships')
export class ShipsController {
  constructor(private readonly shipsService: ShipsService) {}

  @Get('by-client/:clientId')
  @ApiOperation({ summary: 'Get all ships by clientId' })
  @ApiResponse({
    status: 200,
    description: 'List of ships returned successfully',
  })
  @ApiResponse({
    status: 404,
    description: 'No ships found for the given clientId',
  })
  async getShipsByClientId(@Param('clientId') clientId: string) {
    const ships = await this.shipsService.getShipsByClientId(clientId);
    if (!ships.length) {
      throw new NotFoundException('No ships found for the given clientId');
    }
    return ships;
  }

  // Get a single ship by shipId
  @Get(':shipId')
  @ApiOperation({ summary: 'Get ship by shipId' })
  @ApiResponse({ status: 200, description: 'Ship returned successfully' })
  @ApiResponse({ status: 404, description: 'Ship not found' })
  async getShipById(@Param('shipId') shipId: number) {
    const ship = await this.shipsService.getShipById(shipId);
    return ship;
  }

  @Post('/add-main-parts')
  @ApiOperation({ summary: 'Insert main parts for a ship' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        shipId: {
          type: 'integer',
          example: 1,
          description:
            'The ID of the ship to which the main parts will be linked',
        },
      },
    },
  })
  @ApiResponse({ status: 201, description: 'Main parts inserted successfully' })
  @ApiResponse({ status: 400, description: 'Invalid input' })
  @ApiResponse({ status: 500, description: 'Internal server error' })
  async insertMainParts(
    @Body() body: { shipId: number }, // Ship ID as input
  ) {
    const { shipId } = body;
    await this.shipsService.insertMainParts(shipMainParts, shipId);
    return { message: 'Main parts inserted successfully' };
  }

  @Post('add-components')
  @ApiOperation({ summary: 'Insert main part components for a specific ship' }) // Description of the endpoint
  @ApiBody({
    description: 'Provide the shipId to insert components linked to that ship',
    schema: {
      example: { shipId: 123 },
    },
  })
  @ApiResponse({ status: 201, description: 'Data inserted successfully' }) // Successful response
  @ApiResponse({ status: 400, description: 'shipId is required' }) // Bad request response
  async addComponents(@Body() body: InsertMainPartComponentDto) {
    const { shipId } = body;

    if (!shipId) {
      throw new BadRequestException('shipId is required');
    }

    try {
      // await this.shipsService.insertComponents(shipId);
      await this.shipsService.insertComp(shipId);
      return { message: 'Data inserted successfully' };
    } catch (error) {
      return { message: error.message };
    }
  }

  @Get('/dashboard-metrics/:shipId')
  @ApiOperation({ summary: 'Get dashboard metrics' })
  @ApiResponse({
    status: 200,
    description: 'Returns aggregated dashboard metrics',
  })
  async getDashboardMetrics(@Param('shipId') shipId: number) {
    return this.shipsService.getDashboardMetrics(shipId);
  }
}
