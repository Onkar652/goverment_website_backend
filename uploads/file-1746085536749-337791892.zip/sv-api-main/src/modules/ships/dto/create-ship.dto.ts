export class CreateShipDto {}
