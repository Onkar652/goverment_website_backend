export class InsertMainPartComponentDto {
  shipId: number;
}
