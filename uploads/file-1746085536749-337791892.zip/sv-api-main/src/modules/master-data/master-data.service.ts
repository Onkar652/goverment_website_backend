import { BadRequestException, Injectable } from '@nestjs/common';
import { PortListEntity } from 'src/entities/master-configs/port-list.entity';
import { IncidentActivityEntity } from 'src/entities/master-configs/incident-activity.entity';
import { LocationOnboardEntity } from 'src/entities/master-configs/location-onboard.entity';
import { PortEntity } from 'src/entities/master-configs/port.entity';
import { TimezoneEntity } from 'src/entities/master-configs/timezone.entity';
import { VesselActivityEntity } from 'src/entities/master-configs/vessel-activity.entity';
import { VesselLocationEntity } from 'src/entities/master-configs/vessel-location.entity';
import { DataSource, Repository } from 'typeorm';
import { ShipValidationService } from '../common/ship-validation.service';
import { DirectCauseEntity } from 'src/entities/master-configs/direct-cause.entity';
import { InDirectCauseEntity } from 'src/entities/master-configs/indirect-cause.entity';
import { RootCauseEntity } from 'src/entities/master-configs/root-cause.entity';
import * as xlsx from 'xlsx';
@Injectable()
export class MasterDataService {
  private portRepository: Repository<PortEntity>;
  private locationOnBoardRepository: Repository<LocationOnboardEntity>;
  private incidentActivityRepository: Repository<IncidentActivityEntity>;
  private vesselLocationRepository: Repository<VesselLocationEntity>;
  private directCauseRepository: Repository<DirectCauseEntity>;
  private inDirectCauseRepository: Repository<InDirectCauseEntity>;
  private rootCauseRepository: Repository<RootCauseEntity>;
  private timezoneRepository: Repository<TimezoneEntity>;
  private portListRepository: Repository<PortListEntity>;
  private vesselActivityRepository: Repository<VesselActivityEntity>;

  constructor(
    private readonly dataSource: DataSource,
    private shipValidationService: ShipValidationService,
  ) {
    this.directCauseRepository =
      this.dataSource.getRepository(DirectCauseEntity);
    this.inDirectCauseRepository =
      this.dataSource.getRepository(InDirectCauseEntity);
    this.rootCauseRepository = this.dataSource.getRepository(RootCauseEntity);
    this.portRepository = this.dataSource.getRepository(PortEntity);
    this.vesselLocationRepository =
      this.dataSource.getRepository(VesselLocationEntity);
    this.timezoneRepository = this.dataSource.getRepository(TimezoneEntity);
    this.portListRepository = this.dataSource.getRepository(PortListEntity);
    this.incidentActivityRepository = this.dataSource.getRepository(
      IncidentActivityEntity,
    );
    this.locationOnBoardRepository = this.dataSource.getRepository(
      LocationOnboardEntity,
    );
    this.vesselActivityRepository =
      this.dataSource.getRepository(VesselActivityEntity);
  }

  async getAllPorts(): Promise<PortEntity[]> {
    return this.portRepository.find();
  }

  async getAllTimezones(): Promise<TimezoneEntity[]> {
    return this.timezoneRepository.find();
  }

  async getPortsList(page: number, limit: number, search?: string) {
    const query = this.portListRepository.createQueryBuilder('port');

    if (search && search.trim().length > 0) {
      if (search.trim().length < 3) {
        throw new BadRequestException(
          'Search term must be at least 3 characters long',
        );
      }
      // Using ILIKE for case-insensitive search (PostgreSQL); adjust if needed for other DBs
      query.where('(port.code ILIKE :search OR port.name ILIKE :search)', {
        search: `%${search}%`,
      });
    }

    // Apply pagination: calculate offset using page and limit values
    query.skip((page - 1) * limit).take(limit);

    // Execute the query and get both results and total count
    const [data, total] = await query.getManyAndCount();

    return {
      data,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }
  async getVesselLocations(shipId: number): Promise<VesselLocationEntity[]> {
    await this.shipValidationService.getShipById(shipId);
    return await this.vesselLocationRepository.find();
  }

  async getDirectCause(shipId: number): Promise<DirectCauseEntity[]> {
    await this.shipValidationService.getShipById(shipId);
    return await this.directCauseRepository.find();
  }

  async getInDirectCause(shipId: number): Promise<InDirectCauseEntity[]> {
    await this.shipValidationService.getShipById(shipId);
    return await this.inDirectCauseRepository.find();
  }

  async getRootCause(shipId: number): Promise<RootCauseEntity[]> {
    await this.shipValidationService.getShipById(shipId);
    return await this.rootCauseRepository.find();
  }

  async getIncidentActivity(shipId: number): Promise<IncidentActivityEntity[]> {
    await this.shipValidationService.getShipById(shipId);
    return await this.incidentActivityRepository.find();
  }

  async getLocationOnBoard(shipId: number): Promise<LocationOnboardEntity[]> {
    await this.shipValidationService.getShipById(shipId);
    return await this.locationOnBoardRepository.find();
  }

  async getVesselActivity(shipId: number): Promise<VesselActivityEntity[]> {
    await this.shipValidationService.getShipById(shipId);
    return await this.vesselActivityRepository.find();
  }

  async seedData(filePath: string) {
    const workbook = xlsx.readFile(filePath);
    const sheetName = workbook.SheetNames[0]; // Read first sheet
    const jsonData = xlsx.utils.sheet_to_json(workbook.Sheets[sheetName]);

    // Insert data into the database
    for (const row of jsonData) {
      const { Category, SubCategory, Description } = row as any;

      if (!Category || !SubCategory) continue; // Skip empty rows

      const directCause = this.directCauseRepository.create({
        category: Category,
        subcategory: SubCategory,
        descriptionOfDirectCause: Description,
      });

      await this.directCauseRepository.save(directCause);
    }

    return { message: 'Root causes seeded successfully' };
  }
}
