import { Module } from '@nestjs/common';
import { MasterDataService } from './master-data.service';
import { MasterDataController } from './master-data.controller';
import { ShipValidationService } from '../common/ship-validation.service';
@Module({
  imports: [],
  exports: [],
  controllers: [MasterDataController],
  providers: [MasterDataService, ShipValidationService],
})
export class MasterDataModule {}
