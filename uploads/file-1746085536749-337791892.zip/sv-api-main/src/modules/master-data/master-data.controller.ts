import { Controller, Get, ParseIntPipe, Query } from '@nestjs/common';
import { ApiOperation, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { DirectCauseEntity } from 'src/entities/master-configs/direct-cause.entity';
import { IncidentActivityEntity } from 'src/entities/master-configs/incident-activity.entity';
import { InDirectCauseEntity } from 'src/entities/master-configs/indirect-cause.entity';
import { LocationOnboardEntity } from 'src/entities/master-configs/location-onboard.entity';
import { RootCauseEntity } from 'src/entities/master-configs/root-cause.entity';
import { TimezoneEntity } from 'src/entities/master-configs/timezone.entity';
import { VesselActivityEntity } from 'src/entities/master-configs/vessel-activity.entity';
import { VesselLocationEntity } from 'src/entities/master-configs/vessel-location.entity';
import { MasterDataService } from './master-data.service';
// import { FileInterceptor } from '@nestjs/platform-express';
// import * as path from 'path';
// import * as fs from 'fs';

@ApiTags('Master data')
@Controller('master-data')
export class MasterDataController {
  constructor(private readonly masterDataService: MasterDataService) {}

  @Get('/timezones')
  @ApiOperation({ summary: 'Fetch all timezones' })
  @ApiResponse({
    status: 200,
    description: 'List of timezones fetched successfully',
    type: [TimezoneEntity],
  })
  async getTimezones() {
    return this.masterDataService.getAllTimezones();
  }

  // @Get('/ports')
  // @ApiOperation({ summary: 'Fetch all ports' })
  // @ApiResponse({
  //   status: 200,
  //   description: 'List of ports fetched successfully',
  //   type: [PortEntity],
  // })
  // async getPorts() {
  //   return this.masterDataService.getAllPorts();
  // }

  @Get('/ports')
  @ApiOperation({
    summary: 'Get list of ports with pagination and optional search',
  })
  @ApiQuery({
    name: 'page',
    type: Number,
    required: false,
    description: 'Page number (default: 1)',
  })
  @ApiQuery({
    name: 'limit',
    type: Number,
    required: false,
    description: 'Number of items per page (default: 10)',
  })
  @ApiQuery({
    name: 'search',
    type: String,
    required: false,
    description:
      'Search string (minimum 3 characters) to filter ports by code or name',
  })
  async getPortsList(
    @Query('page') page: string,
    @Query('limit') limit: string,
    @Query('search') search: string,
  ) {
    // Convert page and limit to numbers (defaulting to 1 and 10 if not provided)
    const pageNumber = parseInt(page, 10) || 1;
    const limitNumber = parseInt(limit, 10) || 10;

    return await this.masterDataService.getPortsList(
      pageNumber,
      limitNumber,
      search,
    );
  }

  @Get('/incident-Activity')
  @ApiOperation({ summary: 'Fetch all incidents' })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship for which direct causes are fetched',
  })
  @ApiResponse({
    status: 200,
    description: 'List of incident of Activity fetched successfully',
    type: [IncidentActivityEntity],
  })
  async getIncidentActivity(@Query('shipId', ParseIntPipe) shipId: number) {
    return this.masterDataService.getIncidentActivity(shipId);
  }

  @Get('/vessel-Activity')
  @ApiOperation({ summary: 'Fetch all vessel Activity' })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship for which direct causes are fetched',
  })
  @ApiResponse({
    status: 200,
    description: 'List of vessel Activity fetched successfully',
    type: [VesselActivityEntity],
  })
  async getVesselActivity(@Query('shipId', ParseIntPipe) shipId: number) {
    return this.masterDataService.getVesselActivity(shipId);
  }
  @Get('/location-on-board')
  @ApiOperation({ summary: 'Fetch all LocationOnboard Activity' })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship for which direct causes are fetched',
  })
  @ApiResponse({
    status: 200,
    description: 'List of location on board fetched successfully',
    type: [LocationOnboardEntity],
  })
  async getLocationOnBoard(@Query('shipId', ParseIntPipe) shipId: number) {
    return this.masterDataService.getLocationOnBoard(shipId);
  }

  @Get('/vessel-locations')
  @ApiOperation({ summary: 'Fetch all vessel Locations' })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship for which direct causes are fetched',
  })
  @ApiResponse({
    status: 200,
    description: 'List of vessel Locations fetched successfully',
    type: [VesselLocationEntity],
  })
  async getVesselLocations(@Query('shipId', ParseIntPipe) shipId: number) {
    return this.masterDataService.getVesselLocations(shipId);
  }

  @Get('/direct-cause')
  @ApiOperation({ summary: 'Fetch all direct causes' })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship for which direct causes are fetched',
  })
  @ApiResponse({
    status: 200,
    description: 'List of direct causes fetched successfully',
    type: [DirectCauseEntity],
  })
  async getAllDirectCause(@Query('shipId', ParseIntPipe) shipId: number) {
    return this.masterDataService.getDirectCause(shipId);
  }

  @Get('/indirect-cause')
  @ApiOperation({ summary: 'Fetch all Indirect causes' })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship for which direct causes are fetched',
  })
  @ApiResponse({
    status: 200,
    description: 'List of direct causes fetched successfully',
    type: [InDirectCauseEntity],
  })
  async getInDirectCause(@Query('shipId', ParseIntPipe) shipId: number) {
    return this.masterDataService.getInDirectCause(shipId);
  }

  @Get('/root-cause')
  @ApiOperation({ summary: 'Fetch all root causes' })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship for which direct causes are fetched',
  })
  @ApiResponse({
    status: 200,
    description: 'List of root causes fetched successfully',
    type: [RootCauseEntity],
  })
  async getAllRootCause(@Query('shipId', ParseIntPipe) shipId: number) {
    return this.masterDataService.getRootCause(shipId);
  }

  // @Post('upload/root')
  // @ApiOperation({ summary: 'Upload Excel file to import port list data' })
  // @ApiConsumes('multipart/form-data')
  // @ApiBody({
  //   description: 'Excel file',
  //   schema: {
  //     type: 'object',
  //     properties: {
  //       file: {
  //         type: 'string',
  //         format: 'binary',
  //         description: 'Excel file containing port list data',
  //       },
  //     },
  //   },
  // })
  // @UseInterceptors(FileInterceptor('file'))
  // uploadExcel(@UploadedFile() file: Express.Multer.File) {
  //   if (!file) {
  //     throw new BadRequestException('No file uploaded');
  //   }

  //   // Save the file temporarily
  //   const uploadsDir = path.join(__dirname, 'uploads');
  //   if (!fs.existsSync(uploadsDir)) {
  //     fs.mkdirSync(uploadsDir);
  //   }
  //   const filePath = path.join(uploadsDir, file.originalname);
  //   fs.writeFileSync(filePath, file.buffer);

  //   // Process the file in the background
  //   setImmediate(async () => {
  //     try {
  //       await this.masterDataService.seedData(filePath);
  //     } catch (error) {
  //       // Log the error (you could also implement a more sophisticated logging mechanism)
  //       console.error('Error processing file:', error);
  //     } finally {
  //       // Clean up the temporary file
  //       fs.unlinkSync(filePath);
  //     }
  //   });

  //   // Immediately return a response so the HTTP connection can close
  //   return {
  //     success: true,
  //     message: 'File received and processing started in background.',
  //   };
  // }
}
