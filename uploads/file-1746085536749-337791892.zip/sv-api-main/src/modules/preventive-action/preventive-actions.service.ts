import {
  BadRequestException,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { CertificationEntity } from 'src/entities/certifications/certification.entity';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { PreventiveActionEntity } from 'src/entities/qhse-reports/preventive-measure.entity';
import { RequisitionEntity } from 'src/entities/requisitions/requisition.entity';
import { WorkOrder } from 'src/entities/shipActions/work-order.entity';
import { DataSource, EntityManager, Like, Repository } from 'typeorm';
import { ShipValidationService } from '../common/ship-validation.service';
import { CreatePreventiveActionDto } from './dto/create-corrective-measure.dto';
@Injectable()
export class PreventiveActionService {
  certificationRepository: Repository<CertificationEntity>;
  fileStorageRepository: Repository<FileStorageEntity>;
  requisitionRepository: Repository<RequisitionEntity>;
  workOrderRepository: Repository<WorkOrder>;
  preventiveActionRepository: Repository<PreventiveActionEntity>;
  constructor(
    private readonly dataSource: DataSource,
    private shipValidationService: ShipValidationService,
  ) {
    this.certificationRepository =
      this.dataSource.getRepository(CertificationEntity);
    this.preventiveActionRepository = this.dataSource.getRepository(
      PreventiveActionEntity,
    );
    this.workOrderRepository = this.dataSource.getRepository(WorkOrder);
    this.fileStorageRepository =
      this.dataSource.getRepository(FileStorageEntity);
    this.requisitionRepository =
      this.dataSource.getRepository(RequisitionEntity);
  }

  async savePreventiveActions(
    preventiveActionId: string,
    preventiveActionDto: CreatePreventiveActionDto,
  ): Promise<PreventiveActionEntity> {
    if (!preventiveActionId) {
      throw new BadRequestException(
        'preventive Action ID is required for updating a preventive Action info.',
      );
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Fetch the existing corrective actions
      const preventiveAction = await this.preventiveActionRepository.findOne({
        where: { preventiveActionId },
        relations: ['workOrders', 'certificate', 'attachments', 'requisition'],
      });

      if (!preventiveAction) {
        throw new NotFoundException(
          `preventiveAction with ID ${preventiveAction} not found.`,
        );
      }

      // Use shared logic for updating the report
      const updatedPreventiveAction = await this.updatedPreventiveAction(
        preventiveAction,
        preventiveActionDto,
        queryRunner.manager,
      );

      await queryRunner.commitTransaction();
      return updatedPreventiveAction;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw new InternalServerErrorException(
        `Failed to update CorrectiveAction: ${error.message}`,
      );
    } finally {
      await queryRunner.release();
    }
  }

  async generateUniquePreventiveId(shipCode: string): Promise<string> {
    const currentYear = new Date().getFullYear().toString().slice(-2);

    const latestReport = await this.preventiveActionRepository.findOne({
      where: { preventiveActionId: Like(`PA-${shipCode}-${currentYear}%`) },
      order: { preventiveActionId: 'DESC' },
    });

    let serialNumber = 1; // Default if no previous ID exists

    if (latestReport) {
      const lastIdParts = latestReport.preventiveActionId.split('-');
      const lastYear = lastIdParts[2].substring(0, 2); // Extract year
      const lastSerial = parseInt(lastIdParts[2].substring(2), 10); // Extract serial number

      if (lastYear === currentYear) {
        serialNumber = lastSerial + 1; // Increment if same year
      }
    }

    // Ensure serial number is 4-digit padded
    const paddedSerial = serialNumber.toString().padStart(4, '0');
    return `PA-${shipCode}-${currentYear}${paddedSerial}`;
  }

  private async updatedPreventiveAction(
    preventiveAction: PreventiveActionEntity,
    preventiveActionDto: CreatePreventiveActionDto,
    manager: EntityManager,
  ): Promise<PreventiveActionEntity> {
    const workOrder = preventiveActionDto.workOrderId
      ? await this.workOrderRepository.findOne({
          where: { id: preventiveActionDto.workOrderId },
        })
      : null;
    // const certificate = preventiveActionDto.certificateId
    //   ? await this.certificationRepository.findOne({
    //       where: { id: preventiveActionDto.certificateId },
    //     })
    //   : null;
    const requisition = preventiveActionDto.requisitionId
      ? await this.requisitionRepository.findOne({
          where: { id: preventiveActionDto.requisitionId },
        })
      : null;

    const updatedPreventiveAction: PreventiveActionEntity =
      this.preventiveActionRepository.create({
        ...preventiveAction,
        ...preventiveActionDto,
        workOrder,
        // certificates,
        purchaseRequisitions: requisition,
      });
    return await manager.save(PreventiveActionEntity, updatedPreventiveAction);
  }

  async getPreventiveActionById(
    preventiveActionId: string,
  ): Promise<PreventiveActionEntity> {
    const preventiveAction = await this.preventiveActionRepository
      .createQueryBuilder('preventiveActions')
      .leftJoinAndSelect('preventiveActions.ship', 'ship')
      .leftJoin('preventiveActions.attachments', 'attachments')
      .leftJoin('preventiveActions.requisition', 'requisition')
      .leftJoin('preventiveActions.workOrders', 'workOrders')
      .leftJoin('preventiveActions.certificate', 'certificate')
      .addSelect([
        'preventiveActions.id',
        'preventiveActions.fileName',
        'preventiveActions.mimeType',
        'preventiveActions.createdOn',
      ])
      .where('preventiveActions.preventiveActionId = :preventiveActionId', {
        preventiveActionId,
      })
      .getOne();

    if (!preventiveAction) {
      throw new NotFoundException(
        `correctiveAction with ID ${preventiveActionId} not found.`,
      );
    }

    return preventiveAction;
  }

  async uploadAttachmentsForPreventive(
    preventiveActionId: string,
    files: Express.Multer.File[],
  ): Promise<void> {
    const preventiveAction = await this.preventiveActionRepository.findOne({
      where: { preventiveActionId },
    });

    if (!preventiveAction) {
      throw new NotFoundException(
        `Corrective Measure with ID ${preventiveActionId} not found.`,
      );
    }

    const attachments = files.map((file) =>
      this.fileStorageRepository.create({
        data: file.buffer,
        mimeType: file.mimetype,
        fileName: file.originalname,
        preventiveAction,
      }),
    );

    await this.fileStorageRepository.save(attachments);
  }

  async getPreventiveAction(query: {
    shipId?: number;
    status?: string;
    page: number;
    limit: number;
  }): Promise<{ data: PreventiveActionEntity[]; total: number }> {
    const { shipId, status, page = 1, limit = 10 } = query;

    const ship = await this.shipValidationService.getShipById(shipId);

    const queryBuilder = this.preventiveActionRepository
      .createQueryBuilder('preventiveActions')
      .where('preventiveActions.shipId = :shipId', { shipId: ship.id });

    if (status) {
      queryBuilder.andWhere('preventiveActions.status = :status', { status });
    }

    const [data, total] = await queryBuilder
      .orderBy('preventiveActions.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return { data, total };
  }
}
