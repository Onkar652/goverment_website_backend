import { Test, TestingModule } from '@nestjs/testing';
import { PreventiveActionService } from './preventive-actions.service';
describe('CorrectiveActionsService', () => {
  let service: PreventiveActionService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PreventiveActionService],
    }).compile();

    service = module.get<PreventiveActionService>(PreventiveActionService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
