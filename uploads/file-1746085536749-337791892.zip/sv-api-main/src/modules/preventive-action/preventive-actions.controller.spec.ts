import { Test, TestingModule } from '@nestjs/testing';
import { PreventiveActionController } from './preventive-actions.controller';
import { PreventiveActionService } from './preventive-actions.service';

describe('PreventiveActionController', () => {
  let controller: PreventiveActionController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PreventiveActionController],
      providers: [PreventiveActionService],
    }).compile();

    controller = module.get<PreventiveActionController>(
      PreventiveActionController,
    );
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
