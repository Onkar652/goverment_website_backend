import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import {
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiQuery,
  ApiResponse,
} from '@nestjs/swagger';
import { PreventiveActionEntity } from 'src/entities/qhse-reports/preventive-measure.entity';
import { CreatePreventiveActionDto } from './dto/create-corrective-measure.dto';
import { PreventiveActionService } from './preventive-actions.service';

@Controller('preventive-action')
export class PreventiveActionController {
  constructor(
    private readonly preventiveActionService: PreventiveActionService,
  ) {}

  @Get()
  @ApiOperation({ summary: 'Get a list of preventive Action list' })
  @ApiResponse({
    status: 200,
    description: 'List of preventive Action with pagination details',
    schema: {
      type: 'object',
      properties: {
        data: {
          type: 'array',
          items: { $ref: '#/components/schemas/Re' },
        },
        total: {
          type: 'number',
          description: 'Total number of preventive Action matching the query',
        },
      },
    },
  })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship to filter preventive Action by',
    example: 1,
  })
  @ApiQuery({
    name: 'status',
    required: false,
    type: String,
    description:
      'Filter preventive Action by their status (e.g., active, draft)',
    example: 'active',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    type: Number,
    description: 'The page number for pagination',
    example: 1,
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    description: 'The number of preventive Action to return per page',
    example: 10,
  })
  async getPreventiveActions(
    @Query('shipId') shipId?: number,
    @Query('status') status?: string,
    @Query('page') page = 1,
    @Query('limit') limit = 10,
  ): Promise<{ data: PreventiveActionEntity[]; total: number }> {
    if (!shipId) {
      throw new BadRequestException('shipId is required');
    }
    return await this.preventiveActionService.getPreventiveAction({
      shipId,
      status,
      page,
      limit,
    });
  }

  @Get(':preventiveActionId')
  @ApiOperation({ summary: 'Get preventive Action info by ID' })
  @ApiResponse({
    status: 200,
    description: 'preventive Action info',
    type: PreventiveActionEntity,
  })
  @ApiResponse({ status: 404, description: 'preventive Action not found' })
  async getPreventiveActionById(
    @Param('preventiveActionId') preventiveActionId: string,
  ): Promise<PreventiveActionEntity> {
    return await this.preventiveActionService.getPreventiveActionById(
      preventiveActionId,
    );
  }

  @Post(':preventiveActionId')
  @ApiOperation({ summary: 'Update preventive Action Info' })
  @ApiResponse({
    status: 200,
    description: 'preventive Action info updated successfully',
    type: PreventiveActionEntity,
  })
  @ApiResponse({ status: 404, description: 'preventive Action not found' })
  async savePreventiveActions(
    @Param('preventiveActionId') preventiveActionId: string,
    @Body() preventiveActionDto: CreatePreventiveActionDto,
  ): Promise<PreventiveActionEntity> {
    return await this.preventiveActionService.savePreventiveActions(
      preventiveActionId,
      preventiveActionDto,
    );
  }

  @Post(':preventiveActionId/attachments')
  @UseInterceptors(FilesInterceptor('files'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Upload multiple attachments for a preventive Action',
    schema: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  async uploadAttachmentsForPreventiveAction(
    @Param('preventiveActionId') preventiveActionId: string,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<{ message: string }> {
    await this.preventiveActionService.uploadAttachmentsForPreventive(
      preventiveActionId,
      files,
    );
    return { message: 'Attachments uploaded successfully' };
  }
}
