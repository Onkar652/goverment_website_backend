import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { CertificationEntity } from 'src/entities/certifications/certification.entity'; // Added this to ensure it's included
import { CorrectiveActionEntity } from 'src/entities/qhse-reports/corrective-measure.entity';
import { PreventiveActionController } from './preventive-actions.controller';
import { PreventiveActionService } from './preventive-actions.service';
import { PreventiveActionEntity } from 'src/entities/qhse-reports/preventive-measure.entity';
import { ShipValidationService } from '../common/ship-validation.service';
import { AreaEntity } from 'src/entities/master-configs/area.entity'; // Ensure AreaEntity is imported if it’s part of your service logic
import { RequisitionEntity } from 'src/entities/requisitions/requisition.entity'; // Similarly, add requisition entity

@Module({
  imports: [
    TypeOrmModule.forFeature([
      FileStorageEntity,
      CorrectiveActionEntity,
      PreventiveActionEntity,
      CertificationEntity, // Added CertificationEntity
      AreaEntity, // Added AreaEntity
      RequisitionEntity, // Added RequisitionEntity
    ]),
  ],
  controllers: [PreventiveActionController],
  providers: [PreventiveActionService, ShipValidationService],
  exports: [PreventiveActionService],
})
export class PreventiveActionModule {}
