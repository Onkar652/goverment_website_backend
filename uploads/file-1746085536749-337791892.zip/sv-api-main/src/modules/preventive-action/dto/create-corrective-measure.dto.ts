import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsBoolean,
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';
import { CertificateStatus } from 'src/utils/models/common.types';

export class CreatePreventiveActionDto {
  @ApiProperty({
    example: 'API',
    description: 'Indicates the source of initiation',
  })
  @IsNotEmpty()
  @IsString()
  initiatedFrom: string;

  @ApiProperty({
    example: 101,
    description: 'ID of the ship associated with the preventive action',
  })
  @IsOptional()
  @IsInt()
  shipId?: number;

  @ApiPropertyOptional({
    example: 'CA-20240205-001',
    description: 'Unique preventive action ID',
  })
  @IsOptional()
  @IsString()
  preventiveActionId?: string;

  @ApiPropertyOptional({ example: 'Ensure compliance with safety protocols' })
  @IsOptional()
  @IsString()
  preventiveActionPlan?: string;

  @ApiPropertyOptional({ example: 'Fixed safety harness issue' })
  @IsOptional()
  @IsString()
  actionCarriedOut?: string;

  @ApiPropertyOptional({ example: true })
  @IsOptional()
  @IsBoolean()
  isEvidenceRequired?: boolean;

  @ApiPropertyOptional({ example: '2024-02-05T12:00:00Z' })
  @IsOptional()
  @IsDateString()
  nearMissReportIncidentDate?: string;

  @ApiPropertyOptional({ example: '2024-02-20T12:00:00Z' })
  @IsOptional()
  @IsDateString()
  targetDate?: string;

  @ApiProperty({
    description: 'Status of the certificate for the Preventive Report',
    enum: CertificateStatus,
    example: CertificateStatus.Draft,
  })
  @IsEnum(CertificateStatus)
  status: CertificateStatus;

  @ApiPropertyOptional({
    example: 12,
    description: 'User ID of the person in charge',
  })
  @IsOptional()
  @IsInt()
  personInChargeId?: number;

  @ApiPropertyOptional({
    example: 30,
    description: 'Report ID associated with the preventive action',
  })
  @IsOptional()
  @IsString()
  reportId?: string;

  @ApiPropertyOptional({
    example: 55,
    description: 'Work Order ID linked to this preventive action',
  })
  @IsOptional()
  @IsInt()
  workOrderId?: number;

  @ApiPropertyOptional({
    example: 42,
    description: 'Certificate ID linked to this preventive action',
  })
  @IsOptional()
  @IsInt()
  certificateId?: number;

  @ApiPropertyOptional({
    example: 78,
    description: 'Requisition ID linked to this preventive action',
  })
  @IsOptional()
  @IsInt()
  requisitionId?: number;
}
