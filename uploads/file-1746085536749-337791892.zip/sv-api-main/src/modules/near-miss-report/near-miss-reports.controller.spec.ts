import { Test, TestingModule } from '@nestjs/testing';
import { ReportsController } from './near-miss-reports.controller';
import { NearMissReportService } from './near-miss-reports.service';

describe('ReportsController', () => {
  let controller: ReportsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ReportsController],
      providers: [NearMissReportService],
    }).compile();

    controller = module.get<ReportsController>(ReportsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
