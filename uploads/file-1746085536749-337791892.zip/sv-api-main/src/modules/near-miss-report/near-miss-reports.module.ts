import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { IncidentActivityEntity } from 'src/entities/master-configs/incident-activity.entity';
import { EnvironmentLossEntity } from 'src/entities/potential-loss/environment-loss.entity';
import { LossPotentialEntity } from 'src/entities/potential-loss/potential-loss.entity';
import { Property } from 'src/entities/potential-loss/property.entity';
import { Service } from 'src/entities/potential-loss/service.entity';
import { CauseAnalysisEntity } from 'src/entities/qhse-reports/cause-analysis.entity';

import { CorrectiveActionEntity } from 'src/entities/qhse-reports/corrective-measure.entity';
import { PreventiveActionEntity } from 'src/entities/qhse-reports/preventive-measure.entity';
import { NearMissReportEntity } from 'src/entities/qhse-reports/near-miss-report.entity';
import { AuthModule } from '../auth/auth.module';
import { ShipValidationService } from '../common/ship-validation.service';
import { CorrectiveActionModule } from '../corrective-action/corrective-actions.module';
import { PreventiveActionModule } from '../preventive-action/preventive-actions.module';
import { ReportsController } from './near-miss-reports.controller';
import { NearMissReportService } from './near-miss-reports.service';

@Module({
  imports: [
    AuthModule,
    TypeOrmModule.forFeature([
      NearMissReportEntity,
      EnvironmentLossEntity,
      Property,
      Service,
      LossPotentialEntity,
      CauseAnalysisEntity,
      FileStorageEntity,
      CorrectiveActionEntity,
      PreventiveActionEntity,
      IncidentActivityEntity,
    ]),
    CorrectiveActionModule,
    PreventiveActionModule,
  ],
  controllers: [ReportsController],
  providers: [NearMissReportService, ShipValidationService],
  exports: [NearMissReportService],
})
export class NearMissReportModule {}
