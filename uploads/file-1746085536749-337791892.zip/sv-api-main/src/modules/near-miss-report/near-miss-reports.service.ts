import {
  BadRequestException,
  HttpStatus,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { EnvironmentLossEntity } from 'src/entities/potential-loss/environment-loss.entity';
import { LossPotentialEntity } from 'src/entities/potential-loss/potential-loss.entity';
import { RiskPotentialEntity } from 'src/entities/potential-loss/potential-risk.entity';
import { Property } from 'src/entities/potential-loss/property.entity';
import { Service } from 'src/entities/potential-loss/service.entity';
import { CauseAnalysisEntity } from 'src/entities/qhse-reports/cause-analysis.entity';
import { CorrectiveActionEntity } from 'src/entities/qhse-reports/corrective-measure.entity';
import { NearMissReportEntity } from 'src/entities/qhse-reports/near-miss-report.entity';
import { PreventiveActionEntity } from 'src/entities/qhse-reports/preventive-measure.entity';
import { CertificateStatus } from 'src/utils/models/common.types';
import { DataSource, EntityManager, In, Like, Repository } from 'typeorm';
import { ShipValidationService } from '../common/ship-validation.service';
import { CorrectiveActionsService } from '../corrective-action/corrective-actions.service';
import { PreventiveActionService } from '../preventive-action/preventive-actions.service';
import { CreateNearMissReportDto } from './dto/create-near-miss.dto';
import { CreatePotentialLossDto } from './dto/create-potential-loss.dto';
import { CreateCauseAnalysisDto } from './dto/initiate-near-miss-report.dto';
import { v4 as uuidv4 } from 'uuid';
import { DirectCauseEntity } from 'src/entities/master-configs/direct-cause.entity';
import { InDirectCauseEntity } from 'src/entities/master-configs/indirect-cause.entity';
import { RootCauseEntity } from 'src/entities/master-configs/root-cause.entity';
import { DeleteReportsDto } from './dto/delete-reports.dto';

@Injectable()
export class NearMissReportService {
  private nearMissReportRepository: Repository<NearMissReportEntity>;
  private saveCauseAnalysisRepository: Repository<CauseAnalysisEntity>;
  private preventiveActionRepository: Repository<PreventiveActionEntity>;
  private correctiveActionRepository: Repository<CorrectiveActionEntity>;
  private fileStorageRepository: Repository<FileStorageEntity>;
  constructor(
    private readonly dataSource: DataSource,
    private correctiveActionsService: CorrectiveActionsService,
    private preventiveActionService: PreventiveActionService,
    private shipValidationService: ShipValidationService,
  ) {
    this.fileStorageRepository =
      this.dataSource.getRepository(FileStorageEntity);
    this.preventiveActionRepository = this.dataSource.getRepository(
      PreventiveActionEntity,
    );
    this.correctiveActionRepository = this.dataSource.getRepository(
      CorrectiveActionEntity,
    );
    this.dataSource.getRepository(FileStorageEntity);
    this.saveCauseAnalysisRepository =
      this.dataSource.getRepository(CauseAnalysisEntity);
    this.nearMissReportRepository =
      this.dataSource.getRepository(NearMissReportEntity);
  }

  async initiateNearMissBookReport(
    shipId: number,
  ): Promise<CreateNearMissReportDto> {
    // Validate Ship
    const ship = await this.shipValidationService.getShipById(shipId);
    // Generate unique IDs
    const nearMissReportId = await this.generateUniqueNearMissReportId(
      ship.code,
    );
    const correctiveActionId =
      await this.correctiveActionsService.generateUniqueCorrectionId(ship.code);
    const preventiveActionId =
      await this.preventiveActionService.generateUniquePreventiveId(ship.code);

    const preventiveAction = this.preventiveActionRepository.create({
      preventiveActionId: preventiveActionId,
      status: CertificateStatus.Draft,
      initiatedFrom: 'Near Miss Report',
      findingReportId: nearMissReportId,
      preventiveActionsPlan: null,
      actionCarriedOut: null,
      isEvidenceRequired: null,
      nearMissReportIncidentDate: null,
      targetDate: null,
      personInCharge: null,
      ship,
    });
    const correctiveAction = this.correctiveActionRepository.create({
      correctiveActionId: correctiveActionId,
      status: CertificateStatus.Draft,
      initiatedFrom: 'Near Miss Report',
      findingReportId: nearMissReportId,
      correctiveActionsPlan: null,
      actionCarriedOut: null,
      isEvidenceRequired: null,
      nearMissReportIncidentDate: null,
      targetDate: null,
      personInCharge: null,
      ship,
    });

    const draftReport: NearMissReportEntity =
      this.nearMissReportRepository.create({
        nearMissReportId,
        status: CertificateStatus.Draft,
        ship,
        reportTitle: null,
        locationOnboard: null,
        targetCompletionDate: null,
        incidentDate: null,
        incidentTime: null,
        vesselActivity: null,
        vesselLocation: null,
        vesselStatus: null,
        timezone: null,
        attachments: null,
        activityAtTimeOfIncident: null,
        correctiveAction,
        preventiveAction,
      });

    const savedReport = await this.nearMissReportRepository.save(draftReport);

    return {
      nearMissReportId: savedReport.nearMissReportId,
      shipId,
      status: savedReport.status,
      reportTitle: savedReport.reportTitle,
      locationOnboard: savedReport.locationOnboard,
      targetCompletionDate: savedReport.targetCompletionDate,
      incidentDate: savedReport.incidentDate,
      incidentTime: savedReport.incidentTime,
      vesselActivity: savedReport.vesselActivity,
      vesselLocation: savedReport.vesselLocation,
      preventiveAction: savedReport.preventiveAction,
      correctiveAction: savedReport.correctiveAction,
      timezone: savedReport.timezone,
      vesselStatus: savedReport.vesselStatus,
      activityAtTimeOfIncident: savedReport.activityAtTimeOfIncident,
      eventDetails: savedReport.eventDetails,
      consequentialCategory: savedReport.consequentialCategory,
      rank: savedReport.rank,
      name: savedReport.name,
      reviewerName: savedReport.reviewerName,
      lossPotential: savedReport.lossPotential,
    };
  }

  async saveNearMissReport(
    createIncidentReportDto: CreateNearMissReportDto,
  ): Promise<{ status: HttpStatus; message: string }> {
    const { nearMissReportId } = createIncidentReportDto;
    if (!nearMissReportId) {
      throw new BadRequestException(
        'Report ID is required for updating a report.',
      );
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Fetch the existing report
      const report = await this.nearMissReportRepository.findOne({
        where: { nearMissReportId, disabled: false },
        relations: [
          'lossPotential',
          'lossPotential.potentialRisk',
          'lossPotential.environmentLosses',
          'lossPotential.properties',
          'lossPotential.services',
          'lossPotential.services.disruptionOfBusiness',
          'lossPotential.services.regulatoryCompliance',
          'lossPotential.services.reputationDamage',
          'causeAnalysis',
          'correctiveAction',
          'preventiveAction',
        ],
      });

      if (!report) {
        throw new NotFoundException(
          `Report with ID ${nearMissReportId} not found.`,
        );
      }

      report.status = 'draft';
      report.rank = createIncidentReportDto.rank;
      report.name = createIncidentReportDto.name;
      report.reviewerName = createIncidentReportDto.reviewerName;
      report.eventDetails = createIncidentReportDto.eventDetails;
      report.activityAtTimeOfIncident =
        createIncidentReportDto.activityAtTimeOfIncident;
      report.locationOnboard = createIncidentReportDto.locationOnboard;
      report.reportTitle = createIncidentReportDto.reportTitle;
      report.consequentialCategory =
        createIncidentReportDto.consequentialCategory;
      report.incidentDate =
        createIncidentReportDto.incidentDate || report.incidentDate;
      report.vesselActivity =
        createIncidentReportDto.vesselActivity || report.vesselActivity;
      report.vesselLocation =
        createIncidentReportDto.vesselLocation || report.vesselLocation;
      if (createIncidentReportDto.lossPotential) {
        await this.saveLossPotentials(
          createIncidentReportDto.lossPotential,
          report,
          queryRunner.manager,
        );
      }

      if (createIncidentReportDto.causeAnalysis) {
        await this.saveCauseAnalysis(
          createIncidentReportDto.causeAnalysis,
          report,
          queryRunner.manager,
        );
      }

      const {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        lossPotential,
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        causeAnalysis,
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        correctiveAction,
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        preventiveAction,
        ...reportData
      } = report;
      await queryRunner.manager.update(
        NearMissReportEntity,
        report.id,
        reportData,
      );
      // ***************************************************************************

      await queryRunner.commitTransaction();
      return {
        status: HttpStatus.OK,
        message: 'Near Miss report saved successfully',
      };
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw new InternalServerErrorException(
        `Failed to update report: ${error.message}`,
      );
    } finally {
      await queryRunner.release();
    }
  }

  async saveLossPotentials(
    lossPotentialDtos: CreatePotentialLossDto[],
    report: NearMissReportEntity,
    manager: EntityManager,
  ): Promise<void> {
    if (!lossPotentialDtos.length) return;

    const existingLosses = report.lossPotential || [];
    const existingLossMap = new Map(
      existingLosses.map((loss) => [loss.type, loss]),
    );

    for (const dto of lossPotentialDtos) {
      let potentialLoss = existingLossMap.get(dto.type);

      if (potentialLoss) {
        manager.merge(LossPotentialEntity, potentialLoss, dto);

        if (dto.potentialRisk) {
          potentialLoss.potentialRisk = await manager.save(
            RiskPotentialEntity,
            {
              ...dto.potentialRisk,
              id: potentialLoss.potentialRisk?.id || undefined,
            },
          );
        }

        if (dto.environmentDetails) {
          // Remove existing environment losses and replace them with new ones
          await manager.delete(EnvironmentLossEntity, {
            environment: potentialLoss,
          });

          potentialLoss.environmentLosses = await manager.save(
            EnvironmentLossEntity,
            dto.environmentDetails.map((env) => ({
              ...env,
              environment: potentialLoss,
            })),
          );
        }

        if (dto.propertyDetails) {
          potentialLoss.properties = await manager.save(Property, {
            ...dto.propertyDetails,
            id: potentialLoss.properties?.id || undefined,
          });
        }

        if (dto.serviceDetails) {
          if (!potentialLoss.services) {
            // Initialize an empty service entity if it doesn't exist
            potentialLoss.services = manager.create(Service);
          }

          // Save and update each risk field separately
          potentialLoss.services.disruptionOfBusiness = await manager.save(
            RiskPotentialEntity,
            {
              ...dto.serviceDetails.disruptionOfBusiness,
              id: potentialLoss.services?.disruptionOfBusiness?.id || undefined,
            },
          );

          potentialLoss.services.regulatoryCompliance = await manager.save(
            RiskPotentialEntity,
            {
              ...dto.serviceDetails.regulatoryCompliance,
              id: potentialLoss.services?.regulatoryCompliance?.id || undefined,
            },
          );

          potentialLoss.services.reputationDamage = await manager.save(
            RiskPotentialEntity,
            {
              ...dto.serviceDetails.reputationDamage,
              id: potentialLoss.services?.reputationDamage?.id || undefined,
            },
          );

          // Save the updated service entity
          potentialLoss.services = await manager.save(
            Service,
            potentialLoss.services,
          );
        }
        await manager.save(LossPotentialEntity, potentialLoss);
      } else {
        // Create new loss and related entities
        potentialLoss = manager.create(LossPotentialEntity, {
          ...dto,
          nearMissReport: { id: report.id },
        });
        potentialLoss = await manager.save(LossPotentialEntity, potentialLoss);

        if (dto.potentialRisk) {
          potentialLoss.potentialRisk = await manager.save(
            RiskPotentialEntity,
            dto.potentialRisk,
          );
        }

        if (dto.environmentDetails) {
          potentialLoss.environmentLosses = await manager.save(
            EnvironmentLossEntity,
            dto.environmentDetails.map((env) => ({
              ...env,
              environment: potentialLoss,
            })),
          );
        }

        if (dto.propertyDetails) {
          potentialLoss.properties = await manager.save(
            Property,
            dto.propertyDetails,
          );
        }

        if (dto.serviceDetails) {
          potentialLoss.services = await manager.save(Service, {
            ...dto.serviceDetails,
            disruptionOfBusiness: await manager.save(
              RiskPotentialEntity,
              dto.serviceDetails.disruptionOfBusiness,
            ),
            regulatoryCompliance: await manager.save(
              RiskPotentialEntity,
              dto.serviceDetails.regulatoryCompliance,
            ),
            reputationDamage: await manager.save(
              RiskPotentialEntity,
              dto.serviceDetails.reputationDamage,
            ),
          });
        }

        report.lossPotential.push(potentialLoss);

        // newLosses.push(potentialLoss);
      }
    }

    // if (newLosses.length) {
    //   await manager.save(LossPotentialEntity, newLosses);
    // }

    // Delete old losses not included in the update
    const updatedLossTypes = new Set(lossPotentialDtos.map((dto) => dto.type));
    const lossesToDelete = existingLosses.filter(
      (loss) => !updatedLossTypes.has(loss.type),
    );

    if (lossesToDelete.length) {
      await manager.remove(LossPotentialEntity, lossesToDelete);
    }
  }

  private async saveCauseAnalysis(
    causeAnalysisDto: CreateCauseAnalysisDto,
    report: NearMissReportEntity,
    manager: EntityManager,
  ) {
    let causeAnalysis: CauseAnalysisEntity;

    // Check if the report already has a CauseAnalysis entity with a business identifier (causeId)
    if (report.causeAnalysis && report.causeAnalysis.causeId) {
      // UPDATE PATH: Merge incoming data with the existing CauseAnalysis record
      causeAnalysis = manager.merge(CauseAnalysisEntity, report.causeAnalysis, {
        causeId: report.causeAnalysis.causeId, // Keep the same business id
        directCauseDescription: causeAnalysisDto.directCauseDescription,
        indirectCauseDescription: causeAnalysisDto.indirectCauseDescription,
        rootCauseDescription: causeAnalysisDto.rootCauseDescription,
        directCause: {
          id: causeAnalysisDto.directCauseId,
        } as DirectCauseEntity,
        indirectCause: {
          id: causeAnalysisDto.indirectCauseId,
        } as InDirectCauseEntity,
        rootCause: { id: causeAnalysisDto.rootCauseId } as RootCauseEntity,
      });
      causeAnalysis = await manager.save(CauseAnalysisEntity, causeAnalysis);
    } else {
      // CREATE PATH: Generate a new UUID for causeId and create a new CauseAnalysis entity.
      const newCauseId = uuidv4();

      causeAnalysis = manager.create(CauseAnalysisEntity, {
        causeId: newCauseId, // Set the generated UUID as the business identifier
        directCauseDescription: causeAnalysisDto.directCauseDescription,
        indirectCauseDescription: causeAnalysisDto.indirectCauseDescription,
        rootCauseDescription: causeAnalysisDto.rootCauseDescription,
        // Link to the near miss report using only the primary key to avoid circular references
        nearMissReport: { id: report.id } as NearMissReportEntity,
        // Reference the master cause records by their IDs
        directCause: {
          id: causeAnalysisDto.directCauseId,
        } as DirectCauseEntity,
        indirectCause: {
          id: causeAnalysisDto.indirectCauseId,
        } as InDirectCauseEntity,
        rootCause: { id: causeAnalysisDto.rootCauseId } as RootCauseEntity,
      });
      causeAnalysis = await manager.save(CauseAnalysisEntity, causeAnalysis);
      // Optionally assign the newly created cause analysis back to the report for in-memory reference
      report.causeAnalysis = causeAnalysis;
    }

    return causeAnalysis;
  }

  async generateUniqueNearMissReportId(shipCode: string): Promise<string> {
    const currentYear = new Date().getFullYear().toString().slice(-2);

    // Fetch the Ship's metadata (serialNumber)
    const lastReport = await this.nearMissReportRepository.findOne({
      where: { nearMissReportId: Like(`NM-${shipCode}-${currentYear}%`) },
      order: { nearMissReportId: 'DESC' },
    });

    // If the ship metadata doesn't exist, create it with serial number 1
    let serialNumber = 1; // Default serial if no previous report exists

    if (lastReport) {
      const lastReportIdParts = lastReport.nearMissReportId.split('-');
      const lastYear = lastReportIdParts[2].substring(0, 2); // Extract year from last report ID
      const lastSerial = parseInt(lastReportIdParts[2].substring(2), 10); // Extract serial number

      if (lastYear === currentYear) {
        serialNumber = lastSerial + 1; // Increment only if same year
      }
    }

    const paddedSerial = serialNumber.toString().padStart(3, '0');
    return `NM-${shipCode}-${currentYear}${paddedSerial}`;
  }

  async getReports(query: {
    shipId: number;
    status?: string;
    page: number;
    limit: number;
  }) {
    const { shipId, status, page = 1, limit = 10 } = query;

    const ship = await this.shipValidationService.getShipById(shipId);

    const queryBuilder = this.nearMissReportRepository
      .createQueryBuilder('near_miss_report')
      .where('near_miss_report.shipId = :shipId', { shipId: ship.id })
      .andWhere('near_miss_report.disabled = :disabled', { disabled: false });

    if (status) {
      queryBuilder.andWhere('near_miss_report.status = :status', { status });
    }
    const [data, total] = await queryBuilder
      .orderBy('near_miss_report.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return { data, total };
  }

  async getReportById(nearMissReportId: string): Promise<NearMissReportEntity> {
    const report = await this.nearMissReportRepository
      .createQueryBuilder('near_miss_report')
      .leftJoinAndSelect('near_miss_report.ship', 'ship')
      .leftJoin('near_miss_report.attachments', 'attachments')
      .addSelect([
        'attachments.id',
        'attachments.fileName',
        'attachments.mimeType',
        'attachments.createdOn',
      ])

      .leftJoinAndSelect(
        'near_miss_report.correctiveAction',
        'corrective_action',
      )
      .leftJoinAndSelect('near_miss_report.lossPotential', 'loss_potential')
      .leftJoinAndSelect('loss_potential.potentialRisk', 'potential_risk')
      .leftJoinAndSelect('loss_potential.environmentLosses', 'environment_loss')
      .leftJoinAndSelect('loss_potential.properties', 'property')
      .leftJoinAndSelect('loss_potential.services', 'service')
      // For the Service relation, join its nested RiskPotential relations
      .leftJoinAndSelect('service.disruptionOfBusiness', 'disruption')
      .leftJoinAndSelect('service.regulatoryCompliance', 'regulatory')
      .leftJoinAndSelect('service.reputationDamage', 'reputation')
      .leftJoinAndSelect('near_miss_report.causeAnalysis', 'cause_analysis')
      .leftJoinAndSelect('cause_analysis.directCause', 'direct_cause')
      .leftJoinAndSelect('cause_analysis.indirectCause', 'indirect_cause')
      .leftJoinAndSelect('cause_analysis.rootCause', 'root_cause')
      .leftJoinAndSelect(
        'near_miss_report.preventiveAction',
        'preventive_action',
      )

      .where('near_miss_report.nearMissReportId = :nearMissReportId', {
        nearMissReportId,
      })
      .getOne();

    if (!report) {
      throw new NotFoundException(
        `Report with ID ${nearMissReportId} not found.`,
      );
    }

    return report;
  }

  async uploadAttachmentsForNearMissReport(
    nearMissReportId: string,
    files: Express.Multer.File[],
  ): Promise<void> {
    const nearMissReport = await this.nearMissReportRepository.findOne({
      where: { nearMissReportId, disabled: false },
    });

    if (!nearMissReport) {
      throw new NotFoundException(
        `Report with ID ${nearMissReportId} not found.`,
      );
    }

    const attachments = files.map((file) =>
      this.fileStorageRepository.create({
        data: file.buffer,
        mimeType: file.mimetype,
        fileName: file.originalname,
        nearMissReport,
      }),
    );

    await this.fileStorageRepository.save(attachments);
  }

  async deleteReportsByReportIds(
    deleteReportsDto: DeleteReportsDto,
  ): Promise<{ status: HttpStatus; message: string }> {
    const { reportIds } = deleteReportsDto;

    // Fetch all reports matching the given reportIds that are not already disabled.
    const reports = await this.nearMissReportRepository.find({
      where: {
        nearMissReportId: In(reportIds),
        disabled: false,
      },
    });

    if (reports.length === 0) {
      throw new NotFoundException(
        `No reports found for IDs: ${reportIds.join(', ')}`,
      );
    }

    // Identify reports that are not in "draft" status.
    const notDraftReports = reports.filter(
      (report) => report.status.toLowerCase() !== 'draft',
    );

    if (notDraftReports.length > 0) {
      throw new BadRequestException(
        `Reports with IDs ${notDraftReports.map((r) => r.nearMissReportId).join(', ')} are not in draft status and cannot be deleted.`,
      );
    }

    // Soft delete: set disabled flag to true for each report.
    reports.forEach((report) => {
      report.disabled = true;
    });

    // Save all updated reports in one call.
    await this.nearMissReportRepository.save(reports);

    return {
      status: HttpStatus.OK,
      message: `Successfully deleted ${reports.length} reports.`,
    };
  }
}
