import { Test, TestingModule } from '@nestjs/testing';
import { NearMissReportService } from './near-miss-reports.service';
describe('ReportsService', () => {
  let service: NearMissReportService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [NearMissReportService],
    }).compile();

    service = module.get<NearMissReportService>(NearMissReportService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
