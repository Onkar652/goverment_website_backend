import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { ValidateNested } from 'class-validator';
import { PotentialRiskDto } from './potential-risk.dto';

export class ServiceDetailsDto {
  @ApiProperty({
    description: 'Disruption of business risk details',
    type: PotentialRiskDto,
  })
  @ValidateNested()
  @Type(() => PotentialRiskDto)
  disruptionOfBusiness: PotentialRiskDto;

  @ApiProperty({
    description: 'Regulatory compliance risk details',
    type: PotentialRiskDto,
  })
  @ValidateNested()
  @Type(() => PotentialRiskDto)
  regulatoryCompliance: PotentialRiskDto;

  @ApiProperty({
    description: 'Reputation damage risk details',
    type: PotentialRiskDto,
  })
  @ValidateNested()
  @Type(() => PotentialRiskDto)
  reputationDamage: PotentialRiskDto;
}
