import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsString, IsOptional } from 'class-validator';

export class EnvironmentDetailsDto {
  @ApiProperty({ description: 'Type of pollution', example: 'Oil Spill' })
  @IsString()
  typeOfPollution: string;

  @ApiProperty({
    description: 'Environmental impact',
    example: 'Marine life affected',
  })
  @IsString()
  environmentImpact: string;

  @ApiProperty({ description: 'Was there a spillage?', example: true })
  isSpillage: boolean;

  @ApiPropertyOptional({
    description: 'Quantity of spillage (in liters)',
    example: 50,
  })
  @IsOptional()
  quantityOfSpillage?: number;

  @ApiPropertyOptional({
    description: 'Additional remarks',
    example: 'Immediate cleanup performed',
  })
  @IsOptional()
  @IsString()
  remarks?: string;
}
