import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class PropertyDetailsDto {
  @ApiProperty({
    description: 'Incident classification',
    example: 'Structural Damage',
  })
  @IsString()
  incidentClassification: string;

  @ApiProperty({
    description: 'Incident sub-classification',
    example: 'Hull Breach',
  })
  @IsString()
  incidentSubClassification: string;
}
