import { ApiProperty } from '@nestjs/swagger';
import { IsArray, ArrayNotEmpty, IsString } from 'class-validator';

export class DeleteReportsDto {
  @ApiProperty({
    description: 'Array of nearMissReportId values for reports to delete',
    type: [String],
  })
  @IsArray()
  @ArrayNotEmpty()
  @IsString({ each: true })
  reportIds: string[];
}
