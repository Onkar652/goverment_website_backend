import { IsNotEmpty, IsNumber } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class InitiateNearMissBookReportDTO {
  @ApiProperty({
    description: 'ID of the ship to associate with the report',
    example: 1,
  })
  @IsNotEmpty()
  @IsNumber()
  shipId: number;
}
