import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class PotentialRiskDto {
  @ApiProperty({
    description: 'Likelihood of occurrence',
    example: 'medium',
  })
  @IsString()
  @IsOptional()
  likelihood: string;

  @ApiProperty({
    description: 'Consequence severity',
    example: 'major',
  })
  @IsString()
  @IsOptional()
  consequence: string;

  @ApiProperty({
    description: 'Overall risk level',
    example: 'high',
  })
  @IsString()
  @IsOptional()
  riskLevel: string;
}
