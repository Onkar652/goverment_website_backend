import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class InitiateNearMissReportDto {
  @ApiProperty({ example: 1 })
  @IsNotEmpty()
  @IsNumber()
  shipId: number;
}

export class CreateCauseAnalysisDto {
  @ApiPropertyOptional({ description: 'Optional cause analysis identifier' })
  causeId?: string;

  @ApiPropertyOptional({
    description: 'Direct cause description text',
    example: 'Operator error',
  })
  directCauseDescription?: string;

  @ApiPropertyOptional({
    description: 'Indirect cause description text',
    example: 'Lack of supervision',
  })
  indirectCauseDescription?: string;

  @ApiPropertyOptional({
    description: 'Root cause description text',
    example: 'Systemic issues in training',
  })
  rootCauseDescription?: string;

  @ApiProperty({
    description: 'ID of the master record for direct cause',
    example: 1,
  })
  directCauseId: number;

  @ApiProperty({
    description: 'ID of the master record for indirect cause',
    example: 2,
  })
  indirectCauseId: number;

  @ApiProperty({
    description: 'ID of the master record for root cause',
    example: 3,
  })
  rootCauseId: number;
}
