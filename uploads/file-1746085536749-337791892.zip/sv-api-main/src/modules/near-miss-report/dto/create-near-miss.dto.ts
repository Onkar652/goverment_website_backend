import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsNumber,
  IsObject,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

import { Type } from 'class-transformer';
import { CreateCorrectiveActionDto } from 'src/modules/corrective-action/dto/create-corrective-measure.dto';
import { CreatePreventiveActionDto } from 'src/modules/preventive-action/dto/create-corrective-measure.dto';
import { CreatePotentialLossDto } from './create-potential-loss.dto';
import { CreateCauseAnalysisDto } from './initiate-near-miss-report.dto';

export class CreateNearMissReportDto {
  @ApiProperty({
    description: 'ID of the ship associated with the report',
    example: 1,
  })
  @IsNumber()
  shipId: number;

  @ApiPropertyOptional({
    example: 'NM-20240205-001',
    description: 'Unique corrective action ID',
  })
  @IsString()
  nearMissReportId: string;

  @ApiProperty({
    description: 'Incident date',
    example: '2025-01-15',
  })
  @IsOptional()
  @IsDateString()
  incidentDate: Date;

  @ApiPropertyOptional({
    description: 'Status of the report',
    example: 'draft',
  })
  @IsOptional()
  @IsString()
  status?: string = 'Draft';

  @ApiProperty({
    description: 'Title of the report',
    example: 'Collision Report',
  })
  @IsString()
  @IsOptional()
  reportTitle?: string;

  @IsOptional()
  @IsString()
  reviewerName?: string;

  @IsOptional()
  @IsString()
  name?: string;

  @IsOptional()
  @IsString()
  rank?: string;

  @ApiProperty({
    description: 'Location onboard the vessel where the incident occurred',
    example: 'Deck 5',
  })
  @IsString()
  @IsOptional()
  locationOnboard?: string;

  @ApiProperty({
    description: 'Target completion date for the report',
    example: '2025-02-28',
  })
  @IsOptional()
  @IsDateString()
  targetCompletionDate?: Date;

  @ApiProperty({
    description: 'Incident time',
    example: '14:30:00',
  })
  @IsOptional()
  @IsString()
  incidentTime?: string;

  @ApiProperty({
    description: 'Vessel activity at the time of the incident',
    example: 'Navigating through the channel',
  })
  @IsOptional()
  @IsString()
  vesselActivity: string;

  @ApiProperty({
    description: 'Location of the vessel',
    example: 'Port of Singapore',
  })
  @IsString()
  @IsOptional()
  vesselLocation?: string;

  @ApiProperty({
    description: 'Current status of the vessel',
    example: 'Underway',
  })
  @IsString()
  @IsOptional()
  vesselStatus?: string;

  @ApiProperty({
    description: 'Timezone associated with the report',
    example: 'Asia/Kolkata',
  })
  @IsString()
  @IsOptional()
  timezone?: string;

  @ApiProperty({
    description: 'Activity at the time of the incident',
    example: 'Preparing to dock',
  })
  @IsOptional()
  @IsString()
  activityAtTimeOfIncident?: string;

  @ApiProperty({
    description: 'Potential loss event details',
    example: 'Event details',
  })
  @IsOptional()
  @IsString()
  eventDetails?: string;

  @ApiProperty({
    description: 'Potential loss consequence category',
    example: 'High',
  })
  @IsOptional()
  @IsString()
  consequentialCategory?: string;

  @ApiPropertyOptional({
    description: 'List of potential losses associated with this report',
    type: [CreatePotentialLossDto],
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreatePotentialLossDto)
  lossPotential?: CreatePotentialLossDto[];

  @ApiPropertyOptional({
    description: 'Activity at the time of the incident',
    type: CreateCauseAnalysisDto,
  })
  @IsOptional()
  @IsObject()
  causeAnalysis?: CreateCauseAnalysisDto;

  @ApiProperty({
    description: 'Preventive Measures Actions',
    example: 'Preparing to Actions',
  })
  @IsOptional()
  @IsObject()
  preventiveAction?: CreatePreventiveActionDto;

  // @ApiProperty({
  //   description: 'Preventive Measures Actions',
  //   example: 'Preparing to Actions',
  // })
  // @IsOptional()
  // @IsObject()
  // potentialSecurityLoss?: CreatePreventiveActionDto;

  @ApiProperty({
    description: 'corrective Actions',
    example: 'Preparing to Actions',
  })
  @IsOptional()
  @IsObject()
  correctiveAction?: CreateCorrectiveActionDto;
}
