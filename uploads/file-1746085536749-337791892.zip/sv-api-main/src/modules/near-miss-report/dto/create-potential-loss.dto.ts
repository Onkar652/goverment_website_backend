import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsEnum, IsOptional, ValidateNested } from 'class-validator';
import { PotentialLossType } from 'src/entities/potential-loss/potential-loss.entity';
import { EnvironmentDetailsDto } from './environment-loss-details.dto';
import { PotentialRiskDto } from './potential-risk.dto';
import { PropertyDetailsDto } from './property-loss-details.dto';
import { ServiceDetailsDto } from './service-loss-details.dto';

export class CreatePotentialLossDto {
  @ApiProperty({
    description: 'Type of potential loss',
    enum: PotentialLossType,
  })
  @IsEnum(PotentialLossType)
  type: PotentialLossType;

  // Potential Risk (Not required for Service Type)
  @ApiPropertyOptional({
    description: 'Potential risk details',
    type: PotentialRiskDto,
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => PotentialRiskDto)
  potentialRisk?: PotentialRiskDto;

  // Environment Type - Table in UI (OneToMany)
  @ApiPropertyOptional({
    description: 'Environment details (if applicable)',
    type: [EnvironmentDetailsDto],
  })
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => EnvironmentDetailsDto)
  environmentDetails?: EnvironmentDetailsDto[];

  // Property Type - Has additional classification fields
  @ApiPropertyOptional({
    description: 'Property details (if applicable)',
    type: PropertyDetailsDto,
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => PropertyDetailsDto)
  propertyDetails?: PropertyDetailsDto;

  // Service Type - Contains three separate potential risks
  @ApiPropertyOptional({
    description: 'Service details (if applicable)',
    type: ServiceDetailsDto,
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => ServiceDetailsDto)
  serviceDetails?: ServiceDetailsDto;
}
