import {
  BadRequestException,
  Body,
  Controller,
  Get,
  HttpStatus,
  Param,
  Post,
  Query,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import {
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiQuery,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { NearMissReportEntity } from 'src/entities/qhse-reports/near-miss-report.entity';
import { CreateNearMissReportDto } from './dto/create-near-miss.dto';
import { NearMissReportService } from './near-miss-reports.service';
import { AuthAuditInterceptor } from 'src/gaurds/auth-gaurd.interceptor';
import { AuthGuard } from 'src/gaurds/auth.gaurd';
import { DeleteReportsDto } from './dto/delete-reports.dto';

@ApiTags('Near miss report')
@Controller('near-miss-reports')
@UseGuards(AuthGuard)
@UseInterceptors(AuthAuditInterceptor)
export class ReportsController {
  constructor(private readonly reportsService: NearMissReportService) {}

  @Post('/initiate-near-miss-report')
  @ApiOperation({ summary: 'Initiate a report and generate a reportCode' })
  @ApiResponse({ status: 201, description: 'Report initiated successfully' })
  @ApiBody({
    description: 'Ship ID for which the report is being initiated',
    schema: {
      type: 'object',
      properties: {
        shipId: {
          type: 'integer',
          description: 'ID of the ship',
          example: 1,
        },
      },
    },
  })
  async initiateReport(@Body('shipId') shipId: number) {
    return await this.reportsService.initiateNearMissBookReport(shipId);
  }

  @Get('allReports')
  @ApiOperation({ summary: 'Get a list of reports' })
  @ApiResponse({
    status: 200,
    description: 'List of reports with pagination details',
    schema: {
      type: 'object',
      properties: {
        data: {
          type: 'array',
          items: { $ref: '#/components/schemas/Re' },
        },
        total: {
          type: 'number',
          description: 'Total number of reports matching the query',
        },
      },
    },
  })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship to filter reports by',
    example: 1,
  })
  @ApiQuery({
    name: 'status',
    required: false,
    type: String,
    description: 'Filter reports by their status (e.g., active, draft)',
    example: 'active',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    type: Number,
    description: 'The page number for pagination',
    example: 1,
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    description: 'The number of reports to return per page',
    example: 10,
  })
  async getReports(
    @Query('shipId') shipId: number,
    @Query('status') status?: string,
    @Query('page') page = 1,
    @Query('limit') limit = 10,
  ) {
    if (!shipId) {
      throw new BadRequestException('shipId is required');
    }
    return await this.reportsService.getReports({
      shipId,
      status,
      page,
      limit,
    });
  }

  @Get(':nearMissReportId')
  @ApiOperation({ summary: 'Get report details by ID' })
  @ApiResponse({
    status: 200,
    description: 'Report details',
    type: NearMissReportEntity,
  })
  @ApiResponse({ status: 404, description: 'Report not found' })
  async getReportById(
    @Param('nearMissReportId') nearMissReportId: string,
  ): Promise<NearMissReportEntity> {
    return await this.reportsService.getReportById(nearMissReportId);
  }

  @Post('save-draft')
  @ApiOperation({ summary: 'Update report details' })
  @ApiResponse({
    status: 200,
    description: 'Report updated successfully',
    type: NearMissReportEntity,
  })
  @ApiResponse({ status: 404, description: 'Report not found' })
  async saveReport(
    @Body() createIncidentReportDto: CreateNearMissReportDto,
  ): Promise<{ status: HttpStatus; message: string }> {
    return await this.reportsService.saveNearMissReport(
      createIncidentReportDto,
    );
  }

  @Post(':nearMissReportId/attachments')
  @UseInterceptors(FilesInterceptor('files'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Upload multiple attachments for a Report',
    schema: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  async uploadAttachmentsForNearMissReport(
    @Param('nearMissReportId') nearMissReportId: string,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<{ message: string }> {
    await this.reportsService.uploadAttachmentsForNearMissReport(
      nearMissReportId,
      files,
    );
    return { message: 'Attachments uploaded successfully' };
  }

  @Post('delete')
  @ApiOperation({
    summary: 'Soft Delete Reports',
    description:
      'Soft delete reports by report IDs. Only reports with status "draft" can be deleted.',
  })
  @ApiBody({ type: DeleteReportsDto })
  @ApiResponse({ status: 200, description: 'Reports deleted successfully.' })
  @ApiResponse({
    status: 400,
    description: 'Bad request: Reports not in draft status or invalid IDs.',
  })
  @ApiResponse({
    status: 404,
    description: 'Not Found: Reports with provided IDs not found.',
  })
  async deleteReports(
    @Body() deleteReportsDto: DeleteReportsDto,
  ): Promise<{ status: HttpStatus; message: string }> {
    return this.reportsService.deleteReportsByReportIds(deleteReportsDto);
  }
}
