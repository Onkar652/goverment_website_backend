import { Injectable, NotFoundException } from '@nestjs/common';
import * as moment from 'moment';
import { RunningHoursEntity } from 'src/entities/shipActions/running-hours.entity';
import { WorkOrder } from 'src/entities/shipActions/work-order.entity';
import { MainPart } from 'src/entities/shipParts/main-parts.entity';
import { Ship } from 'src/entities/ships/ships.entity';
import { UserRanks } from 'src/utils/models/common.types';
import { DataSource, In, Not, Repository } from 'typeorm';
import { UpdateRunningHourDto } from './dto/update-running-hour.dto';

@Injectable()
export class RunningHoursService {
  private runningHoursRepository: Repository<RunningHoursEntity>;
  private shipRepo: Repository<Ship>;
  private workOrderRepository: Repository<WorkOrder>;
  private mainPartRepository: Repository<MainPart>;

  private _shipCode: string = '';
  _ship: Ship;
  constructor(private readonly dataSource: DataSource) {
    this.runningHoursRepository =
      this.dataSource.getRepository(RunningHoursEntity);
    this.shipRepo = this.dataSource.getRepository(Ship);
    this.workOrderRepository = this.dataSource.getRepository(WorkOrder);
    this.mainPartRepository = this.dataSource.getRepository(MainPart);
  }

  async initRunningHours(shipId: number): Promise<void> {
    const queryRunner = this.dataSource.createQueryRunner();

    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const mainParts = await queryRunner.manager
        .createQueryBuilder(MainPart, 'mainPart')
        .innerJoin('mainPart.components', 'component')
        .innerJoin('component.workOrderConfig', 'workOrderConfig')
        .innerJoin('mainPart.ship', 'ship', 'ship.id = :shipId', { shipId })
        .where('workOrderConfig.collectRunHours = :collectRunHours', {
          collectRunHours: true,
        })
        .distinct(true)
        .getMany();

      console.log('Main Parts:', mainParts);

      for (const mainPart of mainParts) {
        // Check if running hours already exist for this MainPart
        const existingRunningHours = await queryRunner.manager.findOne(
          RunningHoursEntity,
          { where: { mainPart: mainPart } },
        );

        if (!existingRunningHours) {
          const runningHours = new RunningHoursEntity();
          runningHours.mainPart = mainPart;
          runningHours.collectFrequency = '1W';
          runningHours.updatedByRank = UserRanks.CHIEF_ENGINEER;
          await queryRunner.manager.save(runningHours);
        }
      }

      await queryRunner.commitTransaction();
    } catch (error) {
      // If we catch any error, we must rollback the changes made in the transaction
      await queryRunner.rollbackTransaction();
      throw new Error(`Failed to initialize running hours: ${error.message}`);
    } finally {
      // You need to release a queryRunner which was manually instantiated
      await queryRunner.release();
    }
  }

  async findRunningHoursByShipAndMainPart(
    shipId: number,
    mainPartId?: number,
  ): Promise<any[]> {
    // Return type is now any[] to accommodate custom object structure
    await this.getShipById(shipId);

    const runningHours = await this.runningHoursRepository
      .createQueryBuilder('runningHours')
      .innerJoinAndSelect('runningHours.mainPart', 'mainPart')
      .where('mainPart.shipId = :shipId', { shipId })
      .andWhere(mainPartId ? 'mainPart.id = :mainPartId' : '1=1', {
        mainPartId,
      })
      .andWhere('runningHours.order != -1') // Exclude rows where order = -1
      .orderBy('runningHours.order', 'DESC')
      .getMany();

    // Map the results to the expected return structure
    return runningHours.map((hour) => ({
      id: hour.id,
      dueDateForCounterReading: hour.dueDateForCounterReading,
      lastReportedDate: hour.lastReportedDate,
      lastReportedValue: hour.lastReportedValue,
      actualValue: hour.actualValue,
      dailyAverage: hour.dailyAverage,
      collectFrequency: hour.collectFrequency,
      updatedByRank: hour.updatedByRank,
      partName: hour.mainPart.name, // The part name is now directly from the mainPart
      mainPartId: hour.mainPart.id, // mainPart ID directly from the relation
    }));
  }

  private calculateNextDueDate(currentDate: Date, frequency: string): Date {
    const momentDate = moment(currentDate);
    const [amount, unit] = frequency.match(/\d+|\D+/g); // Splits '1W' into ['1', 'W']

    return momentDate
      .add(parseInt(amount), unit as moment.unitOfTime.DurationConstructor)
      .toDate();
  }

  private calculateDailyAverage(
    lastValue: number,
    newValue: number,
    lastDate: Date,
    currentDate: Date,
  ): number {
    if (!lastDate || !currentDate) return 0; // No previous date to compare to

    const timeDiff = currentDate.getTime() - lastDate.getTime();
    const diffDays = timeDiff / (1000 * 3600 * 24); // This now includes partial days

    if (diffDays <= 0) return 0; // No elapsed days or negative difference

    return (newValue - lastValue) / diffDays; // Adjusted for exact time differences
  }

  async updateRunningHours(
    shipId: number,
    updates: UpdateRunningHourDto[],
  ): Promise<RunningHoursEntity[]> {
    await this.getShipById(shipId);
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    const updatedEntities: RunningHoursEntity[] = [];
    try {
      for (const update of updates) {
        const currentEntity = await this.runningHoursRepository.findOne({
          where: { id: update.id },
          relations: ['mainPart'],
        });

        if (currentEntity?.mainPart) {
          const { currentReading: newValue, currentReadingDate } = update;
          const newDate = new Date(currentReadingDate || new Date());

          // Get all components linked to the updated MainPart
          const mainPart = await this.mainPartRepository.findOne({
            where: { id: currentEntity.mainPart.id },
            relations: ['components'],
          });
          if (mainPart) {
            for (const component of mainPart.components) {
              const workOrders = await this.workOrderRepository.find({
                where: {
                  component: { id: component.id },
                  status: Not(In(['done'])),
                  config: { collectRunHours: true },
                },
                relations: ['config'],
              });
              for (const workOrder of workOrders) {
                const { maxRunHoursToService, reminderValue } =
                  workOrder.config;
                const baseCounter =
                  workOrder.counterAtEnd ?? workOrder.counterAtCreation ?? 0;

                // Calculate thresholds
                const overdueThreshold = baseCounter + maxRunHoursToService;
                const dueThreshold = overdueThreshold - reminderValue;

                // Evaluate work order status
                if (workOrder.status !== 'overdue') {
                  if (newValue >= overdueThreshold) {
                    workOrder.status = 'overdue';
                  } else if (newValue >= dueThreshold) {
                    workOrder.status = 'open';
                  } else {
                    workOrder.status = 'inwindow';
                  }
                }

                // Update work order counters
                workOrder.lastReportedRunHours = newValue;
                workOrder.counterAtEnd = newValue;

                await queryRunner.manager.save(workOrder);
              }
            }
          }

          const nextDueDate = this.calculateNextDueDate(
            newDate,
            currentEntity.collectFrequency,
          );
          const dailyAverage = this.calculateDailyAverage(
            currentEntity.lastReportedValue,
            newValue,
            currentEntity.lastReportedDate,
            newDate,
          );

          // Set the current and last reported values
          currentEntity.lastReportedValue = newValue || 0;
          currentEntity.lastReportedDate = newDate;
          currentEntity.actualValue = newValue;
          currentEntity.dailyAverage = dailyAverage;
          currentEntity.updatedByRank = UserRanks.FOURTH_ENGINEER; // Assuming "4E" is the correct enum
          currentEntity.dueDateForCounterReading = nextDueDate; // Updated due date

          await queryRunner.manager.save(currentEntity);
          updatedEntities.push(currentEntity);
        }
      }
      await queryRunner.commitTransaction();
      return updatedEntities;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw new Error(`Failed to update running hours: ${error.message}`);
    } finally {
      await queryRunner.release();
    }
  }

  async getShipById(shipId: number): Promise<Ship> {
    const ship = await this.shipRepo.findOne({
      where: { id: shipId, disabled: false },
      relations: ['client', 'voyages', 'userDetails', 'mainParts'], // Include any relations needed
    });
    if (!ship) {
      throw new NotFoundException('Ship not found');
    }
    this._ship = ship;
    this._shipCode = ship.code;
    return ship;
  }
}
