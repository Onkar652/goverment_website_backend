import { Module } from '@nestjs/common';
import { RunningHoursService } from './running-hours.service';
import { RunningHoursController } from './running-hours.controller';

@Module({
  controllers: [RunningHoursController],
  providers: [RunningHoursService],
})
export class RunningHoursModule {}
