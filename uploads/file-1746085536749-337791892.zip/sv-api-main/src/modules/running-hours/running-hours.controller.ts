import {
  BadRequestException,
  Body,
  Controller,
  HttpException,
  HttpStatus,
  Post,
} from '@nestjs/common';
import { ApiBody, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { CreateWorkOrderConfigBodyDto } from '../work-orders/dto/create-wo-config.dto';
import { RunningHoursService } from './running-hours.service';
import { RunningHoursEntity } from 'src/entities/shipActions/running-hours.entity';
import { GetRunningHoursDto } from './dto/get-running-hour.dto';
import { UpdateRunningHoursBatchDto } from './dto/update-running-hour.dto';

@ApiTags('running-hours')
@Controller('running-hours')
export class RunningHoursController {
  constructor(private readonly runningHoursService: RunningHoursService) {}

  @Post('init-rh')
  @ApiOperation({ summary: 'Insert work order configurations from CSV data' })
  @ApiResponse({
    status: 201,
    description: 'Work Order Configurations inserted successfully',
  })
  @ApiResponse({ status: 400, description: 'Invalid request data' })
  async insertWorkOrderConfig(@Body() body: CreateWorkOrderConfigBodyDto) {
    const { shipId } = body;

    if (!shipId) {
      throw new BadRequestException('shipId is required');
    }

    return await this.runningHoursService.initRunningHours(shipId);
  }

  @Post()
  @ApiOperation({
    summary: 'Retrieve Running Hours by Ship and optionally by Main Part',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved running hours',
    type: [RunningHoursEntity],
  })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  @ApiResponse({ status: 500, description: 'Internal Server Error' })
  @ApiBody({ type: GetRunningHoursDto })
  async getRunningHours(
    @Body() findRunningHoursDto: GetRunningHoursDto,
  ): Promise<RunningHoursEntity[]> {
    try {
      return await this.runningHoursService.findRunningHoursByShipAndMainPart(
        findRunningHoursDto.shipId,
        findRunningHoursDto.mainPartId,
      );
    } catch (error) {
      throw new HttpException(
        'Failed to retrieve running hours',
        HttpStatus.INTERNAL_SERVER_ERROR,
        {
          cause: error,
        },
      );
    }
  }

  @Post('/update-counters')
  @ApiOperation({ summary: 'Update multiple Running Hours records' })
  @ApiResponse({
    status: 200,
    description: 'Successfully updated running hours',
  })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  @ApiBody({ type: UpdateRunningHoursBatchDto })
  async updateRunningHoursBatch(
    @Body() rhUpdate: UpdateRunningHoursBatchDto,
  ): Promise<RunningHoursEntity[]> {
    const { shipId, updates } = rhUpdate;
    return await this.runningHoursService.updateRunningHours(shipId, updates);
  }
}
