import { Test, TestingModule } from '@nestjs/testing';
import { RunningHoursController } from './running-hours.controller';
import { RunningHoursService } from './running-hours.service';

describe('RunningHoursController', () => {
  let controller: RunningHoursController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [RunningHoursController],
      providers: [RunningHoursService],
    }).compile();

    controller = module.get<RunningHoursController>(RunningHoursController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
