import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsDate, IsOptional } from 'class-validator';

export class UpdateRunningHourDto {
  @ApiProperty({
    description: 'ID of the Running Hours record to update',
    example: 1,
  })
  @IsNumber()
  id: number;

  @ApiProperty({ description: 'New current reading value', example: 1200 })
  @IsNumber()
  currentReading: number;

  @ApiProperty({
    description: 'Date when the current reading was taken',
    example: '2024-09-15',
    required: false,
  })
  @IsDate()
  @IsOptional()
  currentReadingDate?: Date;
}

export class UpdateRunningHoursBatchDto {
  @ApiProperty({ type: [UpdateRunningHourDto] })
  updates: UpdateRunningHourDto[];

  @ApiProperty({ description: 'Unique identifier of the ship', example: 1 })
  @IsNumber()
  shipId: number;
}
