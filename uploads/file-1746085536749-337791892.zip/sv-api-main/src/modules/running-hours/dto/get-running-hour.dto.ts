import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsOptional } from 'class-validator';

export class GetRunningHoursDto {
  @ApiProperty({ description: 'Unique identifier of the ship', example: 1 })
  @IsNumber()
  shipId: number;

  @ApiProperty({
    description: 'Unique identifier of the main part (optional)',
    example: 2,
    required: false,
  })
  @IsNumber()
  @IsOptional()
  mainPartId?: number;
}
