import { Test, TestingModule } from '@nestjs/testing';
import { RunningHoursService } from './running-hours.service';

describe('RunningHoursService', () => {
  let service: RunningHoursService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [RunningHoursService],
    }).compile();

    service = module.get<RunningHoursService>(RunningHoursService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
