import { Injectable, NotFoundException } from '@nestjs/common';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { DataSource, Repository } from 'typeorm';

@Injectable()
export class FileStorageService {
  private fileStorageRepository: Repository<FileStorageEntity>;
  constructor(private readonly dataSource: DataSource) {
    this.fileStorageRepository =
      this.dataSource.getRepository(FileStorageEntity);
  }

  async getFileById(fileId: string): Promise<FileStorageEntity> {
    const file = await this.fileStorageRepository.findOne({
      where: { id: fileId },
    });

    if (!file) {
      throw new NotFoundException(`File with ID ${fileId} not found`);
    }

    return file;
  }

  async deleteFile(fileId: string): Promise<void> {
    const file = await this.getFileById(fileId);
    await this.fileStorageRepository.remove(file);
  }
}
