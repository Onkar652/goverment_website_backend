import {
  BadRequestException,
  Controller,
  Delete,
  ForbiddenException,
  Get,
  InternalServerErrorException,
  NotFoundException,
  Param,
  Res,
} from '@nestjs/common';
import { FileStorageService } from './file-storage.service';
import { Response } from 'express';
import { ApiOperation, ApiParam, ApiResponse, ApiTags } from '@nestjs/swagger';

@ApiTags('file-storage')
@Controller('file-storage')
export class FileStorageController {
  constructor(private readonly fileStorageService: FileStorageService) {}

  @Get(':fileId/download')
  @ApiOperation({ summary: 'Download a file by ID' })
  @ApiParam({
    name: 'fileId',
    description: 'The ID of the file to download',
    required: true,
    type: String,
  })
  @ApiResponse({
    status: 200,
    description: 'The file has been downloaded successfully',
    content: {
      'application/octet-stream': {
        schema: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @ApiResponse({
    status: 404,
    description: 'File not found',
  })
  async downloadFile(
    @Param('fileId') fileId: string,
    @Res() res: Response,
  ): Promise<void> {
    const file = await this.fileStorageService.getFileById(fileId);

    if (!file) {
      throw new NotFoundException(`File with ID ${fileId} not found`);
    }

    res.set({
      'Content-Type': file.mimeType,
      'Content-Disposition': `attachment; filename="${file.fileName}"`,
    });

    res.send(file.data);
  }

  @Delete(':fileId')
  @ApiOperation({ summary: 'Delete a file by ID' }) // Describes the endpoint
  @ApiParam({
    name: 'fileId',
    description: 'The ID of the file to delete',
    required: true,
    type: String,
  }) // Describes the parameter
  @ApiResponse({
    status: 200,
    description: 'The file has been deleted successfully',
  })
  @ApiResponse({ status: 404, description: 'File not found' })
  @ApiResponse({ status: 400, description: 'Invalid file ID' })
  @ApiResponse({ status: 403, description: 'Unauthorized to delete the file' })
  @ApiResponse({ status: 500, description: 'Internal server error' })
  async deleteFile(
    @Param('fileId') fileId: string,
  ): Promise<{ message: string }> {
    try {
      const file = await this.fileStorageService.getFileById(fileId);

      if (!file) {
        throw new NotFoundException(`File with ID ${fileId} not found`);
      }

      await this.fileStorageService.deleteFile(fileId);

      return { message: 'File deleted successfully' };
    } catch (error) {
      if (
        error instanceof NotFoundException ||
        error instanceof BadRequestException ||
        error instanceof ForbiddenException
      ) {
        throw error; // Rethrow known errors
      }
      console.error('Unexpected error:', error); // Log unexpected errors
      throw new InternalServerErrorException(
        'An unexpected error occurred while deleting the file',
      );
    }
  }
}
