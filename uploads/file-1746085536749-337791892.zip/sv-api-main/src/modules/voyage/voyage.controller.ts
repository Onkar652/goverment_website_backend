import {
  BadRequestException,
  Body,
  Controller,
  Get,
  HttpException,
  HttpStatus,
  Param,
  Post,
  Query,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import {
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiQuery,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { VoyageEntity } from 'src/entities/voyage/voyage.entity';
import { CreateVoyageDto } from './dto/create-voyage.dto';
import { VoyageFilterDto } from './dto/voyage-filter.dto';
import { VoyageService } from './voyage.service';
import { DeleteVoyageDto } from './dto/delete-voyage.dto';

@ApiTags('Voyage')
@Controller('voyage')
export class VoyageController {
  constructor(private readonly voyageService: VoyageService) {}

  @Post('/save-draft')
  @ApiOperation({ summary: 'Create or Update a Voyage' })
  @ApiResponse({ status: 201, description: 'Voyage created successfully.' })
  @ApiResponse({ status: 400, description: 'Validation error.' })
  @ApiResponse({ status: 404, description: 'Referenced data not found.' })
  async createOrUpdateVoyage(
    @Body() createVoyageDto: CreateVoyageDto,
  ): Promise<{ status: HttpStatus; message: string }> {
    return await this.voyageService.updateVoyage(createVoyageDto);
  }

  @Post('/set-active')
  @ApiOperation({ summary: 'Set a voyage as active' })
  @ApiResponse({
    status: 200,
    description: 'Voyage set to active successfully.',
  })
  @ApiResponse({ status: 400, description: 'Validation failed.' })
  @ApiResponse({ status: 404, description: 'Voyage not found.' })
  async setActive(
    @Body() voyageDto: CreateVoyageDto,
  ): Promise<{ status: HttpStatus; message: string }> {
    return this.voyageService.setActive(voyageDto);
  }

  @Post('/initiate')
  @ApiOperation({ summary: 'Initiate a voyage and generate a voyageId' })
  @ApiResponse({ status: 201, description: 'Voyage initiated successfully' })
  @ApiBody({
    description: 'Ship ID for which the voyage is being initiated',
    schema: {
      type: 'object',
      properties: {
        shipId: {
          type: 'integer',
          description: 'ID of the ship',
          example: 1,
        },
      },
    },
  })
  async initiateVoyage(
    @Body('shipId') shipId: number,
  ): Promise<CreateVoyageDto> {
    return await this.voyageService.initiateVoyage(shipId);
  }

  @Get()
  @ApiOperation({ summary: 'Get a list of voyages' })
  @ApiResponse({
    status: 200,
    description: 'List of voyages with pagination details',
    schema: {
      type: 'object',
      properties: {
        data: {
          type: 'array',
          items: { $ref: '#/components/schemas/VoyageEntity' },
        },
        total: {
          type: 'number',
          description: 'Total number of voyages matching the query',
        },
      },
    },
  })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship to filter voyages by',
    example: 1,
  })
  @ApiQuery({
    name: 'status',
    required: false,
    type: String,
    description: 'Filter voyages by their status (e.g., active, draft)',
    example: 'active',
  })
  @ApiQuery({
    name: 'voyageNumber',
    required: false,
    type: String,
    description: 'Filter voyages by voyage number',
    example: 'V123',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    type: Number,
    description: 'The page number for pagination',
    example: 1,
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    description: 'The number of voyages to return per page',
    example: 10,
  })
  async getVoyages(
    @Query('shipId') shipId: number,
    @Query('status') status?: string,
    @Query('voyageNumber') voyageNumber?: string,
    @Query('page') page = 1,
    @Query('limit') limit = 10,
  ): Promise<{ data: VoyageEntity[]; total: number }> {
    if (!shipId) {
      throw new BadRequestException('shipId is required');
    }
    return await this.voyageService.getVoyages({
      shipId,
      status,
      voyageNumber,
      page,
      limit,
    });
  }

  @Get(':voyageId')
  @ApiOperation({ summary: 'Get voyage details by ID' })
  @ApiResponse({
    status: 200,
    description: 'Voyage details',
    type: VoyageEntity,
  })
  @ApiResponse({ status: 404, description: 'Voyage not found' })
  async getVoyageById(
    @Param('voyageId') voyageId: string,
  ): Promise<VoyageEntity> {
    return await this.voyageService.getVoyageById(voyageId);
  }

  @Post('/search')
  @ApiOperation({ summary: 'Search and filter voyages' })
  @ApiResponse({
    status: 200,
    description: 'Filtered voyages',
    type: [VoyageEntity],
  })
  async searchVoyages(
    @Body() filterDto: VoyageFilterDto,
  ): Promise<{ data: VoyageEntity[]; total: number }> {
    return await this.voyageService.searchVoyages(filterDto);
  }

  @Post(':voyageId/attachments')
  @UseInterceptors(FilesInterceptor('files')) // Change to FilesInterceptor
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Upload multiple attachments for a voyage',
    schema: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  async uploadAttachments(
    @Param('voyageId') voyageId: string,
    @UploadedFiles() files: Express.Multer.File[], // Change to @UploadedFiles
  ): Promise<{ message: string }> {
    await this.voyageService.uploadAttachments(voyageId, files);
    return { message: 'Attachments uploaded successfully' };
  }

  @Post(':voyageId/complete')
  @ApiOperation({ summary: 'Complete a voyage' })
  @ApiResponse({ status: 200, description: 'Voyage completed successfully' })
  @ApiResponse({ status: 404, description: 'Voyage not found' })
  @ApiResponse({ status: 400, description: 'Voyage not in active state' })
  async completeVoyage(
    @Param('voyageId') voyageId: string,
  ): Promise<{ message: string }> {
    return await this.voyageService.completeVoyage(voyageId);
  }

  @Post('/delete')
  @ApiOperation({ summary: 'Delete voyages by voyage IDs if in draft status' })
  @ApiResponse({ status: 200, description: 'Voyages deleted successfully' })
  @ApiResponse({
    status: 400,
    description: 'Invalid request or voyages not in draft status',
  })
  async deleteVoyages(
    @Body() deleteVoyageDto: DeleteVoyageDto,
  ): Promise<{ message: string }> {
    const { shipId, voyageIds } = deleteVoyageDto;

    const result = await this.voyageService.deleteVoyages(shipId, voyageIds);

    if (result) {
      return { message: 'Voyages deleted successfully' };
    } else {
      throw new HttpException(
        'Some voyages could not be deleted as they are not in draft status',
        HttpStatus.BAD_REQUEST,
      );
    }
  }
}
