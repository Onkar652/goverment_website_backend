import {
  BadRequestException,
  HttpStatus,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { CharterEntity } from 'src/entities/voyage/charter.entity';
import { ItineraryPortEntity } from 'src/entities/voyage/itinerary-port.entity';
import { VoyageEntity } from 'src/entities/voyage/voyage.entity';
import { ZoneEntity } from 'src/entities/voyage/zones.entity';
import { DataSource, EntityManager, In, Repository } from 'typeorm';
import { CharterDto } from './dto/charter.dto';
import { CreateVoyageDto } from './dto/create-voyage.dto';
import { ItineraryPortDto } from './dto/itinerary.dto';
import { ZoneDto } from './dto/zone.dto';
import { ShipValidationService } from '../common/ship-validation.service';
import { VoyageFilterDto } from './dto/voyage-filter.dto';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { PortListEntity } from 'src/entities/master-configs/port-list.entity';

@Injectable()
export class VoyageService {
  voyageRepository: Repository<VoyageEntity>;
  portRepository: Repository<PortListEntity>;
  fileStorageRepository: Repository<FileStorageEntity>;
  constructor(
    private dataSource: DataSource,
    private shipValidationService: ShipValidationService,
  ) {
    this.voyageRepository = this.dataSource.getRepository(VoyageEntity);
    this.portRepository = this.dataSource.getRepository(PortListEntity);
    this.fileStorageRepository =
      this.dataSource.getRepository(FileStorageEntity);
  }

  async updateVoyage(
    createVoyageDto: CreateVoyageDto,
  ): Promise<{ status: HttpStatus; message: string }> {
    const { voyageId } = createVoyageDto;

    if (!voyageId) {
      throw new BadRequestException(
        'Voyage ID is required for updating a voyage.',
      );
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Fetch the existing voyage
      const voyage = await this.voyageRepository.findOne({
        where: { voyageId },
        relations: ['ports', 'charters', 'zones'],
      });

      if (!voyage) {
        throw new NotFoundException(`Voyage with ID ${voyageId} not found.`);
      }
      // Use shared logic for updating the voyage
      const updatedVoyage = await this.handleVoyageUpdate(
        voyage,
        createVoyageDto,
        queryRunner.manager,
      );

      updatedVoyage.status = 'draft';

      // Save the updated status
      await queryRunner.manager.save(VoyageEntity, updatedVoyage);

      await queryRunner.commitTransaction();
      return {
        status: HttpStatus.OK,
        message: 'Voyage Saved successfully',
      };
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw new InternalServerErrorException(
        `Failed to update voyage: ${error.message}`,
      );
    } finally {
      await queryRunner.release();
    }
  }

  private async updateItineraryPorts(
    voyage: VoyageEntity,
    ports: ItineraryPortDto[],
    manager: EntityManager,
  ) {
    // Remove existing ports
    await manager.delete(ItineraryPortEntity, { voyage: { id: voyage.id } });

    // Add new ports
    const updatedPorts: ItineraryPortEntity[] = [];
    for (const port of ports) {
      const portEntity = await this.portRepository.findOne({
        where: { id: port.portId },
      });
      if (!portEntity) {
        throw new NotFoundException(`Port with ID ${port.portId} not found.`);
      }

      const newPort = manager.create(ItineraryPortEntity, {
        voyage,
        port: portEntity,
        timezone: port.timezone,
        eta: port.eta,
        etb: port.etb,
        etd: port.etd,
        actualArrival: port.actualArrival,
        arrivalDate: port.arrivalDate,
        departureDate: port.departureDate,
        actualDeparture: port.actualDeparture,
        agentName: port.agentName,
        remarks: port.remarks,
      });

      const savedPort = await manager.save(newPort);
      updatedPorts.push(savedPort);
    }

    // Update the voyage instance with the new ports
    voyage.ports = updatedPorts;
  }

  private async updateCharters(
    voyage: VoyageEntity,
    charters: CharterDto[],
    manager: EntityManager,
  ) {
    // Remove existing charters
    await manager.delete(CharterEntity, { voyage: { id: voyage.id } });

    // Add new charters
    const updatedCharters: CharterEntity[] = [];
    for (const charter of charters) {
      const newCharter = manager.create(CharterEntity, {
        voyage,
        type: charter.type,
        name: charter.name,
        address1: charter.address1,
        address2: charter.address2,
        contactNumber: charter.contactNumber,
      });

      const savedCharter = await manager.save(newCharter);
      updatedCharters.push(savedCharter);
    }

    // Update the voyage instance with the new ports
    voyage.charters = updatedCharters;
  }

  private async updateZones(
    voyage: VoyageEntity,
    zones: ZoneDto[],
    manager: EntityManager,
  ) {
    // Remove existing zones
    await manager.delete(ZoneEntity, { voyage: { id: voyage.id } });

    // Add new zones
    const updatedZones: ZoneEntity[] = [];
    for (const zone of zones) {
      const newZone = manager.create(ZoneEntity, {
        voyage,
        zoneType: zone.zoneType,
        entryLatitude: zone.entryLatitude,
        entryLongitude: zone.entryLongitude,
        entryEta: zone.entryEta,
        exitLatitude: zone.exitLatitude,
        exitLongitude: zone.exitLongitude,
        exitEtd: zone.exitEtd,
      });

      const savedZone = await manager.save(newZone);
      updatedZones.push(savedZone);
    }

    // Update the voyage instance with the new zones
    voyage.zones = updatedZones;
  }

  async generateUniqueVoyageId(shipCode: string): Promise<string> {
    const prefix = `${shipCode}-VI-`; // Prefix with ship code and "VI-"
    let uniqueNumber;

    while (true) {
      // Generate a random number in the desired range (e.g., 100000 to 999999)
      uniqueNumber = Math.floor(100000 + Math.random() * 900000);

      // Combine prefix and unique number
      const candidateId = `${prefix}${uniqueNumber}`;

      // Check if the ID already exists in the database
      const existingVoyage = await this.voyageRepository.findOne({
        where: { voyageId: candidateId },
      });

      // If it doesn't exist, return it as the unique ID
      if (!existingVoyage) {
        return candidateId;
      }
    }
  }

  private async handleVoyageUpdate(
    voyage: VoyageEntity,
    voyageDto: CreateVoyageDto,
    manager: EntityManager,
  ): Promise<VoyageEntity> {
    const {
      voyageNumber,
      voyageStart,
      vesselStatus,
      timezone,
      charterPartySpeed,
      charterPartyConsumption,
      remarks,
      ports,
      charters,
      zones,
    } = voyageDto;

    // Update voyage fields directly
    const updatedVoyage = this.voyageRepository.merge(voyage, {
      voyageNumber,
      voyageStart,
      vesselStatus,
      timezone,
      charterPartySpeed,
      charterPartyConsumption,
      remarks,
    });

    // Save updated voyage details
    const savedVoyage = await manager.save(VoyageEntity, updatedVoyage);

    // Handle itinerary ports
    if (ports) {
      await this.updateItineraryPorts(savedVoyage, ports, manager);
    }

    // Handle charters
    if (charters) {
      await this.updateCharters(savedVoyage, charters, manager);
    }

    // Handle zones
    if (zones) {
      await this.updateZones(savedVoyage, zones, manager);
    }

    return savedVoyage;
  }

  private validateActivation(voyageDto: CreateVoyageDto): void {
    const { voyageNumber, voyageStart, vesselStatus, timezone, ports } =
      voyageDto;

    if (!voyageNumber) {
      throw new BadRequestException('Voyage number is required.');
    }
    if (!voyageStart) {
      throw new BadRequestException('Voyage start date is required.');
    }
    if (!vesselStatus) {
      throw new BadRequestException('Vessel status is required.');
    }
    if (!timezone) {
      throw new BadRequestException('Timezone is required.');
    }

    this.validateItineraryPorts(ports);
  }
  private validateItineraryPorts(ports: ItineraryPortDto[]): void {
    if (!ports || ports.length === 0 || ports.length === 1) {
      throw new BadRequestException('At least two itinerary port is required.');
    }

    ports.forEach((port, index) => {
      const isFirstPort = index === 0;
      const isLastPort = index === ports.length - 1;

      if (isFirstPort) {
        if (!port.etd) {
          throw new BadRequestException(`ETD is required for the first port.`);
        }
      }

      if (!isFirstPort && !isLastPort) {
        if (!port.eta) {
          throw new BadRequestException(
            `ETA is required for intermediate port.`,
          );
        }
        if (!port.etd) {
          throw new BadRequestException(
            `ETD is required for intermediate port (Port ID: ${port.portId}).`,
          );
        }
      }

      if (isLastPort) {
        if (!port.eta) {
          throw new BadRequestException(
            `ETA is required for the last port (Port ID: ${port.portId}).`,
          );
        }
      }

      if (port.actualArrival && port.actualDeparture) {
        if (new Date(port.actualDeparture) < new Date(port.actualArrival)) {
          throw new BadRequestException(
            `Actual departure cannot be earlier than actual arrival for Port ID: ${port.portId}.`,
          );
        }
      }
    });
  }

  async setActive(
    voyageDto: CreateVoyageDto,
  ): Promise<{ status: HttpStatus; message: string }> {
    const ship = await this.shipValidationService.getShipById(voyageDto.shipId);

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Check if any voyage is already active
      const activeVoyage = await this.voyageRepository.findOne({
        where: {
          ship: { id: ship.id },
          status: 'active',
        },
      });

      if (activeVoyage) {
        throw new BadRequestException(
          `Voyage ${activeVoyage.voyageId} is already active for this ship. Please complete or deactivate it before activating a new voyage.`,
        );
      }

      // Validate activation inputs
      this.validateActivation(voyageDto);

      // Fetch the voyage to be updated
      const voyage = await this.voyageRepository.findOne({
        where: { voyageId: voyageDto.voyageId },
        relations: ['ports', 'charters', 'zones'],
      });

      if (!voyage) {
        throw new NotFoundException(
          `Voyage with ID ${voyageDto.voyageId} not found.`,
        );
      }

      // Use shared logic for updating the voyage
      const updatedVoyage = await this.handleVoyageUpdate(
        voyage,
        voyageDto,
        queryRunner.manager,
      );

      // Set the status to active
      updatedVoyage.status = 'active';

      // Save the updated status
      await queryRunner.manager.save(VoyageEntity, updatedVoyage);

      await queryRunner.commitTransaction();

      return {
        message: 'Voyage set to active successfully',
        status: HttpStatus.OK,
      };
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw new InternalServerErrorException(
        `Failed to set voyage active: ${error.message}`,
      );
    } finally {
      await queryRunner.release();
    }
  }

  async initiateVoyage(shipId: number): Promise<CreateVoyageDto> {
    const ship = await this.shipValidationService.getShipById(shipId);

    // Generate a unique voyage ID
    const voyageId = await this.generateUniqueVoyageId(ship.code);

    // Create a draft voyage with default values
    const draftVoyage = this.voyageRepository.create({
      voyageId,
      ship,
      status: 'draft',
      voyageNumber: '', // Part of generalInfo
      voyageStart: null, // Part of generalInfo
      vesselStatus: null, // Part of generalInfo
      timezone: null, // Part of generalInfo
      charterPartySpeed: null, // Part of generalInfo
      charterPartyConsumption: null, // Part of generalInfo
      remarks: null, // Part of generalInfo
    });

    // Save the draft voyage in the database
    const savedVoyage = await this.voyageRepository.save(draftVoyage);

    // Map the saved voyage to the expected DTO structure
    return {
      voyageId: savedVoyage.voyageId,
      shipId: savedVoyage.ship.id,
      voyageNumber: savedVoyage.voyageNumber,
      voyageStart: savedVoyage.voyageStart,
      vesselStatus: savedVoyage.vesselStatus,
      timezone: savedVoyage.timezone,
      charterPartySpeed: savedVoyage.charterPartySpeed,
      charterPartyConsumption: savedVoyage.charterPartyConsumption,
      remarks: savedVoyage.remarks,
      status: savedVoyage.status,
      ports: [],
      charters: [],
      zones: [],
    };
  }

  async getVoyages(query: {
    shipId: number;
    status?: string;
    voyageNumber?: string;
    page: number;
    limit: number;
  }): Promise<{ data: VoyageEntity[]; total: number }> {
    const { shipId, status, voyageNumber, page = 1, limit = 10 } = query;

    const ship = await this.shipValidationService.getShipById(shipId);

    const queryBuilder = this.voyageRepository
      .createQueryBuilder('voyage')
      .where('voyage.shipId = :shipId', { shipId: ship.id })
      .andWhere('voyage.disabled = false');

    if (status) {
      queryBuilder.andWhere('voyage.status = :status', { status });
    }
    if (voyageNumber) {
      queryBuilder.andWhere('voyage.voyageNumber ILIKE :voyageNumber', {
        voyageNumber: `%${voyageNumber}%`,
      });
    }

    const [data, total] = await queryBuilder
      .orderBy('voyage.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return { data, total };
  }
  async getVoyageById(voyageId: string): Promise<VoyageEntity> {
    const voyage = await this.voyageRepository
      .createQueryBuilder('voyage')
      .leftJoinAndSelect('voyage.ship', 'ship')
      .leftJoinAndSelect('voyage.ports', 'ports')
      .leftJoinAndSelect('ports.port', 'port')
      .leftJoinAndSelect('voyage.charters', 'charters')
      .leftJoinAndSelect('voyage.zones', 'zones')
      .leftJoin('voyage.attachments', 'attachments')
      .addSelect([
        'attachments.id',
        'attachments.fileName',
        'attachments.mimeType',
        'attachments.createdOn',
      ])
      .where('voyage.voyageId = :voyageId', { voyageId })
      .getOne();

    if (!voyage) {
      throw new NotFoundException(`Voyage with ID ${voyageId} not found.`);
    }

    return voyage;
  }

  async searchVoyages(
    filterDto: VoyageFilterDto,
  ): Promise<{ data: VoyageEntity[]; total: number }> {
    const {
      shipId,
      status,
      voyageNumber,
      startDate,
      endDate,
      page = 1,
      limit = 10,
      voyageId,
    } = filterDto;

    const ship = await this.shipValidationService.getShipById(shipId);

    const queryBuilder = this.voyageRepository
      .createQueryBuilder('voyage')
      .leftJoinAndSelect('voyage.ship', 'ship')
      .where('voyage.shipId = :shipId', { shipId: ship.id })
      .andWhere('voyage.disabled = false');

    if (status) {
      queryBuilder.andWhere('voyage.status = :status', { status });
    }
    if (voyageNumber) {
      queryBuilder.andWhere('voyage.voyageNumber ILIKE :voyageNumber', {
        voyageNumber: `%${voyageNumber}%`,
      });
    }

    if (voyageId) {
      queryBuilder.andWhere('voyage.voyageId ILIKE :voyageId', {
        voyageId: `%${voyageId}%`,
      });
    }
    if (startDate) {
      queryBuilder.andWhere('voyage.voyageStart >= :startDate', { startDate });
    }
    if (endDate) {
      queryBuilder.andWhere('voyage.voyageStart <= :endDate', { endDate });
    }

    const [data, total] = await queryBuilder
      .orderBy('voyage.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return { data, total };
  }

  async uploadAttachments(
    voyageId: string,
    files: Express.Multer.File[],
  ): Promise<void> {
    const voyage = await this.voyageRepository.findOne({ where: { voyageId } });

    if (!voyage) {
      throw new NotFoundException(`Voyage with ID ${voyageId} not found.`);
    }

    const attachments = files.map((file) =>
      this.fileStorageRepository.create({
        data: file.buffer,
        mimeType: file.mimetype,
        fileName: file.originalname,
        voyage,
      }),
    );

    await this.fileStorageRepository.save(attachments);
  }

  async completeVoyage(voyageId: string): Promise<{ message: string }> {
    const voyage = await this.voyageRepository.findOne({
      where: { voyageId, disabled: false },
      relations: ['ship', 'ports'],
    });

    if (!voyage) {
      throw new NotFoundException(`Voyage with ID ${voyageId} not found.`);
    }

    if (voyage.status !== 'active') {
      throw new BadRequestException(
        `Voyage must be in active state to complete. Current status: ${voyage.status}`,
      );
    }

    // Ensure no active voyages remain for this ship after completion
    const activeVoyages = await this.voyageRepository.find({
      where: { ship: { id: voyage.ship.id }, status: 'active' },
    });

    if (activeVoyages.length > 1) {
      throw new BadRequestException(
        `Another voyage is active for this ship. Complete or deactivate it before closing this voyage.`,
      );
    }
    this.validateItineraryPortsonCompletion(voyage.ports);
    // Update the voyage status to 'completed'
    voyage.status = 'closed';
    voyage.completionDate = new Date();

    await this.voyageRepository.save(voyage);

    return {
      message: `Voyage ${voyage.voyageId} has been completed successfully.`,
    };
  }

  private validateItineraryPortsonCompletion(
    ports: ItineraryPortEntity[],
  ): void {
    if (!ports || ports.length === 0) {
      throw new BadRequestException('Voyage itinerary is empty.');
    }

    // Sort ports based on the sequence they appear (assuming they are ordered)
    const sortedPorts = ports.sort(
      (a, b) => a.createdAt.getTime() - b.createdAt.getTime(),
    );

    const firstPort = sortedPorts[0];
    const lastPort = sortedPorts[sortedPorts.length - 1];

    // Step 1: Validate the first port (must have departure dates filled)
    if (!firstPort.departureDate || !firstPort.actualDeparture) {
      throw new BadRequestException(
        `The first port must have both departureDate and actualDeparture filled.`,
      );
    }

    // Step 2: Validate the last port (must have arrival dates filled)
    if (!lastPort.arrivalDate || !lastPort.actualArrival) {
      throw new BadRequestException(
        `The last port must have both arrivalDate and actualArrival filled.`,
      );
    }

    // Step 3: Validate intermediate ports (must have all arrival and departure fields filled)
    const intermediatePorts = sortedPorts.slice(1, sortedPorts.length - 1);

    for (const port of intermediatePorts) {
      if (
        !port.arrivalDate ||
        !port.actualArrival ||
        !port.departureDate ||
        !port.actualDeparture
      ) {
        throw new BadRequestException(
          `Intermediate port (${port?.port?.code}) must have all arrival and departure fields filled.`,
        );
      }
    }
  }

  async deleteVoyages(shipId: number, voyageIds: string[]): Promise<boolean> {
    // Validate ship existence
    const ship = await this.shipValidationService.getShipById(shipId);

    // Find voyages
    const voyages = await this.voyageRepository.findBy({
      voyageId: In(voyageIds),
      ship: { id: ship.id },
    });

    if (!voyages.length) {
      throw new NotFoundException(
        `No voyages found for the given IDs and ship`,
      );
    }

    // Check if all voyages are in draft status
    const nonDraftVoyages = voyages.filter(
      (voyage) => voyage.status !== 'draft',
    );
    if (nonDraftVoyages.length > 0) {
      throw new BadRequestException(
        `Some voyages cannot be deleted as they are not in draft status`,
      );
    }

    // Delete voyages
    await this.voyageRepository.update(
      { voyageId: In(voyageIds) },
      { disabled: true },
    );

    return true;
  }
}
