import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNumber, IsString, IsDateString, IsOptional } from 'class-validator';

export class ItineraryPortDto {
  @ApiProperty({
    description: 'ID of the port',
    example: 123,
  })
  @IsNumber()
  portId: number;

  @ApiProperty({
    description: 'Timezone of the port',
    example: 'Asia/Kolkata',
  })
  @IsString()
  timezone: string;

  @ApiPropertyOptional({
    description: 'Estimated Time of Arrival (ETA)',
    example: '2024-12-25T10:30:00Z',
  })
  @IsOptional()
  @IsDateString()
  eta?: Date;

  @ApiPropertyOptional({
    description: 'Estimated Time of Berthing (ETB)',
    example: '2024-12-25T12:00:00Z',
  })
  @IsOptional()
  @IsDateString()
  etb?: Date;

  @ApiPropertyOptional({
    description: 'Estimated Time of Departure (ETD)',
    example: '2024-12-26T18:00:00Z',
  })
  @IsOptional()
  @IsDateString()
  etd?: Date;

  @ApiPropertyOptional({
    description: 'Actual time of arrival (EOSP)',
    example: '2024-12-25T11:30:00Z',
  })
  @IsOptional()
  @IsDateString()
  actualArrival?: Date;

  @ApiPropertyOptional({
    description: 'Arrival date at berth (AB)',
    example: '2024-12-25T12:15:00Z',
  })
  @IsOptional()
  @IsDateString()
  arrivalDate?: Date;

  @ApiPropertyOptional({
    description: 'Departure date from berth (DB)',
    example: '2024-12-26T17:50:00Z',
  })
  @IsOptional()
  @IsDateString()
  departureDate?: Date;

  @ApiPropertyOptional({
    description: 'Actual time of departure (COSP)',
    example: '2024-12-26T18:30:00Z',
  })
  @IsOptional()
  @IsDateString()
  actualDeparture?: Date;

  @ApiPropertyOptional({
    description: 'Name of the agent at the port',
    example: 'John Doe',
  })
  @IsOptional()
  @IsString()
  agentName?: string;

  @ApiPropertyOptional({
    description: 'Remarks for the port visit',
    example: 'Weather delay encountered.',
  })
  @IsOptional()
  @IsString()
  remarks?: string;
}
