import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsString, IsOptional } from 'class-validator';

export class CharterDto {
  @ApiProperty({
    description: 'Type of the charter (e.g., time, voyage)',
    example: 'Time',
  })
  @IsString()
  type: string;

  @ApiProperty({
    description: 'Name of the charter',
    example: 'ABC Shipping Co.',
  })
  @IsString()
  name: string;

  @ApiProperty({
    description: 'Primary address of the charter',
    example: '123 Shipping Lane, Port City',
  })
  @IsString()
  address1: string;

  @ApiPropertyOptional({
    description: 'Secondary address of the charter',
    example: 'Building B, Floor 3',
  })
  @IsOptional()
  @IsString()
  address2?: string;

  @ApiProperty({
    description: 'Contact number for the charter',
    example: '+123456789',
  })
  @IsString()
  contactNumber: string;
}
