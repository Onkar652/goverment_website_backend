import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNumber, IsDateString } from 'class-validator'; // Adjust the import path for ZoneType
import { ZoneType } from 'src/entities/voyage/zones.entity';

export class ZoneDto {
  @ApiProperty({
    description: 'Type of the zone (e.g., ECA, EU waters, etc.)',
    enum: ZoneType,
    example: ZoneType.ECA,
  })
  @IsEnum(ZoneType)
  zoneType: ZoneType;

  @ApiProperty({
    description: 'Latitude of the entry point into the zone',
    example: 37.7749,
  })
  @IsNumber()
  entryLatitude: number;

  @ApiProperty({
    description: 'Longitude of the entry point into the zone',
    example: -122.4194,
  })
  @IsNumber()
  entryLongitude: number;

  @ApiProperty({
    description: 'Estimated time of entry into the zone',
    example: '2024-12-25T10:30:00Z',
  })
  @IsDateString()
  entryEta: Date;

  @ApiProperty({
    description: 'Latitude of the exit point from the zone',
    example: 40.7128,
  })
  @IsNumber()
  exitLatitude: number;

  @ApiProperty({
    description: 'Longitude of the exit point from the zone',
    example: -74.006,
  })
  @IsNumber()
  exitLongitude: number;

  @ApiProperty({
    description: 'Estimated time of departure from the zone',
    example: '2024-12-26T18:30:00Z',
  })
  @IsDateString()
  exitEtd: Date;
}
