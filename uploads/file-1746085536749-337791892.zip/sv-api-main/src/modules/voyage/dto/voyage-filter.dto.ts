import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsNumber, IsString, IsDateString } from 'class-validator';

export class VoyageFilterDto {
  @IsNumber()
  @ApiProperty({
    example: 1,
    description: 'ID of the ship associated with the voyage',
  })
  shipId: number;

  @IsOptional()
  @IsString()
  @ApiPropertyOptional({
    example: 'active',
    description: 'Status of the voyage (e.g., draft, active)',
  })
  status?: string;

  @IsOptional()
  @IsString()
  @ApiPropertyOptional({
    example: 'VI-12345',
    description: 'Unique identifier of the voyage',
  })
  voyageId?: string;

  @IsOptional()
  @IsString()
  @ApiPropertyOptional({
    example: 'V001',
    description: 'User-defined voyage number',
  })
  voyageNumber?: string;

  @IsOptional()
  @IsDateString()
  @ApiPropertyOptional({
    example: '2024-01-01',
    description: 'Start date for filtering voyages (inclusive)',
  })
  startDate?: string;

  @IsOptional()
  @IsDateString()
  @ApiPropertyOptional({
    example: '2024-12-31',
    description: 'End date for filtering voyages (inclusive)',
  })
  endDate?: string;

  @IsOptional()
  @IsNumber()
  @ApiPropertyOptional({
    example: 1,
    description: 'Page number for pagination (default: 1)',
  })
  page: number;

  @IsOptional()
  @IsNumber()
  @ApiPropertyOptional({
    example: 10,
    description: 'Number of voyages per page for pagination (default: 10)',
  })
  limit: number;
}
