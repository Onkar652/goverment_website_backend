import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsNotEmpty,
  IsNumber,
  ArrayNotEmpty,
  IsString,
} from 'class-validator';

export class DeleteVoyageDto {
  @ApiProperty({
    description: 'ID of the ship to which the voyages belong',
    example: 1,
  })
  @IsNumber()
  @IsNotEmpty()
  shipId: number;

  @ApiProperty({
    description: 'Array of voyage IDs to delete',
    example: ['VOY123', 'VOY456'],
  })
  @IsArray()
  @ArrayNotEmpty()
  @IsString({ each: true })
  voyageIds: string[];
}
