import { Type } from 'class-transformer';
import {
  IsOptional,
  IsNumber,
  ValidateNested,
  IsDateString,
  IsString,
} from 'class-validator';
import { ItineraryPortDto } from './itinerary.dto';
import { CharterDto } from './charter.dto';
import { ZoneDto } from './zone.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateVoyageDto {
  @ApiProperty({
    description: 'Unique identifier for the voyage (auto-generated)',
    example: 'VI-1234',
  })
  @IsString()
  voyageId: string;

  @ApiProperty({
    description: 'ID of the ship associated with the voyage',
    example: 1,
  })
  @IsNumber()
  shipId: number;

  @ApiProperty({
    description: 'Voyage number provided by the user',
    example: 'V1234',
  })
  @IsString()
  voyageNumber: string;

  @ApiProperty({
    description: 'Start date and time of the voyage',
    example: '2024-12-25T10:30:00Z',
  })
  @IsDateString()
  voyageStart: Date;

  @ApiProperty({
    description: 'Status of the vessel (e.g., Ballast, Loaded)',
    example: 'Ballast',
  })
  @IsString()
  vesselStatus: string;

  @ApiProperty({
    description: 'Timezone associated with the voyage',
    example: 'Asia/Kolkata',
  })
  @IsString()
  timezone: string;

  @ApiPropertyOptional({
    description: 'Charter Party speed specified by the user',
    example: 12.5,
  })
  @IsOptional()
  @IsNumber()
  charterPartySpeed?: number;

  @ApiPropertyOptional({
    description: 'Charter Party fuel consumption specified by the user',
    example: 200,
  })
  @IsOptional()
  @IsNumber()
  charterPartyConsumption?: number;

  @ApiPropertyOptional({
    description: 'Additional remarks for the voyage',
    example: 'Initial voyage remarks.',
  })
  @IsOptional()
  @IsString()
  remarks?: string;

  @ApiPropertyOptional({
    description: 'Status for the voyage',
    example: 'draft',
  })
  @IsOptional()
  @IsString()
  status?: string;

  @ApiPropertyOptional({
    description: 'List of itinerary ports associated with the voyage',
    type: [ItineraryPortDto],
  })
  @ValidateNested({ each: true })
  @Type(() => ItineraryPortDto)
  ports?: ItineraryPortDto[];

  @ApiPropertyOptional({
    description: 'List of charter details associated with the voyage',
    type: [CharterDto],
  })
  @ValidateNested({ each: true })
  @Type(() => CharterDto)
  charters?: CharterDto[];

  @ApiPropertyOptional({
    description: 'List of zones associated with the voyage',
    type: [ZoneDto],
  })
  @ValidateNested({ each: true })
  @Type(() => ZoneDto)
  zones?: ZoneDto[];
}
