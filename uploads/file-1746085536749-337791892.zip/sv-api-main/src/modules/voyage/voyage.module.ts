import { Module } from '@nestjs/common';
import { VoyageService } from './voyage.service';
import { VoyageController } from './voyage.controller';
import { ShipValidationService } from '../common/ship-validation.service';

@Module({
  controllers: [VoyageController],
  providers: [VoyageService, ShipValidationService],
})
export class VoyageModule {}
