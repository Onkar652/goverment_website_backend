import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { SpareEntity } from 'src/entities/inventory/spares.entity';
import { RequisitionItemEntity } from 'src/entities/requisitions/requisition-item.entity';
import { RequisitionEntity } from 'src/entities/requisitions/requisition.entity';
import { MainPart } from 'src/entities/shipParts/main-parts.entity';
import {
  InventoryType,
  RequisitionStatus,
} from 'src/utils/models/common.types';
import { DataSource, Repository } from 'typeorm';
import { ShipValidationService } from '../common/ship-validation.service';
import { CreateRequisitionDto } from './dto/create-requisition.dto';
import { RequisitionItemResponseDto } from './dto/requisition-response.dto';
import { UpdateRequisitionDto } from './dto/update-requisition.dto';
import { UpdateRequisitionItemDto } from './dto/update-requisition-item.dto';
import {
  SpareTransaction,
  TransactionReason,
} from 'src/entities/inventory/spare-transaction.entity';

@Injectable()
export class RequisitionService {
  private requisitionRepository: Repository<RequisitionEntity>;
  private requisitionItemRepository: Repository<RequisitionItemEntity>;
  private spareRepository: Repository<SpareEntity>;
  private fileStorageRepository: Repository<FileStorageEntity>;
  private mainPartRepository: Repository<MainPart>;
  constructor(
    private readonly dataSource: DataSource,
    private shipValidationService: ShipValidationService,
  ) {
    this.mainPartRepository = this.dataSource.getRepository(MainPart);
    this.requisitionRepository =
      this.dataSource.getRepository(RequisitionEntity);
    this.requisitionItemRepository = this.dataSource.getRepository(
      RequisitionItemEntity,
    );
    this.spareRepository = this.dataSource.getRepository(SpareEntity);
    this.fileStorageRepository =
      this.dataSource.getRepository(FileStorageEntity);
  }
  async createRequisition(
    createRequisitionDto: CreateRequisitionDto,
  ): Promise<RequisitionEntity> {
    const { shipId, type, modelName, mainPartId, makerName } =
      createRequisitionDto;
    const ship = await this.shipValidationService.getShipById(shipId);
    if (!ship) {
      throw new NotFoundException(
        `Ship with ID ${createRequisitionDto.shipId} not found`,
      );
    }

    let mainPart = null;

    // Validate Main Part if type is "spare"
    if (type === InventoryType.SPARE) {
      if (!mainPartId) {
        throw new BadRequestException(
          'MainPartId is required for spare requisitions',
        );
      }

      mainPart = await this.mainPartRepository.findOne({
        where: { id: mainPartId },
      });

      if (!mainPart) {
        throw new NotFoundException(
          `Main Part with ID ${mainPartId} not found`,
        );
      }
    }

    // 2. Create Requisition Entity
    const requisition = this.requisitionRepository.create({
      prNumber: `PR-${Date.now()}`,
      description: createRequisitionDto.description,
      portOfSupply: createRequisitionDto.portOfSupply,
      priority: createRequisitionDto.priority,
      type: createRequisitionDto.type,
      status: RequisitionStatus.DRAFT,
      ship,
      mainPart,
      modelName,
      makerName,
      commentToBuyer: createRequisitionDto.commentToBuyer,
      commentToVendor: createRequisitionDto.commentToVendor,
      requiredDate: createRequisitionDto.requiredDate,
    });

    const savedRequisition = await this.requisitionRepository.save(requisition);
    const savedItems = [];
    // 3. Create Requisition Items
    for (const itemDto of createRequisitionDto.items) {
      let inventoryItem: SpareEntity | undefined;

      // Check if inventory item exists
      if (itemDto.id) {
        inventoryItem = await this.spareRepository.findOne({
          where: { id: itemDto.id },
        });

        if (!inventoryItem) {
          throw new NotFoundException(
            `Spare item with ID ${itemDto.inventoryItemId} not found`,
          );
        }
      } else {
        // Create new SpareEntity if it doesn't exist
        inventoryItem = this.spareRepository.create({
          description: itemDto.description,
          partNumber: itemDto.partNumber,
          unitOfMeasure: itemDto.uom,
          rob: 0,
          type:
            createRequisitionDto.type === InventoryType.SPARE
              ? 'spare'
              : 'store',
          ship,
          mainPart:
            createRequisitionDto.type === InventoryType.SPARE ? mainPart : null,
        });
        inventoryItem = await this.spareRepository.save(inventoryItem);
      }

      // Link inventory item to requisition item
      const requisitionItem = this.requisitionItemRepository.create({
        requisition: savedRequisition,
        inventoryItem,
        description: itemDto.description,
        itemNumber: itemDto.itemNumber,
        partNumber: itemDto.partNumber,
        drawingNumber: itemDto.drawingNumber,
        requestedQuantity: itemDto.requestedQuantity,
        rob: itemDto.rob,
        quantityInUse: itemDto.quantityInUse,
        uom: itemDto.uom,
        remarks: itemDto.remarks,
        commentToBuyer: itemDto.commentToBuyer,
        commentToVendor: itemDto.commentToVendor,
      });

      const savedItem =
        await this.requisitionItemRepository.save(requisitionItem);
      delete savedItem.inventoryItem;
      delete savedItem.requisition;
      savedItems.push(savedItem);

      const spareTransactionRepo =
        this.dataSource.getRepository(SpareTransaction);

      const spareTransaction = spareTransactionRepo.create({
        spare: inventoryItem,
        reason: TransactionReason.PURCHASE,
        quantity: 0,
        remark: `Purchase request created: ${savedRequisition.prNumber}`,
        updatedBy: 'CE', // Or relevant user info
      });
      await spareTransactionRepo.save(spareTransaction);
    }
    savedRequisition.items = savedItems;
    return savedRequisition;
  }

  async uploadFileForRequisitionItem(
    itemId: number,
    file: Express.Multer.File,
  ): Promise<FileStorageEntity> {
    // Find the requisition item
    const requisitionItem = await this.requisitionItemRepository.findOne({
      where: { id: itemId },
    });

    if (!requisitionItem) {
      throw new NotFoundException(
        `Requisition item with ID ${itemId} not found`,
      );
    }

    // Create and save the file entity
    const fileEntity = this.fileStorageRepository.create({
      fileName: file.originalname,
      mimeType: file.mimetype,
      data: file.buffer,
    });

    const savedFile = await this.fileStorageRepository.save(fileEntity);

    // Link the file to the requisition item
    requisitionItem.file = savedFile;
    await this.requisitionItemRepository.save(requisitionItem);

    return savedFile;
  }

  async getRequisitions(
    status?: RequisitionStatus,
    search?: string,
    page: number = 1,
    limit: number = 10,
  ): Promise<{
    data: RequisitionEntity[];
    total: number;
    page: number;
    limit: number;
  }> {
    const query = this.requisitionRepository
      .createQueryBuilder('requisition')
      .select([
        'requisition.id',
        'requisition.prNumber',
        'requisition.description',
        'requisition.portOfSupply',
        'requisition.priority',
        'requisition.type',
        'requisition.status',
        'requisition.createdOn',
        'requisition.updatedOn',
        'requisition.modelName',
        'requisition.makerName',
        'requisition.commentToBuyer',
        'requisition.commentToVendor',
        'requisition.requiredDate',
        'ship.id',
        'ship.name',
        'mainPart.id',
        'mainPart.name',
        'documents.id',
        'documents.fileName',
        'documents.mimeType',
        'documents.updatedOn',
      ])
      .leftJoin('requisition.ship', 'ship')
      .leftJoin('requisition.mainPart', 'mainPart')
      .leftJoin('requisition.documents', 'documents');

    if (status) {
      query.where('requisition.status = :status', { status });
    }

    if (search) {
      query.andWhere(
        '(requisition.prNumber ILIKE :search OR requisition.description ILIKE :search)',
        { search: `%${search}%` },
      );
    }

    // Pagination logic
    const [data, total] = await query
      .orderBy('requisition.updatedOn', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return {
      data,
      total,
      page,
      limit,
    };
  }

  async getItemsByRequisitionId(
    requisitionId: number,
  ): Promise<RequisitionItemResponseDto[]> {
    const requisition = await this.requisitionRepository.findOne({
      where: { id: requisitionId },
    });

    if (!requisition) {
      throw new NotFoundException(
        `Requisition with ID ${requisitionId} not found`,
      );
    }

    const items = await this.requisitionItemRepository.find({
      where: { requisition: { id: requisitionId } },
      relations: ['file'],
    });

    return items.map((item) => ({
      ...item,
      file: item.file
        ? { id: item.file.id, fileName: item.file.fileName }
        : null,
    }));
  }

  async updateRequisition(
    id: number,
    updateRequisitionDto: UpdateRequisitionDto,
  ): Promise<RequisitionEntity> {
    // Validate and fetch the requisition
    const requisition = await this.getRequisitionById(id);

    // Update requisition-level fields
    await this.updateRequisitionDetails(requisition, updateRequisitionDto);

    // Update requisition items (add, update, delete)
    await this.updateRequisitionItems(
      requisition,
      updateRequisitionDto.items || [],
    );

    return this.requisitionRepository.save(requisition);
  }

  private async getRequisitionById(id: number): Promise<RequisitionEntity> {
    const requisition = await this.requisitionRepository.findOne({
      where: { id },
      relations: ['items', 'ship'], // Avoid fetching deeply nested relations like 'items.file'
    });

    if (!requisition) {
      throw new NotFoundException(`Requisition with ID ${id} not found`);
    }

    return requisition;
  }

  private async updateRequisitionDetails(
    requisition: RequisitionEntity,
    updateRequisitionDto: UpdateRequisitionDto,
  ): Promise<void> {
    const {
      shipId,
      type,
      mainPartId,
      modelName,
      makerName,
      ...requisitionData
    } = updateRequisitionDto;

    // Validate and update ship
    if (shipId && shipId !== requisition.ship.id) {
      const ship = await this.shipValidationService.getShipById(shipId);
      if (!ship) {
        throw new NotFoundException(`Ship with ID ${shipId} not found`);
      }
      requisition.ship = ship;
    }

    // Validate and update mainPart
    if (type === InventoryType.SPARE) {
      if (!mainPartId) {
        throw new BadRequestException(
          'MainPartId is required for spare requisitions',
        );
      }

      const mainPart = await this.mainPartRepository.findOne({
        where: { id: mainPartId },
      });
      if (!mainPart) {
        throw new NotFoundException(
          `Main Part with ID ${mainPartId} not found`,
        );
      }

      requisition.mainPart = mainPart;
    }

    requisition.modelName = modelName;
    requisition.makerName = makerName;

    // Update other fields
    Object.assign(requisition, requisitionData);
  }

  private async updateRequisitionItems(
    requisition: RequisitionEntity,
    items: UpdateRequisitionItemDto[],
  ): Promise<void> {
    const existingItemIds = requisition.items.map((item) => item.id);
    const incomingItemIds = items.map((item) => item.id).filter((id) => !!id);

    // Remove items not included in the updated list
    const itemsToRemove = existingItemIds.filter(
      (id) => !incomingItemIds.includes(id),
    );
    if (itemsToRemove.length > 0) {
      await this.requisitionItemRepository.delete(itemsToRemove);
    }

    // Add or update items
    for (const itemDto of items) {
      if (itemDto.id) {
        // Update existing item
        await this.updateExistingItem(itemDto);
      } else {
        // Add new item
        await this.addNewItem(requisition, itemDto);
      }
    }
  }

  private async updateExistingItem(
    itemDto: UpdateRequisitionItemDto,
  ): Promise<void> {
    const existingItem = await this.requisitionItemRepository.findOne({
      where: { id: itemDto.id },
      relations: ['inventoryItem'],
    });

    if (!existingItem) {
      throw new NotFoundException(`Item with ID ${itemDto.id} not found`);
    }

    Object.assign(existingItem, itemDto);
    await this.requisitionItemRepository.save(existingItem);
  }

  private async addNewItem(
    requisition: RequisitionEntity,
    itemDto: UpdateRequisitionItemDto,
  ): Promise<void> {
    let inventoryItem: SpareEntity | undefined;

    if (itemDto.inventoryItemId) {
      inventoryItem = await this.spareRepository.findOne({
        where: { id: itemDto.inventoryItemId },
      });

      if (!inventoryItem) {
        throw new NotFoundException(
          `Spare item with ID ${itemDto.inventoryItemId} not found`,
        );
      }
    }

    const newItem = this.requisitionItemRepository.create({
      ...itemDto,
      requisition,
      inventoryItem,
    });

    await this.requisitionItemRepository.save(newItem);
  }

  async uploadRequisitionFiles(
    requisitionId: number,
    files: Express.Multer.File[],
  ): Promise<FileStorageEntity[]> {
    const requisition = await this.requisitionRepository.findOne({
      where: { id: requisitionId },
    });

    if (!requisition) {
      throw new NotFoundException(
        `Requisition with ID ${requisitionId} not found`,
      );
    }

    const fileEntities = files.map((file) => {
      const fileEntity = new FileStorageEntity();
      fileEntity.data = file.buffer;
      fileEntity.mimeType = file.mimetype;
      fileEntity.fileName = file.originalname;
      fileEntity.requisition = requisition;
      return fileEntity;
    });

    return await this.fileStorageRepository.save(fileEntities);
  }

  async getRequisitionByRequisitonId(id: number): Promise<RequisitionEntity> {
    const query = this.requisitionRepository
      .createQueryBuilder('requisition')
      .select([
        'requisition.id',
        'requisition.prNumber',
        'requisition.description',
        'requisition.portOfSupply',
        'requisition.priority',
        'requisition.type',
        'requisition.status',
        'requisition.createdOn',
        'requisition.modelName',
        'requisition.makerName',
        'requisition.commentToBuyer',
        'requisition.commentToVendor',
        'requisition.requiredDate',
        'ship.id',
        'ship.name',
        'mainPart.id',
        'mainPart.name',
        'documents.id',
        'documents.fileName',
        'documents.mimeType',
        'documents.updatedOn',
      ])
      .leftJoin('requisition.ship', 'ship')
      .leftJoin('requisition.mainPart', 'mainPart')
      .leftJoin('requisition.documents', 'documents')
      .where('requisition.id = :id', { id });

    return query.getOne();
  }
}
