import {
  IsNotEmpty,
  IsEnum,
  IsString,
  ValidateNested,
  IsArray,
  IsNumber,
  IsOptional,
  IsDate,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  InventoryType,
  RequisitionPriority,
} from 'src/utils/models/common.types';
import { CreateRequisitionItemDto } from './create-requisition-item.dto';

export class CreateRequisitionDto {
  @ApiProperty({ description: 'Ship ID associated with the requisition' })
  @IsNumber()
  @IsNotEmpty()
  shipId: number;

  @ApiProperty({ description: 'Description of the requisition' })
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiProperty({ description: 'Port of supply' })
  @IsString()
  @IsNotEmpty()
  portOfSupply: string;

  @ApiProperty({ description: 'Priority level', enum: RequisitionPriority })
  @IsEnum(RequisitionPriority)
  @IsNotEmpty()
  priority: RequisitionPriority;

  @ApiProperty({ description: 'Requisition type', enum: InventoryType })
  @IsEnum(InventoryType)
  @IsNotEmpty()
  type: InventoryType;

  @ApiProperty({
    description: 'Main part ID (required if type is spare)',
    required: false,
  })
  @IsOptional()
  @IsNumber()
  mainPartId?: number;

  @ApiProperty({
    description: 'Maker name (optional)',
    required: false,
  })
  @IsOptional()
  @IsString()
  makerName?: string;

  @ApiProperty({
    description: 'Model name (optional)',
    required: false,
  })
  @IsOptional()
  @IsString()
  modelName?: string;

  @ApiProperty({
    description: 'Comment to vendor',
    required: false,
  })
  @IsOptional()
  @IsString()
  commentToVendor?: string;

  @ApiProperty({
    description: 'Comment to buyer',
    required: false,
  })
  @IsOptional()
  @IsString()
  commentToBuyer?: string;

  @ApiProperty({
    description: 'Purchase required date',
    required: false,
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  requiredDate?: Date;

  @ApiProperty({
    description: 'Items for the requisition',
    type: [CreateRequisitionItemDto],
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateRequisitionItemDto)
  items: CreateRequisitionItemDto[];
}
