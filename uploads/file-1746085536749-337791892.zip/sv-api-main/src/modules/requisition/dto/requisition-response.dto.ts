export class RequisitionResponseDto {
  id: number;
  prNumber: string;
  description: string;
  portOfSupply: string;
  priority: string;
  type: string;
  status: string;
  createdOn: Date;
  modelName: string;
  makerName: string;
  commentToVendor: string;
  commentToBuyer: string;
  requiredDate: Date;
  ship: {
    id: number;
    name: string;
    imoNumber: string;
  };
  mainPart?: {
    id: number;
    name: string;
  };
  items: RequisitionItemResponseDto[];
}

export class RequisitionItemResponseDto {
  id: number;
  description: string;
  partNumber: string;
  drawingNumber: string;
  requestedQuantity: number;
  uom: string;
  remarks: string;
  file?: FileResponseDto;
  commentToVendor: string;
  commentToBuyer: string;
}

export class FileResponseDto {
  id: string;
  fileName: string;
}
