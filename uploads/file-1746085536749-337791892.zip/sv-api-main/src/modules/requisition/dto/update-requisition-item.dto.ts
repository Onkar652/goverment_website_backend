import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsOptional, IsString } from 'class-validator';

export class UpdateRequisitionItemDto {
  @ApiProperty({
    description: 'Requisition item ID (mandatory for updates)',
    required: true,
  })
  @IsNumber()
  id: number;

  @ApiProperty({
    description: 'Inventory item ID (optional for updates)',
    required: false,
  })
  @IsOptional()
  @IsNumber()
  inventoryItemId?: number;

  @ApiProperty({ description: 'Description of the item', required: false })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ description: 'Part number of the item', required: false })
  @IsOptional()
  @IsString()
  partNumber?: string;

  @ApiProperty({ description: 'Item number of the item', required: false })
  @IsOptional()
  @IsString()
  itemNumber?: string;

  @ApiProperty({ description: 'Drawing number of the item', required: false })
  @IsOptional()
  @IsString()
  drawingNumber?: string;

  @ApiProperty({ description: 'Requested quantity', required: false })
  @IsOptional()
  @IsNumber()
  requestedQuantity?: number;

  @ApiProperty({
    description: 'ROB (remaining on board) quantity',
    required: false,
  })
  @IsOptional()
  @IsNumber()
  rob?: number;

  @ApiProperty({
    description: 'Quantity in use (if applicable)',
    required: false,
  })
  @IsOptional()
  @IsNumber()
  quantityInUse?: number;

  @ApiProperty({ description: 'Unit of measure (optional)', required: false })
  @IsOptional()
  @IsString()
  uom?: string;

  @ApiProperty({ description: 'Remarks (optional)', required: false })
  @IsOptional()
  @IsString()
  remarks?: string;

  @ApiProperty({
    description: 'Comment to vendor',
    required: false,
  })
  @IsOptional()
  @IsString()
  commentToVendor?: string;

  @ApiProperty({
    description: 'Comment to buyer',
    required: false,
  })
  @IsOptional()
  @IsString()
  commentToBuyer?: string;
}
