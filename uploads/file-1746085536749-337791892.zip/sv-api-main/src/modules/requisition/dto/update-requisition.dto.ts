import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsDate,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import {
  RequisitionPriority,
  InventoryType,
} from 'src/utils/models/common.types';
import { UpdateRequisitionItemDto } from './update-requisition-item.dto';

export class UpdateRequisitionDto {
  @ApiProperty({ description: 'Requisition ID (mandatory)' })
  @IsNumber()
  @IsNotEmpty()
  id: number;

  @ApiProperty({
    description: 'Ship ID associated with the requisition (mandatory)',
  })
  @IsNumber()
  @IsNotEmpty()
  shipId: number;

  @ApiProperty({
    description: 'Description of the requisition',
    required: false,
  })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ description: 'Port of supply', required: false })
  @IsOptional()
  @IsString()
  portOfSupply?: string;

  @ApiProperty({
    description: 'Priority level',
    enum: RequisitionPriority,
    required: false,
  })
  @IsOptional()
  @IsEnum(RequisitionPriority)
  priority?: RequisitionPriority;

  @ApiProperty({
    description: 'Requisition type',
    enum: InventoryType,
    required: false,
  })
  @IsOptional()
  @IsEnum(InventoryType)
  type?: InventoryType;

  @ApiProperty({
    description: 'Main part ID (required if type is spare)',
    required: false,
  })
  @IsOptional()
  @IsNumber()
  mainPartId?: number;

  @ApiProperty({
    description: 'Maker name (optional)',
    required: false,
  })
  @IsOptional()
  @IsString()
  makerName?: string;

  @ApiProperty({
    description: 'Model name (optional)',
    required: false,
  })
  @IsOptional()
  @IsString()
  modelName?: string;

  @ApiProperty({
    description: 'Comment to vendor',
    required: false,
  })
  @IsOptional()
  @IsString()
  commentToVendor?: string;

  @ApiProperty({
    description: 'Comment to buyer',
    required: false,
  })
  @IsOptional()
  @IsString()
  commentToBuyer?: string;

  @ApiProperty({
    description: 'Purchase required date',
    required: false,
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  requiredDate?: Date;

  @ApiProperty({
    description: 'Items for the requisition',
    type: [UpdateRequisitionItemDto],
    required: false,
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UpdateRequisitionItemDto)
  items?: UpdateRequisitionItemDto[];
}
