import {
  BadRequestException,
  Body,
  Controller,
  Get,
  NotFoundException,
  Param,
  Post,
  Put,
  Query,
  UploadedFile,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor, FilesInterceptor } from '@nestjs/platform-express';
import {
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { RequisitionEntity } from 'src/entities/requisitions/requisition.entity';
import { RequisitionStatus } from 'src/utils/models/common.types';
import { CreateRequisitionDto } from './dto/create-requisition.dto';
import { RequisitionItemResponseDto } from './dto/requisition-response.dto';
import { RequisitionService } from './requisition.service';
import { UpdateRequisitionDto } from './dto/update-requisition.dto';

@ApiTags('Requisitions')
@Controller('requisition')
export class RequisitionController {
  constructor(private readonly requisitionService: RequisitionService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new requisition' })
  @ApiResponse({
    status: 201,
    description: 'Requisition created successfully',
    type: RequisitionEntity,
  })
  create(@Body() createRequisitionDto: CreateRequisitionDto) {
    return this.requisitionService.createRequisition(createRequisitionDto);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get requisition by ID' })
  @ApiResponse({
    status: 200,
    description: 'Requisition found',
  })
  @ApiResponse({
    status: 404,
    description: 'Requisition not found',
  })
  @ApiParam({
    name: 'id',
    description: 'ID of the requisition',
    type: Number,
  })
  async getRequisitionById(@Param('id') id: number) {
    const requisition =
      await this.requisitionService.getRequisitionByRequisitonId(id);

    if (!requisition) {
      throw new NotFoundException(`Requisition with ID ${id} not found`);
    }

    return requisition;
  }

  @Post(':itemId/upload')
  @ApiOperation({ summary: 'Upload a file for a requisition item' })
  @ApiConsumes('multipart/form-data')
  @ApiParam({ name: 'itemId', description: 'ID of the requisition item' })
  @ApiResponse({
    status: 201,
    description: 'File uploaded successfully',
    schema: {
      type: 'object',
      properties: {
        message: { type: 'string', example: 'File uploaded successfully' },
        fileId: {
          type: 'string',
          example: '123e4567-e89b-12d3-a456-426614174000',
        },
      },
    },
  })
  @ApiResponse({
    status: 400,
    description: 'No file uploaded',
  })
  @ApiResponse({
    status: 404,
    description: 'Requisition item not found',
  })
  @ApiBody({
    description: 'File to upload',
    required: true,
    schema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @UseInterceptors(FileInterceptor('file')) // Multer handles file upload
  async uploadFile(
    @Param('itemId') itemId: number,
    @UploadedFile() file: Express.Multer.File,
  ): Promise<{ message: string; fileId: string }> {
    if (!file) {
      throw new BadRequestException('No file uploaded');
    }

    const savedFile =
      await this.requisitionService.uploadFileForRequisitionItem(itemId, file);

    return {
      message: 'File uploaded successfully',
      fileId: savedFile.id, // Return only the file ID, not the entire entity or file data
    };
  }

  @Get()
  @ApiOperation({ summary: 'Get all requisitions with pagination & search' })
  @ApiQuery({
    name: 'page',
    required: false,
    type: Number,
    description: 'Page number (default: 1)',
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    description: 'Items per page (default: 10)',
  })
  @ApiQuery({
    name: 'search',
    required: false,
    type: String,
    description: 'Search by prNumber or description',
  })
  @ApiQuery({
    name: 'status',
    required: false,
    enum: RequisitionStatus,
    description: 'Filter by status (optional)',
  })
  @ApiResponse({
    status: 200,
    description: 'List of requisitions with pagination',
    type: [RequisitionEntity],
  })
  async getRequisitions(
    @Query('status') status?: RequisitionStatus,
    @Query('search') search?: string,
    @Query('page') page = 1,
    @Query('limit') limit = 10,
  ): Promise<{
    data: RequisitionEntity[];
    total: number;
    page: number;
    limit: number;
  }> {
    return this.requisitionService.getRequisitions(status, search, page, limit);
  }

  @Get(':id/items')
  @ApiOperation({ summary: 'Get items for a specific requisition' })
  @ApiParam({ name: 'id', description: 'Requisition ID' })
  @ApiResponse({
    status: 200,
    description: 'List of items for the requisition',
    type: [RequisitionItemResponseDto],
  })
  @ApiResponse({
    status: 404,
    description: 'Requisition not found',
  })
  async getItemsByRequisitionId(
    @Param('id') id: number,
  ): Promise<RequisitionItemResponseDto[]> {
    return this.requisitionService.getItemsByRequisitionId(id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update a requisition' })
  @ApiParam({ name: 'id', description: 'ID of the requisition to update' })
  @ApiBody({ type: UpdateRequisitionDto })
  @ApiResponse({
    status: 200,
    description: 'Requisition updated successfully',
    type: RequisitionEntity,
  })
  @ApiResponse({ status: 404, description: 'Requisition not found' })
  async updateRequisition(
    @Param('id') id: number,
    @Body() updateRequisitionDto: UpdateRequisitionDto,
  ): Promise<RequisitionEntity> {
    return this.requisitionService.updateRequisition(id, updateRequisitionDto);
  }

  @Post('upload-req-doc/:requisitionId')
  @ApiOperation({ summary: 'Upload documents for a requisition' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'File upload for requisition',
    schema: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  @UseInterceptors(FilesInterceptor('files', 10))
  async uploadRequisitionFiles(
    @Param('requisitionId') requisitionId: number,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<{ message: string; fileIds: string[] }> {
    if (!files || files.length === 0) {
      throw new BadRequestException('No files uploaded');
    }

    const uploadedFiles = await this.requisitionService.uploadRequisitionFiles(
      requisitionId,
      files,
    );

    return {
      message: 'Files uploaded successfully',
      fileIds: uploadedFiles.map((file) => file.id),
    };
  }
}
