import { Module } from '@nestjs/common';
import { WorkOrdersService } from './work-orders.service';
import { WorkOrdersController } from './work-orders.controller';
import { MulterModule } from '@nestjs/platform-express';
import * as multer from 'multer';
import { ShipValidationService } from '../common/ship-validation.service';

@Module({
  imports: [
    MulterModule.register({
      storage: multer.memoryStorage(), // Use memory storage
    }),
  ],
  controllers: [WorkOrdersController],
  providers: [WorkOrdersService, ShipValidationService],
})
export class WorkOrdersModule {}
