import {
  BadRequestException,
  Injectable,
  InternalServerErrorException,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import * as sharp from 'sharp';
import { workOrderData } from 'src/config-data/wo-template';
import { RankMapping } from 'src/config/config';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { SpareEntity } from 'src/entities/inventory/spares.entity';
import { ChecklistConfig } from 'src/entities/shipActions/wo-checklist-config.entity';
import { WorkOrderChecklist } from 'src/entities/shipActions/work-order-checklist.entity';
import { WorkOrderSpareEntity } from 'src/entities/shipActions/work-order-spare.entity';
import { WorkOrder } from 'src/entities/shipActions/work-order.entity';
import { WorkOrderConfig } from 'src/entities/shipActions/workOrder-config.entity';
import { MainPartComponent } from 'src/entities/shipParts/main-part-components.entity';
import { Ship } from 'src/entities/ships/ships.entity';
import { generateJobId } from 'src/utils/utils';
import { Readable, Writable, pipeline } from 'stream';
import { DataSource, EntityManager, In, Repository } from 'typeorm';
import { promisify } from 'util';
import * as XLSX from 'xlsx';
import { createGzip } from 'zlib';
import { ShipValidationService } from '../common/ship-validation.service';
import { WorkOrderQueryDto } from './dto/get-work-order.dto';
import { SpareConsumptionDto } from './dto/spare-consumption.dto';
import { DeleteFilesDto } from './dto/update-wo-docs.dto';
import {
  UpdateChecklistDto,
  UpdateWorkOrderDto,
  UpdateWorkOrderSpareDto,
} from './dto/update-work-order.dto';
import * as moment from 'moment';
import {
  SpareTransaction,
  TransactionReason,
} from 'src/entities/inventory/spare-transaction.entity';
import { allowedWorkOrderSortFields } from './configs/sort-column.config';
const pipe = promisify(pipeline);

@Injectable()
export class WorkOrdersService {
  private readonly logger = new Logger(WorkOrdersService.name);

  private shipRepo: Repository<Ship>;
  private mainPartComponentRepository: Repository<MainPartComponent>;
  private workOrderConfigRepository: Repository<WorkOrderConfig>;
  private workOrderRepository: Repository<WorkOrder>;
  private fileStorageRepository: Repository<FileStorageEntity>;
  private checklistConfigRepository: Repository<ChecklistConfig>;
  private spareRepository: Repository<SpareEntity>;
  private workOrderSpareRepository: Repository<WorkOrderSpareEntity>;

  constructor(
    private readonly dataSource: DataSource,
    private shipValidationService: ShipValidationService,
  ) {
    this.shipRepo = this.dataSource.getRepository(Ship);
    this.mainPartComponentRepository =
      this.dataSource.getRepository(MainPartComponent);
    this.workOrderConfigRepository =
      this.dataSource.getRepository(WorkOrderConfig);
    this.workOrderRepository = this.dataSource.getRepository(WorkOrder);
    this.fileStorageRepository =
      this.dataSource.getRepository(FileStorageEntity);
    this.checklistConfigRepository =
      this.dataSource.getRepository(ChecklistConfig);
    this.spareRepository = this.dataSource.getRepository(SpareEntity);
    this.workOrderSpareRepository =
      this.dataSource.getRepository(WorkOrderSpareEntity);
  }

  private parseMaxServicePeriod(interval: number, countertype: string): string {
    switch (countertype) {
      case 'Monthly':
        return `${interval}M`; // e.g., "3M" for 3 months
      case 'Weekly':
        return `${interval}W`; // e.g., "1W" for 1 week
      case 'Yearly':
        return `${interval}Y`; // e.g., "1Y" for 1 year
      case 'Hours':
        return null; // Not time-based, so return null
      default:
        return `${interval}D`; // Default to days
    }
  }

  async insertWorkOrderConfigFromCsv(shipId: number): Promise<void> {
    const ship = await this.getShipById(shipId);
    if (!ship) {
      throw new NotFoundException('Ship not found');
    }
    const configData = workOrderData;

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      for (const row of configData) {
        const {
          JobTitle,
          Reminder,
          interval,
          countertype,
          LastDoneDate,
          CompName,
          JobID,
          Rank,
        } = row;

        // Parse maxServicePeriod from interval and countertype
        const maxServicePeriod = this.parseMaxServicePeriod(
          interval,
          countertype,
        );

        // Check if the task is based on running hours (countertype = 'Hours')
        const maxRunHoursToService = countertype === 'Hours' ? interval : null;
        const collectRunHours = countertype === 'Hours';

        // Find the associated MainPartComponent using CompName and shipId
        const component = await this.mainPartComponentRepository
          .createQueryBuilder('component')
          .innerJoinAndSelect('component.mainPart', 'mainPart') // Join MainPart
          .innerJoinAndSelect('mainPart.ship', 'ship') // Join Ship through MainPart
          .where('component.name = :name', { name: CompName }) // Filter by component name
          .andWhere('ship.id = :shipId', { shipId }) // Filter by ship ID
          .getOne();

        if (!component) {
          // If component not found, log it and continue to the next row
          this.logger.warn(
            `Component with name "${CompName}" for shipId ${shipId} not found, skipping work order config.`,
          );
          continue;
        }

        const rankEnum = RankMapping[Rank];

        // Create new WorkOrderConfig entity and save it
        const workOrderConfig = this.workOrderConfigRepository.create({
          jobId: JobID,
          description: JobTitle,
          reminderValue: Reminder,
          reminderUnit: countertype === 'Hours' ? 'H' : 'D', // Assume 'H' for hours, 'D' for days
          maxRunHoursToService,
          maxServicePeriod,
          collectRunHours,
          nextServiceDate: LastDoneDate ? new Date(LastDoneDate) : null, // Optional next service date
          component, // Link the main part component
          disabled: false,
          responsibleRank: rankEnum,
          jobDescription: '',
        });

        // Save the new config entry
        await this.workOrderConfigRepository.save(workOrderConfig);
        await queryRunner.manager.save(WorkOrderConfig, workOrderConfig);
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      // Log the error and continue with the next row
      await queryRunner.rollbackTransaction();
      throw new BadRequestException(
        'Error inserting work order config: ' + error.message,
      );
    } finally {
      await queryRunner.release();
    }
  }

  async updateWorkOrderConfigs(): Promise<void> {
    const configData = workOrderData; // Your array of new data

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      for (const data of configData) {
        const { JobID, Rank, JobTitle } = data;
        const rankEnum = RankMapping[Rank];

        await this.workOrderConfigRepository.update(
          { jobId: JobID }, // Where clause to find the record
          {
            responsibleRank: rankEnum, // Update rank
            description: JobTitle, // Update job description
          },
        );
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw new Error('Failed to update work order configs: ' + error.message);
    } finally {
      await queryRunner.release();
    }
  }

  async update(
    id: number,
    updateWorkOrderDto: UpdateWorkOrderDto,
  ): Promise<WorkOrder> {
    const workOrder = await this.workOrderRepository.preload({
      id: id,
      ...updateWorkOrderDto,
    });

    if (!workOrder) {
      return null;
    }

    return this.workOrderRepository.save(workOrder);
  }

  async getShipById(shipId: number): Promise<Ship> {
    const ship = await this.shipRepo.findOne({
      where: { id: shipId, disabled: false },
      relations: ['client', 'voyages', 'userDetails', 'mainParts'], // Include any relations needed
    });
    if (!ship) {
      throw new NotFoundException('Ship not found');
    }
    return ship;
  }

  async findDistinctComponentsCollectingRunHours(): Promise<
    MainPartComponent[]
  > {
    return this.mainPartComponentRepository
      .createQueryBuilder('component')
      .innerJoin('component.workOrderConfig', 'workOrderConfig')
      .where('workOrderConfig.collectRunHours = :collectRunHours', {
        collectRunHours: true,
      })
      .distinct(true)
      .getMany();
  }

  async findWorkOrdersByMainPartAndShip(
    mainPartId: number,
    shipId: number,
  ): Promise<WorkOrderConfig[]> {
    await this.getShipById(shipId);
    return this.workOrderConfigRepository
      .createQueryBuilder('workOrder')
      .innerJoin('workOrder.component', 'component')
      .innerJoin('component.mainPart', 'mainPart')
      .where('mainPart.id = :mainPartId', { mainPartId })
      .andWhere('mainPart.shipId = :shipId', { shipId })
      .getMany();
  }

  async findAllWorkOrderConfigs(shipId: number): Promise<WorkOrderConfig[]> {
    await this.shipValidationService.getShipById(shipId);

    const allWoConfigs = this.workOrderConfigRepository
      .createQueryBuilder('workOrder')
      .leftJoinAndSelect('workOrder.component', 'component')
      .leftJoinAndSelect('component.mainPart', 'mainPart')
      .where('mainPart.shipId = :shipId', { shipId })
      .getMany();

    return allWoConfigs;
  }

  async findAllWorkOrdersByShipId(shipId: number): Promise<WorkOrder[]> {
    const ship = await this.getShipById(shipId);
    if (!ship) {
      throw new NotFoundException('Ship not found');
    }
    try {
      const wo = await this.workOrderRepository.find({
        where: {
          ship: { id: shipId },
        },
        relations: [
          'ship',
          'ptwDocument',
          'raDocument',
          'otherDocuments',
          'jobPhotos',
          'component',
        ],
        select: {
          ptwDocument: {
            id: true,
            mimeType: true,
            fileName: true,
            // Explicitly exclude 'data'
          },
          raDocument: {
            id: true,
            mimeType: true,
            fileName: true,
            // Explicitly exclude 'data'
          },
          otherDocuments: {
            id: true,
            mimeType: true,
            fileName: true,
            // Explicitly exclude 'data'
          },
          jobPhotos: {
            id: true,
            mimeType: true,
            fileName: true,
          },
        },
      });
      return wo;
    } catch (error) {
      throw error;
    }
  }
  async handleDocumentUpload(
    workOrderId: number,
    files: {
      ptwDocument?: Express.Multer.File[];
      raDocument?: Express.Multer.File[];
      otherDocuments?: Express.Multer.File[];
      jobPhotos?: Express.Multer.File[];
    },
  ): Promise<any> {
    const workOrder = await this.workOrderRepository.findOneBy({
      id: workOrderId,
    });
    if (!workOrder) {
      throw new Error('WorkOrder not found');
    }

    try {
      if (files.ptwDocument && files.ptwDocument.length > 0) {
        await this.processFiles(files.ptwDocument, workOrder, 'ptwDocument');
      }
      if (files.raDocument && files.raDocument.length > 0) {
        await this.processFiles(files.raDocument, workOrder, 'raDocument');
      }
      if (files.otherDocuments && files.otherDocuments.length > 0) {
        await this.processFiles(
          files.otherDocuments,
          workOrder,
          'otherDocumentWorkOrder',
        );
      }
      if (files.jobPhotos && files.jobPhotos.length > 0) {
        await this.processFiles(
          files.jobPhotos,
          workOrder,
          'jobPhotoWorkOrder',
        );
      }

      return { message: 'Documents uploaded successfully' };
    } catch (error) {
      throw new Error(error);
    }
    // Process each type of document if present
  }

  async findWorkOrderByIdOrJobId(
    id: number,
    jobId: string,
    shipId: number,
  ): Promise<WorkOrder | undefined> {
    let where = {};
    if (id) {
      where = { id: id, ship: { id: shipId } };
    } else {
      where = { jobId: jobId, ship: { id: shipId } };
    }
    return this.workOrderRepository.findOne({
      where,
      relations: [
        'ship',
        'ptwDocument',
        'raDocument',
        'otherDocuments',
        'jobPhotos',
        'checklistItems',
        'component',
        'component.mainPart',
        'consumedSpares', // Include consumed spares
        'consumedSpares.spare',
      ],
      select: {
        ptwDocument: {
          id: true,
          mimeType: true,
          fileName: true,
        },
        raDocument: {
          id: true,
          mimeType: true,
          fileName: true,
        },
        otherDocuments: {
          id: true,
          mimeType: true,
          fileName: true,
        },
        jobPhotos: {
          id: true,
          mimeType: true,
          fileName: true,
        },
      },
    });
  }

  private async processFiles(
    files: Express.Multer.File[],
    workOrder: WorkOrder,
    propertyName:
      | 'ptwDocument'
      | 'raDocument'
      | 'otherDocumentWorkOrder'
      | 'jobPhotoWorkOrder',
  ): Promise<void> {
    if (files && files.length > 0) {
      for (const file of files) {
        const fileEntity = new FileStorageEntity();
        fileEntity.mimeType = file.mimetype;
        fileEntity.fileName = file.originalname;

        // Determine how to handle the file based on the property name
        if (propertyName === 'jobPhotoWorkOrder') {
          fileEntity.data = await this.compressImage(file);
        } else if (['ptwDocument', 'raDocument'].includes(propertyName)) {
          fileEntity.data = file.buffer; // No compression for these document types
        } else {
          fileEntity.data = await this.compressFile(file);
        }
        if (
          propertyName === 'otherDocumentWorkOrder' ||
          propertyName === 'jobPhotoWorkOrder'
        ) {
          fileEntity[propertyName] = workOrder;
        } else {
          workOrder[propertyName] = fileEntity;
        }

        // Save the file entity to the database
        await this.fileStorageRepository.save(fileEntity);
      }

      await this.workOrderRepository.save(workOrder);
    }
  }

  async compressFile(file: Express.Multer.File): Promise<Buffer> {
    if (['text/plain', 'text/csv', 'text/html'].includes(file.mimetype)) {
      return this.compressText(file.buffer);
    }
    return file.buffer;
  }

  async compressImage(file: Express.Multer.File): Promise<Buffer> {
    return sharp(file.buffer)
      .resize(1024) // Resize to a reasonable size
      .jpeg({ quality: 80 }) // Convert to JPEG with good quality
      .toBuffer();
  }

  async compressText(data: Buffer): Promise<Buffer> {
    const gzip = createGzip();
    const source = Readable.from(data); // Correctly create a readable stream from buffer
    const chunks: Buffer[] = [];

    const writable = new Writable({
      write(chunk, encoding, callback) {
        chunks.push(Buffer.from(chunk)); // Make sure to convert chunk to Buffer if not already
        callback();
      },
    });

    await pipe(source, gzip, writable);

    return Buffer.concat(chunks as any);
  }

  async getFileById(id: string): Promise<FileStorageEntity | undefined> {
    return this.fileStorageRepository.findOneBy({ id });
  }

  async findWorkOrdersByStatus(
    queryDto: WorkOrderQueryDto,
  ): Promise<{ data: WorkOrder[]; total: number }> {
    const {
      shipId,
      status,
      search,
      page = 1,
      limit = 10,
      mainPartId,
      sortField,
      sortOrder,
    } = queryDto;

    if (!shipId) {
      throw new BadRequestException('Ship ID is required');
    }

    // Verify ship existence
    const ship = await this.getShipById(shipId);
    if (!ship) {
      throw new NotFoundException('Ship not found');
    }

    // Determine the primary sort column and order
    let primarySortColumn = 'workOrder.dueDate';
    let primarySortOrder: 'ASC' | 'DESC' = 'DESC';

    if (sortField && sortOrder) {
      const lowerSortOrder = sortOrder.toUpperCase();
      // Check if provided sortField is in our whitelist and sortOrder is valid
      if (
        allowedWorkOrderSortFields[sortField] &&
        (lowerSortOrder === 'ASC' || lowerSortOrder === 'DESC')
      ) {
        primarySortColumn = allowedWorkOrderSortFields[sortField];
        primarySortOrder = lowerSortOrder as 'ASC' | 'DESC';
      }
    }

    // Create a QueryBuilder for work orders
    const queryBuilder = this.workOrderRepository
      .createQueryBuilder('workOrder')
      .leftJoinAndSelect('workOrder.ship', 'ship')
      .leftJoinAndSelect('workOrder.component', 'component')
      .leftJoinAndSelect('component.mainPart', 'mainPart')
      .where('workOrder.ship = :shipId', { shipId });

    // Apply optional filters
    if (status) {
      queryBuilder.andWhere('workOrder.status = :status', { status });
    }

    if (search) {
      queryBuilder.andWhere('LOWER(workOrder.title) LIKE LOWER(:search)', {
        search: `%${search}%`,
      });
    }

    if (mainPartId) {
      queryBuilder.andWhere('mainPart.id = :mainPartId', { mainPartId });
    }
    queryBuilder
      .orderBy(primarySortColumn, primarySortOrder)
      .addOrderBy('workOrder.createdAt', 'DESC');

    // Apply pagination
    const [data, total] = await queryBuilder
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    // Handle no data found
    if (!data.length) {
      return {
        data: [],
        total: 0,
      };
    }

    return { data, total };
  }

  async deleteFiles(deleteFiledto: DeleteFilesDto): Promise<void> {
    // Find all files to be deleted
    const { fileIds, shipId } = deleteFiledto;

    if (!shipId || !fileIds.length) {
      throw new BadRequestException('Invalid params');
    }
    const ship = await this.getShipById(shipId);
    if (!ship) {
      throw new NotFoundException('Ship not found');
    }
    const files = await this.fileStorageRepository.find({
      where: { id: In(fileIds) },
      relations: ['otherDocumentWorkOrder', 'jobPhotoWorkOrder'],
    });

    if (files.length !== fileIds.length) {
      throw new NotFoundException('One or more files not found');
    }

    const queryRunner =
      this.fileStorageRepository.manager.connection.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      for (const file of files) {
        // Check for ptwDocument or raDocument relationships in WorkOrders
        const workOrders = await this.workOrderRepository.find({
          where: [
            { ptwDocument: { id: file.id } },
            { raDocument: { id: file.id } },
          ],
          relations: ['ptwDocument', 'raDocument'],
        });

        for (const workOrder of workOrders) {
          if (workOrder.ptwDocument && workOrder.ptwDocument.id === file.id) {
            workOrder.ptwDocument = null;
          }
          if (workOrder.raDocument && workOrder.raDocument.id === file.id) {
            workOrder.raDocument = null;
          }
          await queryRunner.manager.save(workOrder);
        }

        // Handle one-to-many relationships
        if (file.otherDocumentWorkOrder) {
          file.otherDocumentWorkOrder.otherDocuments =
            file.otherDocumentWorkOrder.otherDocuments.filter(
              (doc) => doc.id !== file.id,
            );
          await queryRunner.manager.save(file.otherDocumentWorkOrder);
        }
        if (file.jobPhotoWorkOrder) {
          file.jobPhotoWorkOrder.jobPhotos =
            file.jobPhotoWorkOrder.jobPhotos.filter(
              (photo) => photo.id !== file.id,
            );
          await queryRunner.manager.save(file.jobPhotoWorkOrder);
        }

        await queryRunner.manager.remove(FileStorageEntity, file);
      }

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw new InternalServerErrorException(
        'Failed to delete files: ' + error.message,
      );
    } finally {
      await queryRunner.release();
    }
  }

  async importDataFromExcel(fileBuffer: Buffer): Promise<void> {
    const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const excelData = XLSX.utils.sheet_to_json(sheet);

    for (const row of excelData) {
      const { Title, jd: jobDescription, checks: Checklist } = row as any;

      // Find all matching WorkOrderConfigs
      const workOrderConfigs = await this.workOrderConfigRepository.find({
        where: { description: Title.trim() }, // Match title by description
        relations: ['checklistItems'], // Load existing checklist items
      });

      if (workOrderConfigs.length === 0) {
        console.warn(`No matching WorkOrderConfig found for title: ${Title}`);
        continue; // Skip if no matching work order found
      }

      for (const workOrderConfig of workOrderConfigs) {
        // Update job description only if different
        if (workOrderConfig.jobDescription !== jobDescription) {
          workOrderConfig.jobDescription = jobDescription;
          await this.workOrderConfigRepository.save(workOrderConfig);
        }

        // If checklist items already exist, skip insertion
        if (workOrderConfig.checklistItems.length > 0) {
          console.log(
            `Checklist already exists for: ${Title}, skipping insertion.`,
          );
          continue;
        }

        // Parse checklist items from the Excel data
        const checklistItems = (Checklist || '')
          .split('*')
          .map((item: string) => item.trim())
          .filter(Boolean);

        if (checklistItems.length > 0) {
          // Create and save checklist entries
          const checklistEntities = checklistItems.map((description) => {
            const checklistConfig = new ChecklistConfig();
            checklistConfig.description = description;
            checklistConfig.workOrderConfig = workOrderConfig;
            return checklistConfig;
          });

          await this.checklistConfigRepository.save(checklistEntities);
          console.log(
            `Inserted ${checklistEntities.length} checklist items for: ${Title}`,
          );
        } else {
          console.log(`No checklist items found for: ${Title}`);
        }
      }
    }

    console.log('DOne!!!🚀');
  }

  async approveWorkOrder(
    jobId: string,
    completedCounter: number | null,
  ): Promise<WorkOrder> {
    return await this.dataSource.transaction(async (manager) => {
      const approvedWorkOrder = await this.approveWorkOrderTransaction(
        jobId,
        completedCounter,
        manager,
      );
      return approvedWorkOrder;
    });
  }

  async approveWorkOrderTransaction(
    jobId: string,
    completedCounter: number | null,
    manager: EntityManager,
  ): Promise<WorkOrder> {
    // Fetch the existing work order
    const existingWorkOrder = await this.workOrderRepository.findOne({
      where: { jobId: jobId },
      relations: ['config', 'component', 'ship', 'config.checklistItems'],
    });

    if (!existingWorkOrder) {
      throw new NotFoundException(`WorkOrder with ID ${jobId} not found`);
    }

    if (existingWorkOrder.status.toLowerCase() === 'done') {
      throw new BadRequestException(
        `Work Order with ID ${jobId} is already completed.`,
      );
    }

    // Update and approve the current work order
    existingWorkOrder.status = 'done';
    existingWorkOrder.finishedDate = new Date();
    existingWorkOrder.lastDoneDate = new Date();
    existingWorkOrder.lastDoneCounter =
      completedCounter || existingWorkOrder.counterAtEnd || 0;

    // Save the approved work order
    await manager.save(existingWorkOrder);

    const isCounterBased = existingWorkOrder.config.collectRunHours;

    // Create the next work order accordingly
    const newWorkOrder = isCounterBased
      ? await this.createNextCounterBasedWorkOrder(existingWorkOrder, manager)
      : await this.createNextPeriodicWorkOrder(existingWorkOrder, manager);

    return newWorkOrder;
  }

  async createNextCounterBasedWorkOrder(
    previousWorkOrder: WorkOrder,
    manager: EntityManager,
  ): Promise<WorkOrder> {
    const { maxRunHoursToService, reminderUnit, checklistItems } =
      previousWorkOrder.config;

    // Ensure the correct reminder unit
    if (reminderUnit !== 'H') {
      throw new Error(
        `Reminder unit '${reminderUnit}' is not valid for counter-based jobs.`,
      );
    }

    // Calculate next due counter based on maxRunHoursToService
    const lastDoneCounter =
      previousWorkOrder.counterAtEnd ?? previousWorkOrder.counterAtCreation;

    const nextDueCounter = lastDoneCounter + maxRunHoursToService;

    const newWorkOrder = this.workOrderRepository.create({
      jobId: generateJobId(
        previousWorkOrder.ship.code,
        previousWorkOrder.config.jobId,
      ),
      title: previousWorkOrder.title,
      status: 'inwindow',
      component: previousWorkOrder.component,
      config: previousWorkOrder.config,
      jobDescription: previousWorkOrder.jobDescription,
      plannedCost: previousWorkOrder.plannedCost,
      responsibleRank: previousWorkOrder.responsibleRank,
      counterAtCreation: previousWorkOrder.counterAtEnd,
      lastDoneCounter: previousWorkOrder.counterAtEnd,
      lastDoneDate: new Date(),
      dueCounterAtNext: nextDueCounter,
      ship: previousWorkOrder.ship,
      jobInterval: `${previousWorkOrder.config.maxRunHoursToService}H`,
    });

    if (checklistItems && checklistItems.length > 0) {
      newWorkOrder.checklistItems = checklistItems.map((configItem) => {
        const checklist = new WorkOrderChecklist();
        checklist.description = configItem.description;
        checklist.remarks = '';
        return checklist;
      });
    }

    return await manager.save(newWorkOrder);
  }

  async createNextPeriodicWorkOrder(
    previousWorkOrder: WorkOrder,
    manager: EntityManager,
  ): Promise<WorkOrder> {
    const { maxServicePeriod, reminderUnit, checklistItems } =
      previousWorkOrder.config;

    // Ensure maxServicePeriod is valid
    if (!maxServicePeriod || reminderUnit === 'H') {
      console.warn(
        `Skipped periodic job creation: Invalid maxServicePeriod '${maxServicePeriod}' or reminder unit '${reminderUnit}' for job ID ${previousWorkOrder.jobId}.`,
      );
      return null; // Skip job creation gracefully
    }

    // Use last done date or creation date if last done is missing
    const baseDate =
      previousWorkOrder.lastDoneDate ?? previousWorkOrder.createdAt;

    // Calculate next due date based on maxServicePeriod
    const nextDueDate = moment(baseDate)
      .add(this.convertServicePeriodToMomentUnit(maxServicePeriod))
      .toDate();

    const newWorkOrder = this.workOrderRepository.create({
      jobId: generateJobId(
        previousWorkOrder.ship.code,
        previousWorkOrder.config.jobId,
      ),
      title: previousWorkOrder.title,
      status: 'inwindow',
      component: previousWorkOrder.component,
      config: previousWorkOrder.config,
      jobDescription: previousWorkOrder.jobDescription,
      plannedCost: previousWorkOrder.plannedCost,
      responsibleRank: previousWorkOrder.responsibleRank,
      lastDoneDate: new Date(),
      dueDate: nextDueDate,
      ship: previousWorkOrder.ship,
      jobInterval: previousWorkOrder.config.maxServicePeriod,
    });

    if (checklistItems && checklistItems.length > 0) {
      newWorkOrder.checklistItems = checklistItems.map((configItem) => {
        const checklist = new WorkOrderChecklist();
        checklist.description = configItem.description;
        checklist.remarks = '';
        return checklist;
      });
    }

    return await manager.save(newWorkOrder);
  }

  convertServicePeriodToMomentUnit(maxServicePeriod: string): moment.Duration {
    const periodMap: Record<string, moment.unitOfTime.DurationConstructor> = {
      D: 'days',
      W: 'weeks',
      M: 'months',
      Y: 'years',
    };

    // Extract unit and value
    const unit = maxServicePeriod.slice(-1).toUpperCase();
    const value = parseInt(maxServicePeriod.slice(0, -1), 10);

    if (!periodMap[unit] || isNaN(value)) {
      throw new Error(`Invalid service period format: '${maxServicePeriod}'`);
    }

    // Return the duration correctly formatted for Moment.js
    return moment.duration(value, periodMap[unit]);
  }

  calculateNextDueDate(baseDate: Date, maxServicePeriod: string): Date {
    try {
      const duration = this.convertServicePeriodToMomentUnit(maxServicePeriod);
      return moment(baseDate).add(duration).toDate();
    } catch (error) {
      console.error(`Error calculating next due date: ${error.message}`);
      throw new Error('Failed to calculate next due date');
    }
  }

  async consumeSpares(
    jobId: string,
    spares: SpareConsumptionDto[],
  ): Promise<WorkOrder> {
    const workOrder = await this.workOrderRepository.findOne({
      where: { jobId },
      relations: ['consumedSpares', 'component'],
    });

    if (!workOrder) {
      throw new NotFoundException(`WorkOrder with ID ${jobId} not found.`);
    }

    for (const spare of spares) {
      const existingSpare = await this.spareRepository.findOne({
        where: { id: spare.id },
      });

      if (!existingSpare) {
        throw new NotFoundException(`Spare with ID ${spare.id} not found.`);
      }

      if (spare.quantityUsed > existingSpare.rob) {
        throw new BadRequestException(
          `Insufficient ROB for Spare ID ${spare.id}. Available: ${existingSpare.rob}, Requested: ${spare.quantityUsed}`,
        );
      }

      const newWorkOrderSpare = this.workOrderSpareRepository.create({
        workOrder,
        spare: existingSpare,
        quantityUsed: spare.quantityUsed,
        remarks: spare.remarks || '',
        jobId: workOrder.jobId, // Attach jobId automatically
      });

      await this.workOrderSpareRepository.save(newWorkOrderSpare);

      // Adjust inventory
      existingSpare.rob -= spare.quantityUsed;
      await this.spareRepository.save(existingSpare);
    }

    return await this.workOrderRepository.findOne({
      where: { jobId },
      relations: ['consumedSpares', 'consumedSpares.spare'],
    });
  }

  async updateWorkOrder(
    jobId: string,
    updateWorkOrderDto: UpdateWorkOrderDto,
  ): Promise<WorkOrder> {
    return await this.dataSource.transaction(async (manager) => {
      const workOrder = await manager.findOne(WorkOrder, {
        where: { jobId },
        relations: ['checklistItems', 'consumedSpares'],
      });

      if (!workOrder) {
        throw new NotFoundException(
          `Work order with jobId ${jobId} not found.`,
        );
      }
      const {
        checklistItems,
        consumedSpares,
        ...workOrderUpdates // Exclude relations
      } = updateWorkOrderDto;

      // Update main work order fields
      manager.merge(WorkOrder, workOrder, workOrderUpdates);
      await manager.save(workOrder);

      // Update checklist items
      if (Array.isArray(checklistItems)) {
        await this.updateChecklists(workOrder, checklistItems, manager);
      }

      // Update consumed spares
      if (Array.isArray(consumedSpares)) {
        await this.updateConsumedSpares(workOrder, consumedSpares, manager);
      }

      return workOrder;
    });
  }

  private async updateChecklists(
    workOrder: WorkOrder,
    checklistItems: UpdateChecklistDto[],
    manager: EntityManager,
  ) {
    const existingChecklists = await manager.find(WorkOrderChecklist, {
      where: { workOrder: { id: workOrder.id } },
    });

    const updatedChecklists = (checklistItems || []).map((item) => {
      const existing = existingChecklists.find((c) => c.id === item.id);
      if (existing) {
        manager.merge(WorkOrderChecklist, existing, item);
        return existing;
      }
      return manager.create(WorkOrderChecklist, { ...item, workOrder });
    });

    await manager.save(updatedChecklists);
  }

  private async updateConsumedSpares(
    workOrder: WorkOrder,
    consumedSpares: UpdateWorkOrderSpareDto[],
    manager: EntityManager,
  ) {
    const existingSpares = await manager.find(WorkOrderSpareEntity, {
      where: { workOrder: { id: workOrder.id } },
    });

    for (const spare of consumedSpares) {
      if (
        !spare.quantityUsed ||
        isNaN(spare.quantityUsed) ||
        spare.quantityUsed <= 0
      ) {
        throw new BadRequestException(
          `Invalid quantity used for spare ID ${spare.spareId}.`,
        );
      }
      const existingSpare = existingSpares.find(
        (s) => s.spare.id === spare.spareId,
      );

      if (existingSpare) {
        existingSpare.quantityUsed = spare.quantityUsed;
        existingSpare.remarks = spare.remarks;
        await manager.save(existingSpare);
      } else {
        const spareEntity = await manager.findOne(SpareEntity, {
          where: { id: spare.spareId },
        });

        if (!spareEntity || spareEntity.rob < spare.quantityUsed) {
          throw new BadRequestException(
            `Invalid spare or insufficient stock for spare ID ${spare.spareId}.`,
          );
        }

        const newSpare = manager.create(WorkOrderSpareEntity, {
          workOrder,
          spare: spareEntity,
          quantityUsed: spare.quantityUsed,
          remarks: spare.remarks,
          jobId: workOrder.jobId,
        });
        await manager.save(newSpare);

        // Update the spare ROB
        spareEntity.rob -= spare.quantityUsed;
        await manager.save(spareEntity);

        const spareTransaction = manager.create(SpareTransaction, {
          spare: spareEntity,
          reason: TransactionReason.CONSUME,
          quantity: spare.quantityUsed,
          remark: `Consumed in Work Order: ${workOrder.jobId}`,
          updatedBy: workOrder.responsibleRank || 'CE', // Or relevant user info
        });

        await manager.save(spareTransaction);
      }
    }
  }

  async createWorkOrdersFromConfig(): Promise<void> {
    // Fetch all active work order configs
    const workOrderConfigs = await this.workOrderConfigRepository.find({
      where: { disabled: false },
      relations: ['component', 'checklistItems', 'ship'],
    });

    if (!workOrderConfigs.length) {
      console.log('No active WorkOrderConfigs found.');
      return;
    }

    // Loop through each config and create corresponding work orders
    for (const config of workOrderConfigs) {
      const newWorkOrder = new WorkOrder();

      // Assign core properties
      newWorkOrder.jobId = generateJobId(config.ship.code, config.jobId);
      newWorkOrder.title = config.description;
      newWorkOrder.status = 'inwindow';
      newWorkOrder.component = config.component;
      newWorkOrder.config = config;
      newWorkOrder.ship = config.ship;
      newWorkOrder.jobDescription = config.jobDescription;
      newWorkOrder.plannedCost = config.plannedCost;
      newWorkOrder.responsibleRank = config.responsibleRank;
      newWorkOrder.outOfTurn = false;
      newWorkOrder.isDefect = config.isDefect;
      newWorkOrder.raRequired = config.raRequired;
      newWorkOrder.ptwRequired = config.ptwRequired;

      // Assign Counter-based Values
      if (config.collectRunHours) {
        newWorkOrder.counterAtCreation = 0; // Default counter value
        newWorkOrder.dueCounterAtNext = config.maxRunHoursToService;
      }

      // Assign Periodic-based Values
      if (config.reminderUnit !== 'H') {
        const nextDueDate = this.calculateNextDueDate(
          new Date(),
          config.maxServicePeriod,
        );
        newWorkOrder.dueDate = nextDueDate;
      }

      // Generate Checklists
      newWorkOrder.checklistItems = config.checklistItems.map((item) => {
        const checklist = new WorkOrderChecklist();
        checklist.description = item.description;
        checklist.remarks = '';
        return checklist;
      });

      // Save the work order
      await this.workOrderRepository.save(newWorkOrder);
      console.log(`Created WorkOrder for JobID: ${newWorkOrder.jobId}`);
    }

    console.log('Work order creation from configs completed.');
    console.log('DOne!!!🚀');
  }
}
