export const allowedWorkOrderSortFields: Record<string, string> = {
  dueDate: 'workOrder.dueDate',
  createdAt: 'workOrder.createdAt',
  title: 'workOrder.title',
  responsibleRank: 'workOrder.responsibleRank',
  lastDoneDate: 'workOrder.lastDoneDate',
};
