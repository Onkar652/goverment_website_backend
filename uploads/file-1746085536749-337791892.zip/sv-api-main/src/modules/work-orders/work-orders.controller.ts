import {
  BadRequestException,
  Body,
  Controller,
  Get,
  HttpCode,
  HttpException,
  HttpStatus,
  NotFoundException,
  Param,
  ParseIntPipe,
  Post,
  Res,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { FileFieldsInterceptor } from '@nestjs/platform-express';
import {
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiParam,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { Response } from 'express';
import { WorkOrder } from 'src/entities/shipActions/work-order.entity';
import { WorkOrderConfig } from 'src/entities/shipActions/workOrder-config.entity';
import { CreateWorkOrderConfigBodyDto } from './dto/create-wo-config.dto';
import {
  GetAllWorkOrdersDto,
  GetWorkOrdersDto,
  WorkOrderIdQueryDto,
  WorkOrderQueryDto,
} from './dto/get-work-order.dto';
import {
  DeleteFilesDto,
  UploadWorkOrderDocumentsDto,
} from './dto/update-wo-docs.dto';
import { UpdateWorkOrderDto } from './dto/update-work-order.dto';
import { WorkOrdersService } from './work-orders.service';

@ApiTags('work-order')
@Controller('work-orders')
export class WorkOrdersController {
  constructor(private readonly workOrdersService: WorkOrdersService) {}

  @Post('/system/insert-wo')
  @ApiOperation({ summary: 'Insert work order configurations from CSV data' })
  @ApiResponse({
    status: 201,
    description: 'Work Order Configurations inserted successfully',
  })
  @ApiResponse({ status: 400, description: 'Invalid request data' })
  async insertWorkOrderConfig(@Body() body: CreateWorkOrderConfigBodyDto) {
    const { shipId } = body;

    if (!shipId) {
      throw new BadRequestException('shipId is required');
    }

    await this.workOrdersService.insertWorkOrderConfigFromCsv(shipId);
    return { message: 'Work Order Configurations inserted successfully' };
  }
  @Post('/system/update-wo')
  @ApiOperation({ summary: 'Update work order configurations from CSV data' })
  @ApiResponse({
    status: 201,
    description: 'Work Order Configurations inserted successfully',
  })
  @ApiResponse({ status: 400, description: 'Invalid request data' })
  async updateWorkOrderConfig() {
    return await this.workOrdersService.findDistinctComponentsCollectingRunHours();
    return { message: 'Work Order Configurations inserted successfully' };
  }

  @Post('get-wo-config')
  @ApiOperation({ summary: 'Retrieve work orders by main part ID and ship ID' })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved work orders',
    type: [WorkOrderConfig],
  })
  @ApiResponse({ status: 400, description: 'Bad request' })
  @ApiResponse({ status: 500, description: 'Internal server error' })
  @ApiBody({ type: GetWorkOrdersDto })
  async getWorkOrdersByMainPartAndShip(
    @Body() getWorkOrdersDto: GetWorkOrdersDto,
  ): Promise<WorkOrderConfig[]> {
    try {
      const { shipId, mainPartId } = getWorkOrdersDto;
      const workOrders =
        await this.workOrdersService.findWorkOrdersByMainPartAndShip(
          mainPartId,
          shipId,
        );
      if (!workOrders.length) {
        throw new HttpException('No work orders found', HttpStatus.NOT_FOUND);
      }
      return workOrders;
    } catch (error) {
      throw new HttpException(
        'Failed to retrieve work orders',
        HttpStatus.INTERNAL_SERVER_ERROR,
        {
          cause: error,
        },
      );
    }
  }

  @Post('get-all-wo-configs')
  @ApiOperation({
    summary:
      'Retrieve all work order configurations with optional ship ID filter',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved work order configurations',
    type: [WorkOrderConfig],
  })
  @ApiResponse({ status: 400, description: 'Bad request' })
  @ApiResponse({ status: 500, description: 'Internal server error' })
  @ApiBody({
    description: 'Optional ship ID filter',
    type: GetAllWorkOrdersDto,
  })
  async getAllWorkOrderConfigs(
    @Body() getAllWorkOrdersDto: GetAllWorkOrdersDto,
  ): Promise<WorkOrderConfig[]> {
    try {
      const { shipId } = getAllWorkOrdersDto; // shipId is optional
      const workOrders =
        await this.workOrdersService.findAllWorkOrderConfigs(shipId);
      if (!workOrders.length) {
        throw new HttpException('No work orders found', HttpStatus.NOT_FOUND);
      }
      return workOrders;
    } catch (error) {
      throw new HttpException(
        'Failed to retrieve work order configurations',
        HttpStatus.INTERNAL_SERVER_ERROR,
        {
          cause: error,
        },
      );
    }
  }

  @Get('/by-ship/:shipId')
  @ApiOperation({ summary: 'Get all work orders by ship ID' }) // Describing the endpoint
  @ApiParam({ name: 'shipId', description: 'ID of the ship', type: Number }) // Describing parameters
  @ApiResponse({
    status: 200,
    description: 'Successful retrieval of work orders',
    type: [WorkOrder],
  })
  @ApiResponse({ status: 404, description: 'Ship not found' })
  async getWorkOrdersByShip(
    @Param('shipId', ParseIntPipe) shipId: number,
  ): Promise<WorkOrder[]> {
    return await this.workOrdersService.findAllWorkOrdersByShipId(shipId);
  }

  @Post('/:id/documents')
  @UseInterceptors(
    FileFieldsInterceptor([
      { name: 'ptwDocument', maxCount: 1 },
      { name: 'raDocument', maxCount: 1 },
      { name: 'otherDocuments', maxCount: 10 },
      { name: 'jobPhotos', maxCount: 10 },
    ]),
  )
  @ApiOperation({
    summary: 'Upload documents for a Work Order',
    description:
      'Allows uploading of PTW documents, RA documents, other documents, and job photos for a specified work order.',
  })
  @ApiParam({ name: 'id', description: 'Work Order ID', type: Number })
  @ApiConsumes('multipart/form-data')
  @ApiBody({ type: UploadWorkOrderDocumentsDto })
  @ApiResponse({ status: 200, description: 'Documents uploaded successfully' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async uploadWorkOrderDocuments(
    @Param('id') workOrderId: number,
    @UploadedFiles()
    files: {
      ptwDocument?: Express.Multer.File[];
      raDocument?: Express.Multer.File[];
      otherDocuments?: Express.Multer.File[];
      jobPhotos?: Express.Multer.File[];
    },
  ): Promise<any> {
    return this.workOrdersService.handleDocumentUpload(workOrderId, files);
  }

  // @Post('/update/:id')
  // @ApiOperation({
  //   summary: 'Update a Work Order',
  //   description:
  //     'Updates a work order with partial data. The ID of the work order must be provided.',
  // })
  // @ApiParam({
  //   name: 'id',
  //   type: Number,
  //   description: 'The ID of the work order to update',
  //   required: true,
  // })
  // @ApiBody({
  //   type: UpdateWorkOrderDto,
  //   description: 'The partial data to update the work order with',
  // })
  // @ApiResponse({
  //   status: 200,
  //   description: 'The updated work order',
  //   type: WorkOrder,
  // })
  // @ApiResponse({ status: 404, description: 'Work Order not found' })
  // async updateWorkOrderById(
  //   @Param('id') id: number,
  //   @Body() updateWorkOrderDto: UpdateWorkOrderDto,
  // ) {
  //   const updatedWorkOrder = await this.workOrdersService.update(
  //     id,
  //     updateWorkOrderDto,
  //   );
  //   if (!updatedWorkOrder) {
  //     throw new NotFoundException(`Work Order with ID "${id}" not found`);
  //   }
  //   return updatedWorkOrder;
  // }

  @Post('/update')
  @ApiOperation({ summary: 'Update a work order' })
  @ApiResponse({ status: 200, description: 'Work order updated successfully' })
  @ApiResponse({ status: 404, description: 'Work order not found' })
  @ApiBody({ type: UpdateWorkOrderDto })
  async updateWorkOrder(
    @Body() updateWorkOrderDto: UpdateWorkOrderDto,
  ): Promise<WorkOrder> {
    if (!updateWorkOrderDto.jobId) {
      throw new BadRequestException('Job ID is required.');
    }
    return await this.workOrdersService.updateWorkOrder(
      updateWorkOrderDto.jobId,
      updateWorkOrderDto,
    );
  }

  @Get('/wo-file/:id')
  async getFile(@Param('id') id: string, @Res() res: Response) {
    const file = await this.workOrdersService.getFileById(id);
    if (!file) {
      res.status(404).send('File not found');
      return;
    }
    res.setHeader('Content-Type', file.mimeType);
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${file.fileName}"`,
    );
    res.send(file.data);
  }

  @Post('/by-id')
  @ApiOperation({
    summary:
      'Retrieve a work order by ID or Job ID within a specific ship using POST',
  })
  @ApiResponse({
    status: 200,
    description: 'The found work order details',
    type: WorkOrder,
  })
  @ApiResponse({
    status: 404,
    description: 'No work order found with the provided criteria',
  })
  @ApiBody({
    type: WorkOrderIdQueryDto,
  })
  async getWorkOrderByIdOrJobId(
    @Body() queryDto: WorkOrderIdQueryDto,
    @Res() res: Response,
  ): Promise<void> {
    const { id, jobId, shipId } = queryDto;
    if (!id && !jobId) {
      throw new NotFoundException(
        `You must provide either a work order ID or a job ID.`,
      );
    }

    const workOrder = await this.workOrdersService.findWorkOrderByIdOrJobId(
      id,
      jobId,
      shipId,
    );
    if (!workOrder) {
      throw new NotFoundException(
        `No work order found with ID ${id || jobId} for ship ID ${shipId}`,
      );
    }
    res.send(workOrder);
  }

  @Post('/by-status')
  @ApiOperation({
    summary: 'Retrieve work orders by status with pagination and search',
  })
  @ApiResponse({
    status: 200,
    description: 'List of work orders matching the criteria',
    type: [WorkOrder],
  })
  @ApiResponse({
    status: 404,
    description: 'No work orders found matching the provided criteria',
  })
  @ApiBody({
    type: WorkOrderQueryDto,
  })
  async getWorkOrdersByStatus(@Body() queryDto: WorkOrderQueryDto) {
    return await this.workOrdersService.findWorkOrdersByStatus(queryDto);
  }

  @Post('/wo-file/delete')
  @ApiOperation({ summary: 'Delete a file by ID with ship validation' })
  @ApiResponse({ status: 200, description: 'File deleted successfully' })
  @ApiResponse({ status: 404, description: 'File not found or invalid ship' })
  async deleteFile(
    @Body() deleteFileDto: DeleteFilesDto,
  ): Promise<{ message: string }> {
    try {
      await this.workOrdersService.deleteFiles(deleteFileDto);
      return { message: 'Files deleted successfully' };
    } catch (error) {
      throw new NotFoundException(error.message);
    }
  }

  @Post('approve')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Approve and complete a work order' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Work order approved and next work order created.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Work order not found.',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid request data.',
  })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        completedCounter: {
          type: 'number',
          description: 'Counter value at work order completion (if applicable)',
        },
        jobId: {
          type: 'string',
          description: 'unique job ID of the work order to approve',
        },
      },
    },
  })
  async approveWorkOrder(
    @Body('jobId') jobId: string,
    @Body('completedCounter') completedCounter: number | null,
  ) {
    const approvedWorkOrder = await this.workOrdersService.approveWorkOrder(
      jobId,
      completedCounter,
    );
    return {
      message: 'Work order approved and next work order created successfully.',
      approvedWorkOrder,
    };
  }

  // @Post('work-order-checklist')
  // @ApiOperation({
  //   summary: 'Upload an Excel file to import work order configurations',
  // })
  // @ApiConsumes('multipart/form-data')
  // @ApiResponse({
  //   status: 200,
  //   description: 'File successfully processed and data imported.',
  // })
  // @ApiResponse({
  //   status: 400,
  //   description: 'Invalid file or processing error.',
  // })
  // @ApiBody({
  //   description: 'Excel file to upload',
  //   schema: {
  //     type: 'object',
  //     properties: {
  //       file: {
  //         type: 'string',
  //         format: 'binary',
  //       },
  //     },
  //   },
  // })
  // @UseInterceptors(FileInterceptor('file'))
  // async importWorkOrderConfig(
  //   @UploadedFile() file: Express.Multer.File,
  // ): Promise<string> {
  //   if (!file) {
  //     throw new HttpException('No file uploaded', HttpStatus.BAD_REQUEST);
  //   }

  //   try {
  //     this.workOrdersService.importDataFromExcel(file.buffer);
  //     return 'File successfully processed and data imported.';
  //   } catch (error) {
  //     console.error('Error processing file:', error);
  //     // throw new HttpException(
  //     //   'Failed to process the file. Please check the file format and content.',
  //     //   HttpStatus.INTERNAL_SERVER_ERROR,
  //     // );
  //   }
  // }

  // @Post('create-from-config')
  // @HttpCode(HttpStatus.CREATED)
  // async createWorkOrdersFromConfig() {
  //   this.workOrdersService.createWorkOrdersFromConfig();
  //   return { message: 'Work orders created successfully.' };
  // }
}
