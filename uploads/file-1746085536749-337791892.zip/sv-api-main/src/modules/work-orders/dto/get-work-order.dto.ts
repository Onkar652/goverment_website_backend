import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  IsNumber,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsIn,
} from 'class-validator';

export class GetWorkOrdersDto {
  @ApiProperty({ description: 'Unique identifier of the ship', example: 1 })
  @IsNumber()
  @IsNotEmpty()
  shipId: number;

  @ApiProperty({
    description: 'Unique identifier of the main part',
    example: 2,
  })
  @IsNumber()
  @IsNotEmpty()
  mainPartId: number;
}

export class GetAllWorkOrdersDto {
  @ApiProperty({ description: 'Unique identifier of the ship', example: 1 })
  @IsNumber()
  @IsNotEmpty()
  shipId: number;
}

export class WorkOrderIdQueryDto {
  @ApiProperty({
    description: 'The ID of the ship',
    example: 1,
    required: true,
    type: Number,
  })
  @IsNumber()
  shipId: number;

  @ApiProperty({
    description: 'The ID of the work order',
    example: 100,
    required: false,
    type: Number,
  })
  @IsNumber()
  @IsOptional()
  id?: number;

  @ApiProperty({
    description: 'The Job ID of the work order',
    example: 'JOB1234',
    required: false,
    type: String,
  })
  @IsString()
  @IsOptional()
  jobId?: string;
}

export class WorkOrderStatusQueryDto {
  @ApiProperty({
    description: 'The ID of the ship',
    example: 1,
    required: true,
    type: Number,
  })
  @IsNumber()
  shipId: number;

  @ApiProperty({
    description: 'The status of the work order',
    example: 100,
    required: true,
    type: String,
  })
  @Transform(({ value }) => value?.toLowerCase())
  @IsString()
  status: string;
}

export class WorkOrderQueryDto {
  @ApiProperty({
    description: 'The ID of the ship',
    example: 1,
    required: true,
    type: Number,
  })
  @IsNumber()
  shipId: number;

  @ApiProperty({
    description: 'The status of the work order (optional for "All" tab)',
    example: 'open',
    required: false,
    type: String,
  })
  @IsOptional()
  @Transform(({ value }) => value?.toLowerCase())
  @IsString()
  status?: string;

  @ApiProperty({
    description: 'The job title to search (optional)',
    example: 'engine check',
    required: false,
    type: String,
  })
  @IsOptional()
  @IsString()
  search?: string;

  @ApiProperty({
    description: 'The page number (default 1)',
    example: 1,
    required: false,
    type: Number,
  })
  @IsOptional()
  @IsNumber()
  page?: number;

  @ApiProperty({
    description: 'The number of items per page (default 10)',
    example: 10,
    required: false,
    type: Number,
  })
  @IsOptional()
  @IsNumber()
  limit?: number;

  @ApiProperty({
    description: 'Unique identifier of the main part',
    example: 2,
  })
  @IsOptional()
  @IsNumber()
  mainPartId: number;

  @ApiPropertyOptional({
    description: 'Field to sort by. Allowed values: dueDate, createdAt, title',
    example: 'dueDate',
  })
  @IsOptional()
  @IsString()
  sortField?: string;

  @ApiPropertyOptional({
    description: 'Sort order: ASC or DESC',
    example: 'ASC',
  })
  @IsOptional()
  @IsString()
  @IsIn(['ASC', 'DESC', 'asc', 'desc'])
  sortOrder?: string;
}
