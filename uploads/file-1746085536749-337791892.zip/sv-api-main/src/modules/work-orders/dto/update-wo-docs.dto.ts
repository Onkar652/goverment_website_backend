import { ApiProperty } from '@nestjs/swagger';
import { ArrayNotEmpty, IsArray, IsNumber, IsUUID } from 'class-validator';

export class UploadWorkOrderDocumentsDto {
  @ApiProperty({
    type: 'string',
    format: 'binary',
    required: false,
    description: 'PTW Document',
  })
  ptwDocument?: any;

  @ApiProperty({
    type: 'string',
    format: 'binary',
    required: false,
    description: 'RA Document',
  })
  raDocument?: any;

  @ApiProperty({
    type: 'array',
    items: { type: 'string', format: 'binary' },
    required: false,
    description: 'Other Supporting Documents',
  })
  otherDocuments?: any[];

  @ApiProperty({
    type: 'array',
    items: { type: 'string', format: 'binary' },
    required: false,
    description: 'Job-related Photos',
  })
  jobPhotos?: any[];
}

export class DeleteFilesDto {
  @ApiProperty({
    description: 'An array of UUIDs of the files to be deleted',
    example: [
      '123e4567-e89b-12d3-a456-426614174000',
      '123e4567-e89b-12d3-a456-426614174001',
    ],
    type: [String],
  })
  @IsArray()
  @ArrayNotEmpty()
  @IsUUID('4', { each: true })
  fileIds: string[];

  @ApiProperty({
    description:
      'The ID of the ship associated with the work order of the file',
    example: 1,
    type: Number,
  })
  @IsNumber()
  shipId: number;
}
