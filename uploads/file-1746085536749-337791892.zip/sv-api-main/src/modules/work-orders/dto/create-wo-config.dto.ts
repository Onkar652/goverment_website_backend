import { ApiProperty } from '@nestjs/swagger';
import { IsNumber } from 'class-validator';

export class CreateWorkOrderConfigBodyDto {
  @ApiProperty({ description: 'Ship ID to filter components by', example: 123 })
  @IsNumber()
  shipId: number;
}
