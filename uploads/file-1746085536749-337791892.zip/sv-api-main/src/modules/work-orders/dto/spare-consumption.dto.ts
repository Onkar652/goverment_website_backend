import { ApiProperty } from '@nestjs/swagger';

export class ConsumeSparesDto {
  @ApiProperty({ description: 'Work Order ID', example: 1 })
  workOrderId: number;

  @ApiProperty({
    description: 'List of spares to consume',
    type: () => [SpareConsumptionDto],
  })
  spares: SpareConsumptionDto[];
}

export class SpareConsumptionDto {
  @ApiProperty({ description: 'Spare ID', example: 1 })
  id: number;

  @ApiProperty({ description: 'Quantity used', example: 5 })
  quantityUsed: number;

  @ApiProperty({ description: 'Remarks (optional)', required: false })
  remarks?: string;
}
