import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsString,
  IsOptional,
  IsBoolean,
  IsDate,
  IsNumber,
  IsArray,
  IsEnum,
} from 'class-validator';
import { UserRanks } from 'src/utils/models/common.types';

export class UpdateChecklistDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  description: string;

  @ApiProperty()
  result: string;

  @ApiProperty()
  remarks: string;
}

export class UpdateWorkOrderSpareDto {
  @ApiProperty()
  spareId: number;

  @ApiProperty()
  quantityUsed: number;

  @ApiProperty({ required: false })
  remarks?: string;
}
export class UpdateWorkOrderDto {
  @ApiProperty({
    description: 'Unique Job ID of the Work Order',
    example: 'JOB123',
    required: true,
  })
  @IsString()
  jobId: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  title?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  jobDescription?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  feedback?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  status?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  conditionBeforeOh?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  disabled?: boolean;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  manHours?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  workerCount?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  counterAtCreation?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  counterAtEnd?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  plannedCost?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  outOfTurn?: boolean;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  isDefect?: boolean;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsDate()
  @Type(() => Date)
  isDdefectCapturedOnefect?: Date;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  raRequired?: boolean;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  ptwRequired?: boolean;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  observation?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsEnum(UserRanks)
  responsibleRank?: UserRanks;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsEnum(UserRanks)
  jobDoneBy?: UserRanks;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsDate()
  @Type(() => Date)
  dueDate?: Date;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsDate()
  @Type(() => Date)
  lastDoneDate?: Date;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsDate()
  @Type(() => Date)
  startDate?: Date;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsDate()
  @Type(() => Date)
  finishedDate?: Date;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsDate()
  @Type(() => Date)
  approvedDate?: Date;

  @ApiProperty({ required: false, type: [UpdateChecklistDto] })
  @IsOptional()
  @IsArray()
  checklistItems?: UpdateChecklistDto[];

  @ApiProperty({ required: false, type: [UpdateWorkOrderSpareDto] })
  @IsOptional()
  @IsArray()
  consumedSpares?: UpdateWorkOrderSpareDto[];
}
