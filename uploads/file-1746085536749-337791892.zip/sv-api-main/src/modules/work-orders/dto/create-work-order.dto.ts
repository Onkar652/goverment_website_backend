import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsOptional,
  IsString,
  IsDate,
  IsNumber,
  IsBoolean,
  IsEnum,
} from 'class-validator';
import { UserRanks } from 'src/utils/models/common.types';

export class CreateWorkOrderDto {
  @IsOptional()
  @IsString()
  jobId?: string;

  @IsOptional()
  @IsString()
  title?: string;

  @IsOptional()
  @IsString()
  jobDescription?: string;

  @IsOptional()
  @IsString()
  feedback?: string;

  @IsOptional()
  @IsEnum(UserRanks)
  responsibleRank?: UserRanks;

  @IsOptional()
  @Transform(({ value }) => value?.toLowerCase())
  @IsString()
  status?: string;

  @IsOptional()
  @IsNumber()
  manHours?: number;

  @IsOptional()
  @IsNumber()
  workerCount?: number;

  @IsOptional()
  @IsBoolean()
  disabled?: boolean;

  @IsOptional()
  @Type(() => Date)
  @IsDate()
  dueDate?: Date;

  @IsOptional()
  @Type(() => Date)
  @IsDate()
  startDate?: Date;

  @IsOptional()
  @Type(() => Date)
  @IsDate()
  finishedDate?: Date;

  @IsOptional()
  @Type(() => Date)
  @IsDate()
  approvedDate?: Date;

  @IsOptional()
  @IsNumber()
  counterAtEnd: number;
}

export class CustomResponse {
  @ApiProperty()
  statusCode: number;

  @ApiProperty()
  message: string;

  // @ApiProperty({ type: [ShipWorkOrderDto] })
  // result: ShipWorkOrderDto[];
}
