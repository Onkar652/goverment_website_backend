import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Injectable,
  InternalServerErrorException,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { certificateList } from 'src/config-data/certifications/certification_list';
import { SurveyList } from 'src/config-data/certifications/survey_list';
import { CertificateCategoryEntity } from 'src/entities/certifications/certificate-category.entity';
import { PredefinedCertificatesEntity } from 'src/entities/certifications/certificate-list.entity';
import { CertificateSurveyEntity } from 'src/entities/certifications/certificate-survey.entity';
import { CertificateSurveyLinkEntity } from 'src/entities/certifications/certificate_survey_relation.entity';
import { CertificationEntity } from 'src/entities/certifications/certification.entity';
import { PredefinedSurveyEntity } from 'src/entities/certifications/survey_list.entity';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { CertificateStatus } from 'src/utils/models/common.types';
import { DataSource, In, Repository } from 'typeorm';
import { ShipValidationService } from '../common/ship-validation.service';
import { DeleteFilesDto } from '../work-orders/dto/update-wo-docs.dto';
import { CertificateSurveyDto } from './dto/certificate-surevy.dto';
import {
  CreateCertificateDto,
  CreateOrUpdateCertificateResponseDto,
} from './dto/create-certificate.dto';
import { UpdateCertificateStatusDto } from './dto/update-certification.dto';

@Injectable()
export class CertificationsService {
  private certificateMasterRepo: Repository<PredefinedCertificatesEntity>;
  private certificateRepository: Repository<CertificationEntity>;
  private surveyRepository: Repository<CertificateSurveyEntity>;
  private fileStorageRepository: Repository<FileStorageEntity>;
  private readonly logger = new Logger(CertificationsService.name);
  constructor(
    private readonly dataSource: DataSource,
    private shipValidationService: ShipValidationService,
  ) {
    this.certificateMasterRepo = this.dataSource.getRepository(
      PredefinedCertificatesEntity,
    );
    this.certificateRepository =
      this.dataSource.getRepository(CertificationEntity);
    this.surveyRepository = this.dataSource.getRepository(
      CertificateSurveyEntity,
    );
    this.fileStorageRepository =
      this.dataSource.getRepository(FileStorageEntity);
  }
  async seedData() {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    const categories = new Map<string, CertificateCategoryEntity>();
    const surveysMap = new Map<string, PredefinedSurveyEntity>();

    try {
      for (const surveyName of SurveyList) {
        const survey = new PredefinedSurveyEntity();
        survey.name = surveyName;
        await queryRunner.manager.save(survey);
        surveysMap.set(surveyName, survey);
      }
      for (const item of certificateList) {
        let category = categories.get(item['Certificate Category']);
        if (!category) {
          category = new CertificateCategoryEntity();
          category.name = item['Certificate Category'];
          await queryRunner.manager.save(category);
          categories.set(item['Certificate Category'], category);
        }

        const predefinedCertificate = new PredefinedCertificatesEntity();
        predefinedCertificate.adminSiNo = item['Admin SI. No.'];
        predefinedCertificate.name = item['Certificate'];
        predefinedCertificate.issuingAuthority =
          item['Issuing Authority'] || '';
        predefinedCertificate.category = category;

        const savedCertificate = await queryRunner.manager.save(
          predefinedCertificate,
        );

        for (const surveyName of SurveyList) {
          // Assuming all surveys for simplification
          const survey = surveysMap.get(surveyName);
          const certificateSurvey = new CertificateSurveyLinkEntity();
          certificateSurvey.certificate = savedCertificate;
          certificateSurvey.survey = survey;
          await queryRunner.manager.save(certificateSurvey);
        }
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      console.error('Error occurred during data seeding:', error);
      await queryRunner.rollbackTransaction();
      throw error; // Rethrow the error after rollback
    } finally {
      await queryRunner.release();
    }
  }

  async getMasterData(): Promise<PredefinedCertificatesEntity[]> {
    try {
      return this.certificateMasterRepo.find({
        relations: ['category', 'surveys', 'surveys.survey'], // Ensure to adjust this based on your actual relation paths
      });
    } catch (error) {
      this.logger.error('Error fetching certificates', error.stack);
      throw new HttpException(
        'Internal Server Error',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  async createCertificate(
    createDto: CreateCertificateDto,
  ): Promise<CertificationEntity> {
    const { shipId, surveys, ...certificateDetails } = createDto;
    const ship = await this.shipValidationService.getShipById(shipId);

    const newCertificate = this.certificateRepository.create({
      ...certificateDetails,
      ship,
    });

    if (surveys && surveys.length > 0) {
      newCertificate.surveys = await this.buildSurveys(newCertificate, surveys);
    }

    return await this.certificateRepository.save(newCertificate);
  }

  // Update existing certificate
  async updateCertificate(
    id: number,
    updateDto: CreateCertificateDto,
  ): Promise<CertificationEntity> {
    const existingCertificate = await this.certificateRepository.findOne({
      where: { id },
      relations: ['surveys', 'ship'],
    });
    if (!existingCertificate) {
      throw new NotFoundException(`Certificate with ID ${id} not found`);
    }

    const { shipId, surveys, ...certificateDetails } = updateDto;
    await this.shipValidationService.getShipById(shipId);
    if (shipId !== existingCertificate.ship.id) {
      throw new BadRequestException(
        `Ship id and certificate's ship does not match`,
      );
    }

    // Update basic details
    Object.assign(existingCertificate, certificateDetails);

    if (surveys && surveys.length > 0) {
      existingCertificate.surveys = await this.buildSurveys(
        existingCertificate,
        surveys,
      );
    }

    return await this.certificateRepository.save(existingCertificate);
  }

  async createOrUpdateCertificate(
    createDto: CreateCertificateDto,
  ): Promise<CreateOrUpdateCertificateResponseDto> {
    const { id, shipId, certificateName, surveys, ...certificateDetails } =
      createDto;

    // Validate the ship
    const ship = await this.shipValidationService.getShipById(shipId);
    if (!ship) {
      throw new NotFoundException(`Ship with ID ${shipId} not found`);
    }

    let certificate: CertificationEntity | undefined;

    if (id) {
      // Find by id for update
      certificate = await this.certificateRepository.findOne({
        where: { id, ship },
        relations: ['ship', 'surveys'],
      });
      if (!certificate) {
        throw new NotFoundException(
          `Certificate with ID ${id} not found for ship ${shipId}`,
        );
      }
      // Update the certificate details
      Object.assign(certificate, certificateDetails);
    } else {
      // Find by certificateName for new or replacement
      certificate = await this.certificateRepository.findOne({
        where: { certificateName, ship },
        relations: ['ship', 'surveys'],
      });
    }

    // Check if a certificate with the same name already exists for the ship
    // let certificate = await this.certificateRepository.findOne({
    //   where: { certificateName, ship },
    //   relations: ['ship', 'surveys'],
    // });

    if (certificate) {
      // Update the existing certificate with new details
      Object.assign(certificate, {
        ...certificateDetails,
        ship,
      });
    } else {
      // Create a new certificate if it does not exist
      certificate = this.certificateRepository.create({
        certificateName,
        ...certificateDetails,
        ship,
        disabled: false,
      });
    }

    const savedCertificate = await this.certificateRepository.save(certificate);
    let surveySaveSuccess = true;
    let message = 'Certificate saved successfully.';
    if (surveys && surveys.length > 0) {
      try {
        const savedSurveys = await this.buildSurveys(savedCertificate, surveys);

        // Remove the circular reference by setting each survey's `certificate` to null
        savedSurveys.forEach((survey) => {
          survey.certificate = null;
        });
        savedCertificate.surveys = savedSurveys;
        message += ' Surveys saved successfully.';
      } catch (error) {
        surveySaveSuccess = false;
        message += ' However, there was an error saving the surveys.';
        console.error('Error saving surveys:', error);
      }
    }

    // Return the result with a success flag for surveys and a message
    return {
      certificate: savedCertificate,
      surveySaveSuccess,
      message,
    };
  }

  // Helper method to build or update surveys
  private async buildSurveys(
    certificate: CertificationEntity,
    surveys: CertificateSurveyDto[],
  ): Promise<CertificateSurveyEntity[]> {
    const existingSurveys = await this.surveyRepository.find({
      where: { certificate: { id: certificate.id } },
    });

    // Find surveys to delete (those not present in the input)
    const inputSurveyIds = surveys.filter((s) => s.id).map((s) => s.id);
    const surveysToDelete = existingSurveys.filter(
      (existing) => !inputSurveyIds.includes(existing.id),
    );

    // Delete surveys that are no longer in the input
    if (surveysToDelete.length > 0) {
      await this.surveyRepository.remove(surveysToDelete);
    }
    return await Promise.all(
      surveys.map(async (surveyDto) => {
        let survey: CertificateSurveyEntity;
        if (surveyDto.id) {
          survey = await this.surveyRepository.findOne({
            where: { id: surveyDto.id },
          });
          if (!survey) {
            throw new NotFoundException(
              `Survey with ID ${surveyDto.id} not found`,
            );
          }
        } else {
          survey = new CertificateSurveyEntity();
        }

        Object.assign(survey, surveyDto);
        survey.certificate = certificate;

        return this.surveyRepository.save(survey);
      }),
    );
  }

  async uploadCertificateFiles(
    certificateId: number,
    files: Express.Multer.File[],
  ): Promise<FileStorageEntity[]> {
    const certificate = await this.certificateRepository.findOne({
      where: { id: certificateId },
    });
    if (!certificate) {
      throw new NotFoundException(
        `Certificate with ID ${certificateId} not found`,
      );
    }

    const fileEntities = files.map((file) => {
      const fileEntity = new FileStorageEntity();
      fileEntity.data = file.buffer;
      fileEntity.mimeType = file.mimetype;
      fileEntity.fileName = file.originalname;
      fileEntity.certificate = certificate;
      return fileEntity;
    });

    return await this.fileStorageRepository.save(fileEntities);
  }

  async uploadSurveyFiles(
    surveyId: number,
    files: Express.Multer.File[],
  ): Promise<FileStorageEntity[]> {
    const survey = await this.surveyRepository.findOne({
      where: { id: surveyId },
    });
    if (!survey) {
      throw new NotFoundException(`Survey with ID ${surveyId} not found`);
    }

    const fileEntities = files.map((file) => {
      const fileEntity = new FileStorageEntity();
      fileEntity.data = file.buffer;
      fileEntity.mimeType = file.mimetype;
      fileEntity.fileName = file.originalname;
      fileEntity.survey = survey;
      return fileEntity;
    });

    return await this.fileStorageRepository.save(fileEntities);
  }

  async deleteFiles(deleteFileDto: DeleteFilesDto): Promise<void> {
    const { fileIds, shipId } = deleteFileDto;

    if (!shipId || !fileIds.length) {
      throw new BadRequestException('Invalid params');
    }

    await this.shipValidationService.getShipById(shipId);

    // Retrieve the files and their relations
    const files = await this.fileStorageRepository.find({
      where: { id: In(fileIds) },
      relations: ['certificate', 'survey'],
    });

    if (files.length !== fileIds.length) {
      throw new NotFoundException('One or more files not found');
    }

    const queryRunner =
      this.fileStorageRepository.manager.connection.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      for (const file of files) {
        // Handle one-to-one or many-to-one relationships in certificates or surveys
        if (file.certificate) {
          // Remove file reference from certificate entity
          file.certificate.documents = file.certificate.documents.filter(
            (doc) => doc.id !== file.id,
          );
          await queryRunner.manager.save(file.certificate);
        }

        if (file.survey) {
          // Remove file reference from survey entity
          file.survey.documents = file.survey.documents.filter(
            (doc) => doc.id !== file.id,
          );
          await queryRunner.manager.save(file.survey);
        }

        // Remove the file entity
        await queryRunner.manager.remove(FileStorageEntity, file);
      }

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw new InternalServerErrorException(
        'Failed to delete files: ' + error.message,
      );
    } finally {
      await queryRunner.release();
    }
  }

  async replaceFile(
    fileId: string,
    newFile: Express.Multer.File,
  ): Promise<FileStorageEntity> {
    const file = await this.fileStorageRepository.findOne({
      where: { id: fileId },
    });
    if (!file) {
      throw new NotFoundException('File not found');
    }

    // Update the file with new content
    file.data = newFile.buffer;
    file.mimeType = newFile.mimetype;
    file.fileName = newFile.originalname;

    return await this.fileStorageRepository.save(file);
  }

  async getCertificatesByShip(shipId: number) {
    await this.shipValidationService.getShipById(shipId);
    try {
      const certificates = await this.certificateRepository
        .createQueryBuilder('certificate')
        .leftJoinAndSelect('certificate.ship', 'ship')
        .leftJoinAndSelect('certificate.surveys', 'survey')
        .leftJoin('certificate.documents', 'document')
        .addSelect(['document.id', 'document.mimeType', 'document.fileName'])
        .where('ship.id = :shipId', { shipId })
        .getMany();
      // Handle the case where there are no certificates found
      if (!certificates || certificates.length === 0) {
        console.log('[Certification-fetch] - No certificates found');
        return [];
      }

      return certificates;
    } catch (error) {
      if (error instanceof NotFoundException) {
        throw error;
      }

      // For any other errors, throw a generic internal server error
      throw new InternalServerErrorException(
        `An error occurred while fetching certificates for ship ID ${shipId}: ${error.message}`,
      );
    }
  }

  async updateCertificateStatus(
    id: number,
    updateStatusDto: UpdateCertificateStatusDto,
  ): Promise<CertificationEntity> {
    const { status } = updateStatusDto;
    const certificate = await this.certificateRepository.findOne({
      where: { id },
    });

    if (!certificate) {
      throw new NotFoundException(`Certificate with ID ${id} not found`);
    }

    certificate.status = status;
    return this.certificateRepository.save(certificate);
  }

  async getCertificatesByStatus(
    shipId: number,
    status?: CertificateStatus,
    sortField?: string,
    sortOrder?: string,
  ): Promise<CertificationEntity[]> {
    await this.shipValidationService.getShipById(shipId);
    const allowedSortFields: Record<string, string> = {
      issuedOn: 'certificate.issuedOn',
      expiryDate: 'certificate.expiryDate',
      createdOn: 'certificate.createdOn',
      certificateName: 'certificate.certificateName',
      type: 'certificate.type',
      status: 'certificate.status',
      // Add other allowed fields as needed.
    };

    let primarySortColumn = 'certificate.createdOn';
    let primarySortOrder: 'ASC' | 'DESC' = 'DESC';

    if (sortField && sortOrder) {
      const orderUpper = sortOrder.toUpperCase();
      if (
        allowedSortFields[sortField] &&
        (orderUpper === 'ASC' || orderUpper === 'DESC')
      ) {
        primarySortColumn = allowedSortFields[sortField];
        primarySortOrder = orderUpper as 'ASC' | 'DESC';
      }
    }
    const query = await this.certificateRepository
      .createQueryBuilder('certificate')
      .leftJoinAndSelect('certificate.ship', 'ship')
      .leftJoinAndSelect('certificate.surveys', 'survey')
      .leftJoin('certificate.documents', 'document')
      .leftJoin('survey.documents', 'surveyDocument')
      .addSelect(['document.id', 'document.mimeType', 'document.fileName'])
      .addSelect([
        'surveyDocument.id',
        'surveyDocument.mimeType',
        'surveyDocument.fileName',
      ])
      .where('ship.id = :shipId', { shipId });

    if (status) {
      query.andWhere('certificate.status = :status', { status });
    }
    query.orderBy(primarySortColumn, primarySortOrder);
    const certificates = await query.getMany();

    if (!certificates.length) {
      console.log('[Certification-fetch] - No certificates found');
      return [];
    }

    return certificates;
  }

  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT) // Run this task daily at midnight
  async updateCertificateStatuses(): Promise<void> {
    const currentDate = new Date();
    const threeMonthsFromNow = new Date();
    threeMonthsFromNow.setMonth(threeMonthsFromNow.getMonth() + 3);

    this.logger.log('Running scheduled task to update certificate statuses.');

    try {
      // Get certificates that are not yet expired or in-window
      const certificates = await this.certificateRepository.find({
        where: [
          { status: CertificateStatus.Approved },
          { status: CertificateStatus.InWindow },
          { status: CertificateStatus.Active },
        ],
      });

      for (const certificate of certificates) {
        if (certificate.expiryDate < currentDate) {
          certificate.status = CertificateStatus.Expired;
        } else if (
          certificate.expiryDate >= currentDate &&
          certificate.expiryDate <= threeMonthsFromNow
        ) {
          certificate.status = CertificateStatus.InWindow;
        }

        // Save the updated certificate
        await this.certificateRepository.save(certificate);
      }

      this.logger.log('Certificate statuses updated successfully.');
    } catch (error) {
      this.logger.error('Error updating certificate statuses:', error.message);
    }
  }
}
