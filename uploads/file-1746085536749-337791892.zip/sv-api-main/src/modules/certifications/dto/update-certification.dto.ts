import { PartialType } from '@nestjs/mapped-types';
import { CreateCertificateDto } from './create-certificate.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty } from 'class-validator';
import { CertificateStatus } from 'src/utils/models/common.types';

export class UpdateCertificationDto extends PartialType(CreateCertificateDto) {}

export class UpdateCertificateStatusDto {
  @IsEnum(CertificateStatus, {
    message:
      'Invalid status. Valid statuses are: Draft, Pending Approval, Approved, etc.',
  })
  @IsNotEmpty()
  @ApiProperty({
    description: 'The new status for the certificate',
    enum: CertificateStatus,
    example: CertificateStatus.Approved,
  })
  status: CertificateStatus;
}
