import { ApiProperty } from '@nestjs/swagger';
import {
  IsDateString,
  IsEnum,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';
import { SurveyStatus } from 'src/utils/models/common.types';

export class CertificateSurveyDto {
  @IsOptional()
  @IsNumber()
  @ApiProperty({
    example: 1,
    description: 'ID of the survey, optional for creation',
    required: false,
  })
  id?: number;

  @IsString()
  @ApiProperty({ example: 'Annual Survey', description: 'Name of the survey' })
  name: string;

  @IsString()
  @ApiProperty({ example: 'Safety', description: 'Type of survey' })
  type: string;

  @IsString()
  @ApiProperty({
    example: 'Maritime Safety Authority',
    description: 'Authority that conducted the survey',
  })
  authority: string;

  @IsString()
  @ApiProperty({ example: 'Jane Doe', description: 'Person who surveyed' })
  surveyedBy: string;

  @IsString()
  @ApiProperty({
    example: 'New York Port',
    description: 'Port where the survey took place',
  })
  locationPort: string;

  @IsString()
  @ApiProperty({
    example: '1-2 years',
    description: 'Range within which the due date falls',
  })
  dueRange: string;

  @IsOptional()
  @IsDateString()
  @ApiProperty({
    example: '2024-12-01',
    description: 'Due date for the next survey',
    required: false,
  })
  dueDate?: Date;

  @IsOptional()
  @IsDateString()
  @ApiProperty({
    example: '2025-01-01',
    description: 'Extended due date if applicable',
    required: false,
  })
  extendedDate?: Date;

  @IsOptional()
  @IsDateString()
  @ApiProperty({
    example: '2024-01-01',
    description: 'Date when the survey was completed',
    required: false,
  })
  completedDate?: Date;

  @IsEnum(SurveyStatus)
  @ApiProperty({
    enum: SurveyStatus,
    description: 'Current status of the survey',
  })
  status: SurveyStatus;
}
