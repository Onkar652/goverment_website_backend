import { Type } from 'class-transformer';
import {
  IsBoolean,
  IsDateString,
  IsEnum,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { CertificateStatus } from 'src/utils/models/common.types';
import { CertificateSurveyDto } from './certificate-surevy.dto';
import { ApiProperty } from '@nestjs/swagger';
import { CertificationEntity } from 'src/entities/certifications/certification.entity';

export class CreateCertificateDto {
  @IsOptional()
  @IsNumber()
  @ApiProperty({
    example: 123,
    description: 'The ID of the certificate, optional for creation',
    required: false,
  })
  id?: number;

  @IsNumber()
  @ApiProperty({
    example: 1,
    description: 'ID of the ship associated with the certificate',
  })
  shipId: number;

  @IsString()
  @ApiProperty({
    example: 'Certificate of registry',
    description: 'Name of the certificate',
  })
  certificateName: string;

  @IsString()
  @ApiProperty({
    example: '1.1',
    description: 'AdminSiNo',
  })
  adminSiNo: string;

  @IsString()
  @ApiProperty({ example: '217417', description: 'Unique certificate number' })
  certificateNo: string;

  @IsString()
  @ApiProperty({
    example: 'Provisional',
    description: 'Type of the certificate',
  })
  type: string;

  @IsDateString()
  @ApiProperty({
    example: '2024-01-01',
    description: 'Date the certificate was issued',
  })
  issuedOn: Date;

  @IsDateString()
  @ApiProperty({
    example: '2024-01-01',
    description: 'Date the certificate was last surveyed',
  })
  surveyedOn: Date;

  @IsDateString()
  @ApiProperty({
    example: '2025-01-01',
    description: 'Expiration date of the certificate',
  })
  expiryDate: Date;

  @IsOptional()
  @IsDateString()
  @ApiProperty({
    example: '2025-01-01',
    description: 'Extended expiration date of the certificate',
    required: false,
  })
  extendedDate?: Date;

  @IsString()
  @ApiProperty({
    example: 'John Doe',
    description: 'Name of the person who issued the certificate',
  })
  issuedBy: string;

  @IsString()
  @ApiProperty({
    example: 'Maritime Authority',
    description: 'Authority that issued the certificate',
  })
  issuingAuthority: string;

  @IsBoolean()
  @ApiProperty({
    example: true,
    description: 'Whether the original certificate is on board',
  })
  originalOnBoard: boolean;

  @IsEnum(CertificateStatus)
  @ApiProperty({
    enum: CertificateStatus,
    description: 'Current status of the certificate',
  })
  status: CertificateStatus;

  @ValidateNested({ each: true })
  @Type(() => CertificateSurveyDto)
  @ApiProperty({
    type: [CertificateSurveyDto],
    description: 'List of surveys associated with the certificate',
  })
  surveys: CertificateSurveyDto[];
}

export class CreateOrUpdateCertificateResponseDto {
  @ApiProperty({ type: () => CertificationEntity })
  certificate: CertificationEntity;

  @ApiProperty({ example: true })
  surveySaveSuccess: boolean;

  @ApiProperty({
    example: 'Certificate saved successfully. Surveys saved successfully.',
  })
  message: string;
}
