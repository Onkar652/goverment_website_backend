import {
  BadRequestException,
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  InternalServerErrorException,
  NotFoundException,
  Param,
  ParseIntPipe,
  ParseUUIDPipe,
  Post,
  Put,
  Query,
  Res,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import {
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { Response } from 'express';
import { CertificationsService } from './certifications.service';
import { PredefinedCertificatesEntity } from 'src/entities/certifications/certificate-list.entity';
import { CertificationEntity } from 'src/entities/certifications/certification.entity';
import {
  CreateCertificateDto,
  CreateOrUpdateCertificateResponseDto,
} from './dto/create-certificate.dto';
import { FilesInterceptor } from '@nestjs/platform-express';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { UpdateCertificateStatusDto } from './dto/update-certification.dto';
import { CertificateStatus } from 'src/utils/models/common.types';

@ApiTags('certification')
@Controller('certifications')
export class CertificationsController {
  constructor(private readonly certificationsService: CertificationsService) {}

  @Post('/seed')
  @ApiOperation({ summary: 'Seed predefined certificates and categories' })
  @ApiResponse({
    status: 200,
    description: 'Data seeding successful',
  })
  @ApiResponse({
    status: 500,
    description: 'Internal Server Error',
  })
  async seedData(@Res() res: Response): Promise<Response> {
    try {
      await this.certificationsService.seedData();
      return res
        .status(HttpStatus.OK)
        .json({ message: 'Data seeding successful' });
    } catch (error) {
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
        message: 'Error during data seeding',
        error: error.message,
      });
    }
  }

  @Get('/master-list')
  @ApiResponse({
    status: 200,
    description:
      'List of all predefined certificates with their linked surveys',
    type: [PredefinedCertificatesEntity],
  })
  async findAllCertificatesWithSurveys(): Promise<
    PredefinedCertificatesEntity[]
  > {
    const certificates = await this.certificationsService.getMasterData();

    if (certificates.length === 0) {
      throw new NotFoundException('No predefined certificates found');
    }
    return certificates;
  }

  @Post()
  @ApiOperation({
    summary: 'Create or update a certificate along with its surveys',
    description:
      'If a certificate with the same name and ship ID exists, it will be updated. Otherwise, a new certificate will be created.',
  })
  @ApiResponse({
    status: 201,
    description: 'Certificate created or updated successfully',
    type: CreateOrUpdateCertificateResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Invalid request parameters' })
  async createOrUpdateCertificate(
    @Body() createDto: CreateCertificateDto,
  ): Promise<CreateOrUpdateCertificateResponseDto> {
    try {
      const savedCertificate =
        this.certificationsService.createOrUpdateCertificate(createDto);

      return savedCertificate;
    } catch (error) {
      if (
        error instanceof BadRequestException ||
        error instanceof NotFoundException
      ) {
        throw error;
      }
      throw new InternalServerErrorException(
        'Error creating or updating certificate',
      );
    }
  }

  @Post(':certificateId/files')
  @ApiOperation({ summary: 'Upload documents for a certificate' })
  @ApiConsumes('multipart/form-data')
  @ApiParam({
    name: 'certificateId',
    description: 'ID of the certificate to attach the files',
    type: Number,
  })
  @ApiResponse({
    status: 201,
    description: 'Files uploaded successfully',
    type: FileStorageEntity,
  })
  @ApiBody({
    description: 'File upload',
    required: true,
    schema: {
      type: 'object',
      properties: {
        certificateDocs: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  @UseInterceptors(FilesInterceptor('certificateDocs', 10))
  async uploadCertificateFiles(
    @Param('certificateId', ParseIntPipe) certificateId: number,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<{ message: string }> {
    try {
      if (!files) {
        throw new BadRequestException(
          'No files provided for certificate upload',
        );
      }

      await this.certificationsService.uploadCertificateFiles(
        certificateId,
        files,
      );
      return { message: 'Files uploaded successfully' };
    } catch (error) {
      if (
        error instanceof NotFoundException ||
        error instanceof BadRequestException
      ) {
        throw error;
      }
      throw new InternalServerErrorException(
        'Error uploading certificate files',
      );
    }
  }

  @Post('survey/:surveyId/files')
  @ApiOperation({ summary: 'Upload documents for a survey' })
  @ApiConsumes('multipart/form-data')
  @ApiParam({
    name: 'surveyId',
    description: 'ID of the survey to attach the files',
    type: Number,
  })
  @ApiResponse({
    status: 201,
    description: 'Files uploaded successfully',
    type: FileStorageEntity,
  })
  @ApiBody({
    description: 'Upload survey documents',
    schema: {
      type: 'object',
      properties: {
        surveyDocs: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary', // Required for file upload
          },
        },
      },
    },
  })
  @UseInterceptors(FilesInterceptor('surveyDocs', 10))
  async uploadSurveyFiles(
    @Param('surveyId', ParseIntPipe) surveyId: number,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<{
    message: string;
    files: { fileId: string; filename: string }[];
  }> {
    try {
      if (!files || files.length === 0) {
        throw new BadRequestException('No files provided for survey upload');
      }
      const uploadedFiles = await this.certificationsService.uploadSurveyFiles(
        surveyId,
        files,
      );
      const res = uploadedFiles.map((el) => ({
        fileId: el.id,
        filename: el.fileName,
      }));
      return {
        message: 'Files uploaded successfully',
        files: res,
      };
    } catch (error) {
      if (
        error instanceof NotFoundException ||
        error instanceof BadRequestException
      ) {
        throw error;
      }
      throw new InternalServerErrorException('Error uploading survey files');
    }
  }

  @Put('replace/:fileId')
  @ApiOperation({ summary: 'Replace an existing file with a new one' })
  @ApiConsumes('multipart/form-data')
  @ApiParam({
    name: 'fileId',
    description: 'ID of the file to replace',
    type: String,
  })
  @ApiResponse({
    status: 200,
    description: 'File replaced successfully',
    type: FileStorageEntity,
  })
  @ApiBody({
    description: 'Upload new file to replace',
    schema: {
      type: 'object',
      properties: {
        newFile: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary', // Required for file upload
          },
        },
      },
    },
  })
  @ApiResponse({ status: 404, description: 'File not found' })
  @UseInterceptors(FilesInterceptor('newFile', 1))
  async replaceFile(
    @Param('fileId', ParseUUIDPipe) fileId: string,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<{ message: string; file: FileStorageEntity }> {
    try {
      if (!files) {
        throw new BadRequestException('No file provided for replacement');
      }
      const updatedFile = await this.certificationsService.replaceFile(
        fileId,
        files[0],
      );
      return { message: 'File replaced successfully', file: updatedFile };
    } catch (error) {
      if (error instanceof NotFoundException) {
        throw new NotFoundException(`File with ID ${fileId} not found`);
      }
      throw new InternalServerErrorException('Error replacing the file');
    }
  }

  @Get(':shipId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Retrieve all certificates for a specific ship' })
  @ApiResponse({
    status: 200,
    description: 'List of certificates for the given ship',
    type: CertificationEntity,
    isArray: true,
  })
  @ApiParam({
    name: 'shipId',
    required: true,
    description: 'The ID of the ship for which to retrieve certificates',
    type: 'number',
  })
  async getCertificatesByShip(
    @Param('shipId') shipId: number,
  ): Promise<CertificationEntity[]> {
    return this.certificationsService.getCertificatesByShip(shipId);
  }

  @Post(':id/status')
  @ApiOperation({ summary: 'Update the status of a certificate using POST' })
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'The ID of the certificate',
  })
  @ApiResponse({
    status: 200,
    description: 'The status has been successfully updated',
    type: CertificationEntity,
  })
  @ApiResponse({ status: 404, description: 'Certificate not found' })
  async updateCertificateStatus(
    @Param('id') id: number,
    @Body() updateStatusDto: UpdateCertificateStatusDto,
  ): Promise<CertificationEntity> {
    return this.certificationsService.updateCertificateStatus(
      id,
      updateStatusDto,
    );
  }

  @Get('/by-status/:shipId')
  @ApiOperation({ summary: 'Get certificates by shipId and status' })
  @ApiParam({
    name: 'shipId',
    description: 'ID of the ship',
    type: Number,
  })
  @ApiQuery({
    name: 'status',
    description: 'Certificate status to filter by',
    enum: CertificateStatus,
    required: false,
  })
  @ApiQuery({
    name: 'sortField',
    description:
      'Field to sort by. Allowed values: issueDate, expiryDate, createdAt',
    required: false,
  })
  @ApiQuery({
    name: 'sortOrder',
    description: 'Sort order: ASC or DESC',
    required: false,
  })
  @ApiResponse({
    status: 200,
    description: 'List of certificates matching the given status',
    type: [CertificationEntity],
  })
  @ApiResponse({
    status: 404,
    description: 'No certificates found for the given criteria',
  })
  async getCertificatesByStatus(
    @Param('shipId', ParseIntPipe) shipId: number,
    @Query('status') status: CertificateStatus,
    @Query('sortField') sortField?: string,
    @Query('sortOrder') sortOrder?: string,
  ): Promise<CertificationEntity[]> {
    const certificates =
      await this.certificationsService.getCertificatesByStatus(
        shipId,
        status,
        sortField,
        sortOrder,
      );
    return certificates;
  }
}
