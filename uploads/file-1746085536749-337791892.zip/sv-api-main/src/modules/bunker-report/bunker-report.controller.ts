import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { BunkerReportService } from './bunker-report.service';
import {
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { InitiateBunkerReportDto } from './dto/initiate-bunker.dto';
import { SaveBunkerReportDto } from './dto/save-bunker-report.dto';
import { GetBunkerReportsDto } from './dto/get-bunker-reports.dto';
import { BunkerReportEntity } from '../../entities/bunker-reports/bunker-reports.entity';
import { FilesInterceptor } from '@nestjs/platform-express';

@ApiTags('Bunker Report')
@Controller('bunker-report')
export class BunkerReportController {
  constructor(private readonly bunkerReportService: BunkerReportService) {}

  @Post('/initiate-bunker-report')
  @ApiOperation({ summary: 'Initiate a new bunker report' })
  @ApiResponse({
    status: 201,
    description: 'Bunker report initiated successfully.',
  })
  async initiateBunkerReport(
    @Body() initiateBunkerReportDto: InitiateBunkerReportDto,
  ): Promise<BunkerReportEntity> {
    return await this.bunkerReportService.initiateBunkerReport(
      initiateBunkerReportDto,
    );
  }

  @Post('/save')
  @ApiOperation({ summary: 'Save Bunker Report' })
  @ApiResponse({
    status: 201,
    description: 'Bunker report updated successfully.',
  })
  @ApiResponse({ status: 404, description: 'Bunker report not found.' })
  async saveBunkerReport(@Body() saveBunkerReportDto: SaveBunkerReportDto) {
    return await this.bunkerReportService.saveBunkerReport(saveBunkerReportDto);
  }

  @Get()
  @ApiOperation({ summary: 'Get all bunker reports by shipId with pagination' })
  @ApiResponse({
    status: 200,
    description: 'Returns paginated list of bunker reports.',
  })
  async getBunkerReports(@Query() query: GetBunkerReportsDto) {
    return await this.bunkerReportService.getBunkerReports(query);
  }

  @Get(':reportNumber')
  @ApiOperation({ summary: 'Get bunker report details by report number' })
  @ApiResponse({
    status: 200,
    description: 'Returns bunker report details including all relations.',
  })
  async getBunkerReportDetails(@Param('reportNumber') reportNumber: string) {
    return await this.bunkerReportService.getBunkerReportDetails(reportNumber);
  }

  @Post(':reportNumber/attachments')
  @UseInterceptors(FilesInterceptor('files')) // Change to FilesInterceptor
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Upload multiple attachments for a voyage',
    schema: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  async uploadAttachments(
    @Param('reportNumber') reportNumber: string,
    @UploadedFiles() files: Express.Multer.File[], // Change to @UploadedFiles
  ): Promise<{ message: string }> {
    await this.bunkerReportService.uploadAttachments(reportNumber, files);
    return { message: 'Attachments uploaded successfully' };
  }
}
