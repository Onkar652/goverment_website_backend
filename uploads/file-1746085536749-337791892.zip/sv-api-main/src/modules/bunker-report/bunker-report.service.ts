import {
  BadRequestException,
  ConflictException,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { BunkerReportEntity } from 'src/entities/bunker-reports/bunker-reports.entity';
import { PositionBookReportEntity } from 'src/entities/postion-book-reports/postion-report.entity';
import { ContentEntity } from 'src/entities/tank-config/content.entity';
import { TankConfigurationEntity } from 'src/entities/tank-config/tank-config.entity';
import { BunkerTransactionType } from 'src/utils/models/common.types';
import { DataSource, EntityManager, Like, Repository } from 'typeorm';
import { ShipValidationService } from '../common/ship-validation.service';
import { InitiateBunkerReportDto } from './dto/initiate-bunker.dto';
import { BunkerReportDetailsEntity } from 'src/entities/bunker-reports/bunker-report-details.entity';
import { TankTransferDetailsEntity } from 'src/entities/bunker-reports/tank-transfer-details.entity';
import {
  SaveBunkerReportDto,
  BunkerReportDetailDto,
  TankTransferDetailDto,
} from './dto/save-bunker-report.dto';
import { GetBunkerReportsDto } from './dto/get-bunker-reports.dto';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { TimezoneEntity } from 'src/entities/master-configs/timezone.entity';

@Injectable()
export class BunkerReportService {
  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(BunkerReportEntity)
    private readonly bunkerReportRepository: Repository<BunkerReportEntity>,

    @InjectRepository(TankConfigurationEntity)
    private readonly tankConfigRepository: Repository<TankConfigurationEntity>,

    @InjectRepository(PositionBookReportEntity)
    private readonly positionBookReportRepository: Repository<PositionBookReportEntity>,

    @InjectRepository(ContentEntity)
    private readonly contentRepository: Repository<ContentEntity>,
    @InjectRepository(BunkerReportDetailsEntity)
    private bunkerReportDetailsRepository: Repository<BunkerReportDetailsEntity>,

    @InjectRepository(TankTransferDetailsEntity)
    private tankTransferDetailsRepository: Repository<TankTransferDetailsEntity>,
    private shipValidationService: ShipValidationService,
    @InjectRepository(FileStorageEntity)
    private readonly fileStorageRepository: Repository<FileStorageEntity>,
    @InjectRepository(TimezoneEntity)
    private readonly timezoneRepository: Repository<TimezoneEntity>,
  ) {}
  async initiateBunkerReport(
    initiateBunkerReportDto: InitiateBunkerReportDto,
  ): Promise<BunkerReportEntity> {
    const { shipId } = initiateBunkerReportDto;

    if (!shipId) {
      throw new BadRequestException('Ship ID is missing');
    }

    // Step 1: Validate Ship
    const ship = await this.shipValidationService.getShipById(shipId);
    await this.shipValidationService.validateNoActiveReport(shipId);

    // Step 2: Check for existing draft reports
    const existingDraft = await this.bunkerReportRepository.findOne({
      where: { ship: { id: ship.id }, status: 'draft' },
    });

    const existingPositionReport =
      await this.positionBookReportRepository.findOne({
        where: { ship: { id: ship.id }, status: 'draft' },
      });

    if (existingDraft || existingPositionReport) {
      throw new ConflictException(
        `There is already a draft report in progress. Please complete it before creating a new one.`,
      );
    }

    // Step 3: Generate Report ID
    const reportId = await this.generateBunkerReportId(ship.code);

    // Step 4: Create new bunker report draft
    const newBunkerReport = this.bunkerReportRepository.create({
      reportNumber: reportId,
      ship,
      reportDate: new Date(),
      reportTime: new Date().toTimeString().slice(0, 5).replace(':', ''), // "HHmm"
      transactionType: BunkerTransactionType.BUNKERING,
      status: 'draft',
      bunkeredAt: '',
      companyName: null,
      surveyorName: null,
      comments: null,
    });

    await this.bunkerReportRepository.save(newBunkerReport);

    // Step 5: Fetch initial tank data
    const tanks = await this.tankConfigRepository.find({
      where: { ship: { id: ship.id } },
      relations: ['content'],
    });
    const tankDetails = [];
    // Step 6: Populate bunker report details
    const reportDetails = tanks.map((tank) => {
      const initTank = {
        tank: {
          id: tank.id,
          tankCode: tank.tankCode,
          tankName: tank.tankName,
          capacity: tank.capacity,
          unitOfMeasure: tank.unitOfMeasure,
          currentROB: tank.currentROB,
          lastReportROB: tank.lastReportROB,
        },
        content: {
          id: tank.content.id,
          contentCode: tank.content.contentCode,
          name: tank.content.name,
          sulphurContent: tank.content.sulphurContent,
          viscosity: tank.content.viscosity,
          density: tank.content.density,
        },
        initialQty: tank.lastReportROB || 0, // Setting initial value from last report
        bunkeredQty: 0,
        shortSupply: 0,
        finalQty: tank.lastReportROB || 0, // Assuming finalQty starts from initial
        difference: 0,
        comments: null,
      };

      tankDetails.push(initTank);
      return this.bunkerReportDetailsRepository.create({
        bunkerReport: newBunkerReport,
        tank: tank, // Saving the full tank entity in the database
        content: tank.content, // Saving the full content entity in the database
        initialQty: initTank.initialQty,
        bunkeredQty: initTank.bunkeredQty,
        shortSupply: initTank.shortSupply,
        finalQty: initTank.finalQty,
        difference: initTank.difference,
        comments: initTank.comments,
      });
    });

    await this.bunkerReportDetailsRepository.save(reportDetails);

    await this.shipValidationService.createActiveReport(
      shipId,
      reportId,
      'bunker_report',
    );

    // Step 7: Return bunker report entity with default values
    return {
      ...newBunkerReport,
      details: tankDetails,
      transferDetails: [],
    };
  }

  private async generateBunkerReportId(shipCode: string): Promise<string> {
    const currentYear = new Date().getFullYear().toString().slice(-2); // "25" for 2025

    // Find the latest bunker report for the given ship
    const lastReport = await this.bunkerReportRepository.findOne({
      where: { reportNumber: Like(`${shipCode}-BR-%`) },
      order: { reportNumber: 'DESC' },
    });

    let serialNumber = 1;

    if (lastReport) {
      const lastReportIdParts = lastReport.reportNumber.split('-');
      const lastYear = lastReportIdParts[2].substring(0, 2); // Extract year from last report ID
      const lastSerial = parseInt(lastReportIdParts[2].substring(2), 10); // Extract serial number

      if (lastYear === currentYear) {
        serialNumber = lastSerial + 1; // Increment if same year
      }
    }

    const paddedSerial = serialNumber.toString().padStart(3, '0');
    return `${shipCode}-BR-${currentYear}${paddedSerial}`;
  }

  async saveBunkerReport(
    dto: SaveBunkerReportDto,
  ): Promise<{ message: string }> {
    const {
      reportNumber,
      shipId,
      transactionType,
      reportDate,
      reportTime,
      bunkeredAt,
      companyName,
      surveyorName,
      comments,
      details,
      transferDetails,
      status,
      isCorrection,
      isShore,
      isShoreTask,
    } = dto;

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.shipValidationService.getShipById(shipId);

      const report = await queryRunner.manager.findOne(BunkerReportEntity, {
        where: { reportNumber: reportNumber },
      });

      if (!report) {
        throw new BadRequestException(
          `Report with ${reportNumber} does not exist`,
        );
      }
      report.transactionType = transactionType;
      report.reportDate = reportDate;
      report.reportTime = reportTime;
      report.bunkeredAt = bunkeredAt;
      report.companyName = companyName;
      report.surveyorName = surveyorName;
      report.comments = comments;
      report.bunkeredAt = bunkeredAt;
      report.bargeName = dto.bargeName || '';
      report.supplierName = dto.supplierName || '';
      report.timezone = dto.timezone || '';
      report.isCorrection = isCorrection || false;
      report.isShore = isShore || false;
      report.isShoreTask = isShoreTask || false;
      report.status = status;

      await queryRunner.manager.save(report);

      if (transactionType !== BunkerTransactionType.TANK_TRANSFER && details) {
        await this.saveBunkerDetails(report, details, queryRunner.manager);
      }

      if (
        transactionType === BunkerTransactionType.TANK_TRANSFER &&
        transferDetails
      ) {
        await this.saveTankTransferDetails(
          report,
          transferDetails,
          queryRunner.manager,
        );
      }

      const timeZoneData = await this.timezoneRepository.findOne({
        where: { timezone_id: dto.timezone },
      });
      let utcOffset = 0;
      if (timeZoneData) {
        utcOffset = timeZoneData.utcOffset;
      }

      if (status === 'approved') {
        // Mark the report as completed in active report tracking
        await this.shipValidationService.completeActiveReport(
          reportNumber,
          reportDate.toISOString().split('T')[0],
          reportTime,
          utcOffset,
        );
      }
      await queryRunner.commitTransaction();
      return { message: 'Bunker report saved successfully' };
    } catch (error) {
      // Rollback transaction in case of failure
      await queryRunner.rollbackTransaction();
      throw new InternalServerErrorException(
        `Failed to save bunker report: ${error.message}`,
      );
    } finally {
      await queryRunner.release();
    }
  }

  private async saveBunkerDetails(
    report: BunkerReportEntity,
    details: BunkerReportDetailDto[],
    manager: EntityManager,
  ) {
    for (const detail of details) {
      const tank = await manager.findOne(TankConfigurationEntity, {
        where: { tankCode: detail.tankCode },
      });
      if (!tank) {
        throw new NotFoundException(
          `Tank with ID ${detail.tankCode} not found.`,
        );
      }

      const content = await manager.findOne(ContentEntity, {
        where: { contentCode: detail.contentCode },
      });
      if (!content) {
        throw new NotFoundException(
          `Content with ID ${detail.contentCode} not found.`,
        );
      }

      let reportDetail = await manager.findOne(BunkerReportDetailsEntity, {
        where: {
          bunkerReport: { id: report.id },
          tank: { id: tank.id },
          content: { id: content.id },
        },
      });
      if (reportDetail) {
        // Update the existing record
        reportDetail.initialQty = detail.initialQty;
        reportDetail.bunkeredQty = detail.bunkeredQty || 0;
        reportDetail.shortSupply = detail.shortSupply || 0;
        reportDetail.finalQty = detail.finalQty;
        reportDetail.difference = detail.difference || 0;
        reportDetail.consumption = detail.consumption || 0;
        reportDetail.comments = detail.comments || null;
      } else {
        // Create a new record if it doesn't exist
        reportDetail = manager.create(BunkerReportDetailsEntity, {
          bunkerReport: report,
          tank,
          content,
          initialQty: detail.initialQty,
          bunkeredQty: detail.bunkeredQty || 0,
          shortSupply: detail.shortSupply || 0,
          finalQty: detail.finalQty,
          difference: detail.difference || 0,
          consumption: detail.consumption || 0,
          comments: detail.comments || null,
        });
      }

      await manager.save(reportDetail);

      // Update tank config on final approval
      if (report.status === 'approved') {
        tank.lastReportROB = detail.finalQty;
        tank.currentROB = detail.finalQty;
        await manager.save(tank);
      }
    }
  }

  private async saveTankTransferDetails(
    report: BunkerReportEntity,
    transferDetails: TankTransferDetailDto[],
    manager: EntityManager,
  ) {
    for (const transfer of transferDetails) {
      const fromTank = await manager.findOne(TankConfigurationEntity, {
        where: { tankCode: transfer.fromTankCode },
      });
      const toTank = await manager.findOne(TankConfigurationEntity, {
        where: { tankCode: transfer.toTankCode },
      });

      if (!fromTank || !toTank) {
        throw new NotFoundException(`Tanks not found for transfer.`);
      }

      const content = await manager.findOne(ContentEntity, {
        where: { contentCode: transfer.contentCode },
      });

      const existingTransfer = await manager.findOne(
        TankTransferDetailsEntity,
        {
          where: {
            bunkerReport: { id: report.id },
            fromTank: { id: fromTank.id },
            toTank: { id: toTank.id },
            content: { id: content.id },
          },
        },
      );
      if (existingTransfer) {
        // Update existing transfer details instead of creating a new record
        existingTransfer.transferFromTankROB = transfer.transferFromTankROB;
        existingTransfer.transferToTankROB = transfer.transferToTankROB;
        existingTransfer.transferQty = transfer.transferQty;
        existingTransfer.comments =
          transfer.comments || existingTransfer.comments;

        await manager.save(existingTransfer);
      } else {
        // Create new transfer entry if it doesn't exist
        const transferEntry = manager.create(TankTransferDetailsEntity, {
          bunkerReport: report,
          fromTank,
          toTank,
          content,
          transferFromTankROB: transfer.transferFromTankROB,
          transferToTankROB: transfer.transferToTankROB,
          transferQty: transfer.transferQty,
          comments: transfer.comments || null,
        });

        await manager.save(transferEntry);
      }

      // Update tanks upon approval
      if (report.status === 'approved') {
        fromTank.currentROB -= transfer.transferQty;
        fromTank.lastReportROB -= transfer.transferQty;
        toTank.currentROB += transfer.transferQty;
        toTank.lastReportROB += transfer.transferQty;
        await manager.save([fromTank, toTank]);
      }
    }
  }

  async getBunkerReports(dto: GetBunkerReportsDto): Promise<{
    total: number;
    page: number;
    limit: number;
    reports: BunkerReportEntity[];
  }> {
    const { shipId, status, page = 1, limit = 10 } = dto;

    const queryBuilder = this.bunkerReportRepository
      .createQueryBuilder('report')
      //   .leftJoinAndSelect('report.details', 'details')
      //   .leftJoinAndSelect('report.transferDetails', 'transfer')
      .where('report.ship = :shipId', { shipId });

    if (status) {
      queryBuilder.andWhere('report.status = :status', { status });
    }

    // Count total reports
    const total = await queryBuilder.getCount();

    // Apply pagination
    const reports = await queryBuilder
      .orderBy('report.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getMany();

    return {
      total,
      page,
      limit,
      reports,
    };
  }

  async getBunkerReportDetails(
    reportNumber: string,
  ): Promise<BunkerReportEntity> {
    const report = await this.bunkerReportRepository
      .createQueryBuilder('bunkerReport')
      .leftJoinAndSelect('bunkerReport.ship', 'ship')
      .leftJoinAndSelect('bunkerReport.details', 'details')
      .leftJoinAndSelect('details.tank', 'tank')
      .leftJoinAndSelect('details.content', 'content')
      .leftJoinAndSelect('bunkerReport.transferDetails', 'transferDetails')
      .leftJoinAndSelect('transferDetails.fromTank', 'fromTank')
      .leftJoinAndSelect('transferDetails.toTank', 'toTank')
      .leftJoinAndSelect('transferDetails.content', 'transferContent')
      .leftJoin('bunkerReport.attachments', 'attachments')
      .addSelect([
        'attachments.id',
        'attachments.fileName',
        'attachments.mimeType',
        'attachments.createdOn',
      ])
      .where('bunkerReport.reportNumber = :reportNumber', { reportNumber })
      .orderBy('content.typeOrder', 'ASC')
      .addOrderBy('content.order', 'ASC')
      .getOne();

    if (!report) {
      throw new NotFoundException(
        `Bunker report with report number ${reportNumber} not found.`,
      );
    }

    return report;
  }

  async uploadAttachments(
    reportNumber: string,
    files: Express.Multer.File[],
  ): Promise<void> {
    const bunkerReport = await this.bunkerReportRepository.findOne({
      where: { reportNumber },
    });

    if (!bunkerReport) {
      throw new NotFoundException(
        `Bunker report with ID ${reportNumber} not found.`,
      );
    }

    const attachments = files.map((file) =>
      this.fileStorageRepository.create({
        data: file.buffer,
        mimeType: file.mimetype,
        fileName: file.originalname,
        bunkerReport,
      }),
    );

    await this.fileStorageRepository.save(attachments);
  }
}
