import { Test, TestingModule } from '@nestjs/testing';
import { BunkerReportService } from './bunker-report.service';

describe('BunkerReportService', () => {
  let service: BunkerReportService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [BunkerReportService],
    }).compile();

    service = module.get<BunkerReportService>(BunkerReportService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
