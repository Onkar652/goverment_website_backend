import { Test, TestingModule } from '@nestjs/testing';
import { BunkerReportController } from './bunker-report.controller';
import { BunkerReportService } from './bunker-report.service';

describe('BunkerReportController', () => {
  let controller: BunkerReportController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [BunkerReportController],
      providers: [BunkerReportService],
    }).compile();

    controller = module.get<BunkerReportController>(BunkerReportController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
