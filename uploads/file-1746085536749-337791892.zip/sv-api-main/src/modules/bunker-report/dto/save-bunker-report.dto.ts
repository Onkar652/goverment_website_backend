import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  IsEnum,
  IsDateString,
  ValidateNested,
  IsArray,
  IsBoolean,
} from 'class-validator';
import { Type } from 'class-transformer';
import { BunkerTransactionType } from 'src/utils/models/common.types';

export enum BunkerReportStatus {
  DRAFT = 'draft',
  APPROVED = 'approved',
}
export class BunkerReportDetailDto {
  @ApiProperty({
    example: 'TK001',
    description: 'Tank code for the bunker report',
  })
  @IsNotEmpty()
  @IsString()
  tankCode: string;

  @ApiProperty({
    example: 'FO001',
    description: 'Content code associated with the tank',
  })
  @IsNotEmpty()
  @IsString()
  contentCode: string;

  @ApiProperty({ example: 1000, description: 'Initial quantity in the tank' })
  @IsNotEmpty()
  @IsNumber()
  initialQty: number;

  @ApiProperty({
    example: 200,
    description: 'Quantity bunkered',
    required: false,
  })
  @IsOptional()
  @IsNumber()
  bunkeredQty?: number;

  @ApiProperty({
    example: 10,
    description: 'Short supply quantity',
    required: false,
  })
  @IsOptional()
  @IsNumber()
  shortSupply?: number;

  @ApiProperty({ example: 1200, description: 'Final quantity in the tank' })
  @IsNotEmpty()
  @IsNumber()
  finalQty: number;

  @ApiProperty({
    example: -10,
    description: 'Difference between initial and final quantity',
    required: false,
  })
  @IsOptional()
  @IsNumber()
  difference?: number;

  @ApiProperty({
    example: 2,
    description: 'Consumption between initial and during consumption',
    required: false,
  })
  @IsOptional()
  @IsNumber()
  consumption?: number;

  @ApiProperty({
    example: 'Shortage observed during delivery',
    description: 'Additional comments',
    required: false,
  })
  @IsOptional()
  @IsString()
  comments?: string;
}

export class TankTransferDetailDto {
  @ApiProperty({
    example: 'TK001',
    description: 'Tank code from which the transfer is done',
  })
  @IsNotEmpty()
  @IsString()
  fromTankCode: string;

  @ApiProperty({
    example: 'TK002',
    description: 'Tank code to which the transfer is done',
  })
  @IsNotEmpty()
  @IsString()
  toTankCode: string;

  @ApiProperty({
    example: 'FO001',
    description: 'Content code associated with the transfer',
  })
  @IsNotEmpty()
  @IsString()
  contentCode: string;

  @ApiProperty({
    example: 500,
    description: 'ROB quantity before transfer in the source tank',
  })
  @IsNotEmpty()
  @IsNumber()
  transferFromTankROB: number;

  @ApiProperty({
    example: 600,
    description: 'ROB quantity after transfer in the destination tank',
  })
  @IsNotEmpty()
  @IsNumber()
  transferToTankROB: number;

  @ApiProperty({ example: 100, description: 'Quantity transferred' })
  @IsNotEmpty()
  @IsNumber()
  transferQty: number;

  @ApiProperty({
    example: 'Transfer done for balancing',
    description: 'Additional comments',
    required: false,
  })
  @IsOptional()
  @IsString()
  comments?: string;
}

export class SaveBunkerReportDto {
  @ApiProperty({
    example: 'BR123456',
    description: 'Unique ID of the bunker report',
  })
  @IsNotEmpty()
  @IsString()
  reportNumber: string;

  @ApiProperty({ example: 1, description: 'ID of the ship' })
  @IsNotEmpty()
  @IsNumber()
  shipId: number;

  @ApiProperty({
    enum: BunkerTransactionType,
    description: 'Type of bunker transaction',
  })
  @IsNotEmpty()
  @IsEnum(BunkerTransactionType)
  transactionType: BunkerTransactionType;

  @ApiProperty({
    example: '2024-12-01',
    description: 'Date of the report in YYYY-MM-DD format',
  })
  @IsNotEmpty()
  @IsDateString()
  reportDate: Date;

  @ApiProperty({ example: '1200', description: 'Report submission time' })
  @IsNotEmpty()
  @IsString()
  reportTime: string;

  @ApiProperty({
    example: 'Port of Rotterdam',
    description: 'Location where the bunkering took place',
  })
  @IsOptional()
  @IsString()
  bunkeredAt: string;

  @ApiProperty({
    example: 'UTC-11',
    description: 'Timezone',
  })
  @IsOptional()
  @IsString()
  timezone: string;

  @ApiPropertyOptional({ example: true })
  @IsOptional()
  @IsBoolean()
  isShore?: boolean;

  @ApiPropertyOptional({ example: true })
  @IsOptional()
  @IsBoolean()
  isShoreTask?: boolean;

  @ApiPropertyOptional({ example: true })
  @IsOptional()
  @IsBoolean()
  isCorrection?: boolean;

  @ApiProperty({
    enum: BunkerReportStatus,
    description: 'Status of the bunker report (draft or approved)',
    example: BunkerReportStatus.DRAFT,
  })
  @IsNotEmpty()
  @IsEnum(BunkerReportStatus)
  status: BunkerReportStatus;

  @ApiProperty({
    example: 'XYZ Bunkering Co.',
    description: 'Name of the company supplying the bunker',
    required: false,
  })
  @IsOptional()
  @IsString()
  companyName?: string;

  @ApiProperty({
    example: 'John Doe',
    description: 'Name of the surveyor overseeing the process',
    required: false,
  })
  @IsOptional()
  @IsString()
  surveyorName?: string;

  @ApiProperty({
    example: 'Barge snow',
    description: 'Name of the barge supplying the bunker',
    required: false,
  })
  @IsOptional()
  @IsString()
  bargeName?: string;

  @ApiProperty({
    example: 'John Doe',
    description: 'Name of the supplier supplying the bunkers',
    required: false,
  })
  @IsOptional()
  @IsString()
  supplierName?: string;

  @ApiProperty({
    example: 'Bunkering completed successfully',
    description: 'General comments',
    required: false,
  })
  @IsOptional()
  @IsString()
  comments?: string;

  @ApiProperty({
    type: [BunkerReportDetailDto],
    description: 'Detailed breakdown of bunker report',
    required: false,
  })
  @ValidateNested({ each: true })
  @Type(() => BunkerReportDetailDto)
  @IsArray()
  details?: BunkerReportDetailDto[];

  @ApiProperty({
    type: [TankTransferDetailDto],
    description: 'Tank transfer details',
    required: false,
  })
  @ValidateNested({ each: true })
  @Type(() => TankTransferDetailDto)
  @IsArray()
  transferDetails?: TankTransferDetailDto[];
}
