import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsNumber, IsOptional, IsPositive, IsString } from 'class-validator';

export class GetBunkerReportsDto {
  @ApiProperty({ description: 'ID of the ship', example: 1 })
  @Transform(({ value }) => Number(value))
  @IsNumber()
  shipId: number;

  @ApiProperty({
    description: 'Status of the report (draft or approved)',
    example: 'draft',
    required: false,
  })
  @IsOptional()
  @IsString()
  status?: string;

  @ApiProperty({
    description: 'Page number for pagination',
    example: 1,
    required: false,
  })
  @Transform(({ value }) => (value ? Number(value) : undefined))
  @IsOptional()
  @IsPositive()
  page?: number;

  @ApiProperty({ description: 'Limit per page', example: 10, required: false })
  @Transform(({ value }) => (value ? Number(value) : undefined))
  @IsOptional()
  @IsPositive()
  limit?: number;
}
