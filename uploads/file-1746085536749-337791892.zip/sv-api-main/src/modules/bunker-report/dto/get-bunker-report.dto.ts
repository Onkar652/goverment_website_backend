import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty } from 'class-validator';

export class GetBunkerReportDto {
  @ApiProperty({
    description: 'Report number of the bunker report',
    example: 'ARK_BR_25001',
  })
  @IsNotEmpty()
  @IsString()
  reportNumber: string;
}
