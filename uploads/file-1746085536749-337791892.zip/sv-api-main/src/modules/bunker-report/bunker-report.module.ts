import { Module } from '@nestjs/common';
import { BunkerReportService } from './bunker-report.service';
import { BunkerReportController } from './bunker-report.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BunkerReportEntity } from 'src/entities/bunker-reports/bunker-reports.entity';
import { PositionBookReportEntity } from 'src/entities/postion-book-reports/postion-report.entity';
import { ContentEntity } from 'src/entities/tank-config/content.entity';
import { TankConfigurationEntity } from 'src/entities/tank-config/tank-config.entity';
import { ShipValidationService } from '../common/ship-validation.service';
import { BunkerReportDetailsEntity } from 'src/entities/bunker-reports/bunker-report-details.entity';
import { TankTransferDetailsEntity } from 'src/entities/bunker-reports/tank-transfer-details.entity';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { TimezoneEntity } from 'src/entities/master-configs/timezone.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      BunkerReportEntity,
      TankConfigurationEntity,
      PositionBookReportEntity,
      ContentEntity,
      BunkerReportDetailsEntity,
      TankTransferDetailsEntity,
      FileStorageEntity,
      TimezoneEntity,
    ]),
  ],
  controllers: [BunkerReportController],
  providers: [BunkerReportService, ShipValidationService],
})
export class BunkerReportModule {}
