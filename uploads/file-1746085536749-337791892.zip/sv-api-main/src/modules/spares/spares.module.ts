import { Module } from '@nestjs/common';
import { SparesService } from './spares.service';
import { SparesController } from './spares.controller';
import { CommonModule } from '../common/common.module';

@Module({
  imports: [CommonModule],
  controllers: [SparesController],
  providers: [SparesService],
})
export class SparesModule {}
