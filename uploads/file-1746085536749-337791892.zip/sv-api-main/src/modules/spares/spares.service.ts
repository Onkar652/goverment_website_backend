import { Injectable, NotFoundException } from '@nestjs/common';
import { SpareEntity } from 'src/entities/inventory/spares.entity';
import { MainPart } from 'src/entities/shipParts/main-parts.entity';
import { Ship } from 'src/entities/ships/ships.entity';
import { DataSource, Repository } from 'typeorm';
import { ShipValidationService } from '../common/ship-validation.service';
import { CreateSpareDto } from './dto/create-spare.dto';
import { UpdateSpareDto } from './dto/update-spare.dto';
import {
  SpareTransaction,
  TransactionReason,
} from 'src/entities/inventory/spare-transaction.entity';

@Injectable()
export class SparesService {
  private readonly spareRepository: Repository<SpareEntity>;

  private readonly shipRepository: Repository<Ship>;
  private readonly mainPartRepository: Repository<MainPart>;
  private readonly spareTransactionRepository: Repository<SpareTransaction>;
  constructor(
    private readonly dataSource: DataSource,
    private shipValidationService: ShipValidationService,
  ) {
    this.spareRepository = this.dataSource.getRepository(SpareEntity);
    this.shipRepository = this.dataSource.getRepository(Ship);
    this.mainPartRepository = this.dataSource.getRepository(MainPart);
    this.spareTransactionRepository =
      this.dataSource.getRepository(SpareTransaction);
  }

  async createSpare(createSpareDto: CreateSpareDto): Promise<SpareEntity> {
    const {
      shipId,
      mainPartId,
      rob,
      reason,
      remark,
      createdBy,
      ...spareDetails
    } = createSpareDto;

    const ship = await this.shipValidationService.getShipById(shipId);

    if (!ship) {
      throw new NotFoundException(`Ship with ID ${shipId} not found`);
    }

    const mainPart = await this.mainPartRepository.findOne({
      where: { id: mainPartId, ship: ship },
    });
    if (!mainPart) {
      throw new NotFoundException(
        `MainPart with ID ${mainPartId} not found for ship ${shipId}`,
      );
    }

    const spare = this.spareRepository.create({
      ...spareDetails,
      rob,
      createdBy,
      ship,
      mainPart,
    });
    const savedSpare = await this.spareRepository.save(spare);

    if (rob !== undefined) {
      const initialTransaction = new SpareTransaction();
      initialTransaction.spare = savedSpare;
      initialTransaction.quantity = rob; // Initial ROB is treated as the initial quantity
      initialTransaction.reason = reason || TransactionReason.PURCHASE; // Default reason if not provided
      initialTransaction.remark = remark || 'Initial stock';
      initialTransaction.updatedBy = createdBy || 'CE';
      await this.spareTransactionRepository.save(initialTransaction);
    }
    delete savedSpare.ship;
    return savedSpare;
  }

  async getSparesByShipId(
    shipId: number,
    page: number,
    limit: number,
    search?: string,
  ): Promise<{
    data: SpareEntity[];
    total: number;
    page: number;
    limit: number;
  }> {
    const ship = await this.shipValidationService.getShipById(shipId);

    const queryBuilder = this.spareRepository
      .createQueryBuilder('spare')
      .leftJoinAndSelect('spare.mainPart', 'mainPart')
      .where('spare.ship_id = :shipId', { shipId: ship.id });

    // Search filter for description and partNumber
    if (search) {
      queryBuilder.andWhere(
        '(spare.description ILIKE :search OR spare.partNumber ILIKE :search)',
        { search: `%${search}%` },
      );
    }

    // Pagination
    const [data, total] = await queryBuilder
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return {
      data,
      total,
      page,
      limit,
    };
  }

  async updateSpare(
    id: number,
    updateSpareDto: UpdateSpareDto,
  ): Promise<SpareEntity> {
    const {
      shipId,
      mainPartId,
      rob,
      reason,
      remark,
      updatedBy,
      ...spareUpdates
    } = updateSpareDto;

    const spare = await this.spareRepository.findOne({
      where: { id },
      relations: ['ship', 'mainPart'],
    });
    if (!spare) {
      throw new NotFoundException(`Spare with ID ${id} not found`);
    }

    if (shipId && spare.ship.id !== shipId) {
      const ship = await this.shipRepository.findOne({ where: { id: shipId } });
      if (!ship) {
        throw new NotFoundException(`Ship with ID ${shipId} not found`);
      }
      spare.ship = ship;
    }

    if (mainPartId && (!spare.mainPart || spare.mainPart.id !== mainPartId)) {
      const mainPart = await this.mainPartRepository.findOne({
        where: { id: mainPartId },
      });
      if (!mainPart) {
        throw new NotFoundException(`MainPart with ID ${mainPartId} not found`);
      }
      spare.mainPart = mainPart;
    }

    if (rob !== undefined && spare.rob !== rob) {
      const quantityDifference = rob - (spare.rob || 0);
      const transaction = new SpareTransaction();
      transaction.spare = spare;
      transaction.quantity = quantityDifference;
      transaction.reason = reason;
      transaction.remark = remark || 'Updated stock level';
      transaction.updatedBy = updatedBy || 'CE';
      await this.spareTransactionRepository.save(transaction);

      // Update ROB in spare entity
      spare.rob = rob;
      spare.updatedBy = updatedBy || 'CE';
    }

    Object.assign(spare, spareUpdates);
    return this.spareRepository.save(spare);
  }

  async getSpareById(id: number): Promise<SpareEntity> {
    const spare = await this.spareRepository.findOne({
      where: { id },
      relations: ['ship', 'mainPart'],
    });

    if (!spare) {
      throw new NotFoundException(`Spare with ID ${id} not found`);
    }

    return spare;
  }

  async getSpareHistory(spareId: number): Promise<SpareTransaction[]> {
    // Check if the spare part exists
    const spare = await this.spareRepository.findOne({
      where: { id: spareId },
    });
    if (!spare) {
      throw new NotFoundException(`Spare with ID ${spareId} not found`);
    }

    // Fetch the transaction history for the spare part
    return this.spareTransactionRepository.find({
      where: { spare: { id: spareId } },
      order: { updatedOn: 'DESC' },
    });
  }

  async getSparesByMainPartAndShip(
    shipId: number,
    mainPartId?: number,
  ): Promise<SpareEntity[]> {
    const whereCondition: any = { ship: { id: shipId } };
    if (mainPartId) {
      whereCondition.mainPart = { id: mainPartId };
    }
    const spares = await this.spareRepository.find({
      where: whereCondition,
      relations: ['mainPart'],
    });

    if (!spares || spares.length === 0) {
      throw new NotFoundException(
        `No spares found for mainPartId ${mainPartId} and shipId ${shipId}`,
      );
    }

    // Optionally remove ship details if they are not required in the response
    spares.forEach((spare) => delete spare.ship);

    return spares;
  }

  async searchSparesByMainPartAndShip(
    shipId: number,
    mainPartId: number,
    searchQuery: string,
  ): Promise<SpareEntity[]> {
    // QueryBuilder for complex search
    const queryBuilder = this.spareRepository
      .createQueryBuilder('spare')
      .leftJoinAndSelect('spare.mainPart', 'mainPart')
      .leftJoinAndSelect('spare.ship', 'ship')
      .where('ship.id = :shipId', { shipId })
      .andWhere('mainPart.id = :mainPartId', { mainPartId })
      .andWhere('spare.type = :type', { type: 'spare' })
      .andWhere('spare.description ILIKE :searchQuery', {
        searchQuery: `%${searchQuery}%`, // Case-insensitive search
      });

    const spares = await queryBuilder.getMany();

    if (!spares || spares.length === 0) {
      console.log(
        `No spares found for shipId=${shipId}, mainPartId=${mainPartId}, and query=${searchQuery}`,
      );
      return [];
    }

    // Optionally clean up unnecessary data
    spares.forEach((spare) => delete spare.ship);

    return spares;
  }

  async searchStoreByShip(
    shipId: number,
    searchQuery: string,
  ): Promise<SpareEntity[]> {
    // QueryBuilder for gstore search
    const queryBuilder = this.spareRepository
      .createQueryBuilder('spare')
      .leftJoinAndSelect('spare.ship', 'ship')
      .where('ship.id = :shipId', { shipId })
      .andWhere('spare.type = :type', { type: 'store' }) // Filter by type gstore
      .andWhere('spare.description ILIKE :searchQuery', {
        searchQuery: `%${searchQuery}%`, // Case-insensitive search
      });

    const gstoreItems = await queryBuilder.getMany();

    if (!gstoreItems || gstoreItems.length === 0) {
      console.log(
        `No gstore items found for shipId=${shipId} and query=${searchQuery}`,
      );
      return [];
    }

    // Optionally clean up unnecessary data
    gstoreItems.forEach((item) => delete item.ship);

    return gstoreItems;
  }
}
