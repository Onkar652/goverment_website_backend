import { PartialType, ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';
import { CreateSpareDto } from './create-spare.dto';

export class UpdateSpareDto extends PartialType(CreateSpareDto) {
  @ApiProperty({
    example: 'John Doe',
    description: 'Name of the user who created the record',
    required: false,
  })
  @IsOptional()
  @IsString()
  updatedBy?: string;
}
