// create-spare.dto.ts
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNumber, IsOptional, IsString } from 'class-validator';
import { TransactionReason } from 'src/entities/inventory/spare-transaction.entity';
import { SpareCategory } from 'src/utils/models/common.types';

export class CreateSpareDto {
  @ApiProperty({
    example: 1,
    description: 'ID of the ship associated with the spare part',
  })
  @IsNumber()
  shipId: number;

  @ApiProperty({
    example: 'Spare part description',
    description: 'Description of the spare part',
  })
  @IsString()
  description: string;

  @ApiProperty({
    example: 'MKR123',
    description: 'Reference of the maker',
    required: false,
  })
  @IsOptional()
  @IsString()
  makerRef?: string;

  @ApiProperty({
    example: 'DRW456',
    description: 'Drawing number associated with the spare part',
    required: false,
  })
  @IsOptional()
  @IsString()
  drawingNo?: string;

  @ApiProperty({
    example: 'POS789',
    description: 'Position number of the spare part',
    required: false,
  })
  @IsOptional()
  @IsString()
  positionNo?: string;

  @ApiProperty({
    example: 'Maker Inc.',
    description: 'Name of the maker',
    required: false,
  })
  @IsOptional()
  @IsString()
  makerName?: string;

  @ApiProperty({
    example: 'Model XYZ',
    description: 'Model name of the spare part',
    required: false,
  })
  @IsOptional()
  @IsString()
  modelName?: string;

  @ApiProperty({
    example: 5,
    description: 'Minimum level for the spare part stock',
    required: false,
  })
  @IsOptional()
  @IsNumber()
  minimumLevel?: number;

  @ApiProperty({
    example: 10,
    description: 'Remaining On Board (ROB) quantity of the spare part',
  })
  @IsNumber()
  rob: number;

  @ApiProperty({
    example: 'pcs',
    description: 'Unit of measure for the spare part',
    required: false,
  })
  @IsOptional()
  @IsString()
  unitOfMeasure?: string;

  @ApiProperty({
    example: SpareCategory.NORMAL,
    description: 'Category of the spare part',
    enum: SpareCategory,
    default: SpareCategory.NORMAL,
  })
  @IsEnum(SpareCategory)
  category: SpareCategory;

  @ApiProperty({
    example: 'John Doe',
    description: 'Name of the user who created the record',
    required: false,
  })
  @IsOptional()
  @IsString()
  createdBy?: string;

  @ApiProperty({
    example: 1,
    description: 'ID of the main part associated with the spare part',
  })
  @IsNumber()
  mainPartId: number;

  @IsEnum(TransactionReason)
  reason: TransactionReason;

  @IsOptional()
  @IsString()
  remark?: string;
}
