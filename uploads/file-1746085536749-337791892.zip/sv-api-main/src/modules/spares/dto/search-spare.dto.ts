import { IsNumber, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class SearchSparesDto {
  @ApiProperty({ description: 'ID of the ship' })
  @IsNumber()
  shipId: number;

  @ApiProperty({ description: 'ID of the main part' })
  @IsNumber()
  mainPartId: number;

  @ApiProperty({ description: 'Search term for the description' })
  @IsString()
  query: string;
}

export class SearchGstoreDto {
  @ApiProperty({ description: 'ID of the ship' })
  @IsNumber()
  shipId: number;

  @ApiProperty({ description: 'Search term for the description' })
  @IsString()
  query: string;
}
