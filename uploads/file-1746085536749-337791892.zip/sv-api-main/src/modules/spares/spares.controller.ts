import {
  Body,
  Controller,
  Get,
  NotFoundException,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { SparesService } from './spares.service';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiQuery,
  ApiBody,
} from '@nestjs/swagger';
import { SpareEntity } from 'src/entities/inventory/spares.entity';
import { CreateSpareDto } from './dto/create-spare.dto';
import { UpdateSpareDto } from './dto/update-spare.dto';
import { SearchGstoreDto, SearchSparesDto } from './dto/search-spare.dto';

@ApiTags('Spares')
@Controller('spares')
export class SparesController {
  constructor(private readonly sparesService: SparesService) {}

  @Post()
  @ApiOperation({ summary: 'Add a new spare part' })
  @ApiResponse({
    status: 201,
    description: 'Spare part created successfully',
    type: SpareEntity,
  })
  @ApiResponse({ status: 400, description: 'Invalid input' })
  async addSpare(@Body() createSpareDto: CreateSpareDto): Promise<SpareEntity> {
    return await this.sparesService.createSpare(createSpareDto);
  }

  @Get('/byship/:shipId')
  @ApiOperation({
    summary: 'Get all spare parts for a ship with pagination and search',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    type: Number,
    description: 'Page number (default: 1)',
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    description: 'Items per page (default: 10)',
  })
  @ApiQuery({
    name: 'search',
    required: false,
    type: String,
    description: 'Search by description or part number',
  })
  @ApiResponse({
    status: 200,
    description: 'List of spare parts with pagination',
    type: [SpareEntity],
  })
  async getSparesByShipId(
    @Param('shipId', ParseIntPipe) shipId: number,
    @Query('page') page = 1,
    @Query('limit') limit = 10,
    @Query('search') search?: string,
  ): Promise<{
    data: SpareEntity[];
    total: number;
    page: number;
    limit: number;
  }> {
    return await this.sparesService.getSparesByShipId(
      shipId,
      page,
      limit,
      search,
    );
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update an existing spare part' })
  @ApiResponse({
    status: 200,
    description: 'Spare part updated successfully',
    type: SpareEntity,
  })
  @ApiResponse({ status: 404, description: 'Spare part not found' })
  async updateSpare(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateSpareDto: UpdateSpareDto,
  ): Promise<SpareEntity> {
    return await this.sparesService.updateSpare(id, updateSpareDto);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get spare details by ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the spare part to retrieve',
    example: 1,
  })
  @ApiResponse({
    status: 200,
    description: 'Returns the spare part details',
    type: SpareEntity,
  })
  @ApiResponse({
    status: 404,
    description: 'Spare not found',
  })
  async getSpareById(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<SpareEntity> {
    return this.sparesService.getSpareById(id);
  }

  @Get(':id/history')
  @ApiOperation({ summary: 'Get transaction history by spare ID' })
  @ApiResponse({
    status: 200,
    description: 'Transaction history retrieved successfully',
  })
  @ApiResponse({
    status: 404,
    description: 'Spare part not found or no transaction history available',
  })
  async getSpareHistory(@Param('id') id: number) {
    const history = await this.sparesService.getSpareHistory(id);
    if (!history || history.length === 0) {
      throw new NotFoundException(
        `No transaction history found for spare with ID ${id}`,
      );
    }
    return history;
  }

  @Get('/by-main-part/:shipId')
  @ApiOperation({
    summary: 'Get spares by shipId and optionally filter by mainPartId',
    description:
      'Fetches spares for a specific ship, and optionally filters by mainPartId as a query parameter',
  })
  @ApiParam({
    name: 'shipId',
    description: 'ID of the ship',
    type: Number,
  })
  @ApiQuery({
    name: 'mainPartId',
    description: 'ID of the main part (optional)',
    type: Number,
    required: false,
  })
  @ApiResponse({
    status: 200,
    description:
      'List of spares for the specified ship and optionally main part',
    type: [SpareEntity],
  })
  @ApiResponse({
    status: 404,
    description: 'No spares found for the given criteria',
  })
  async getSparesByMainPartAndShip(
    @Param('shipId', ParseIntPipe) shipId: number,
    @Query('mainPartId') mainPartId?: number,
  ): Promise<SpareEntity[]> {
    const spares = await this.sparesService.getSparesByMainPartAndShip(
      shipId,
      mainPartId ? +mainPartId : undefined,
    );
    return spares;
  }

  @Post('/search-by-main-part')
  @ApiOperation({
    summary: 'Search spares by ship, main part, and description',
  })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        shipId: { type: 'number', description: 'ID of the ship' },
        mainPartId: { type: 'number', description: 'ID of the main part' },
        query: {
          type: 'string',
          description: 'Search term for the description',
        },
      },
      required: ['shipId', 'mainPartId', 'query'],
    },
  })
  async searchSparesByMainPartAndShip(
    @Body() searchDto: SearchSparesDto,
  ): Promise<SpareEntity[]> {
    return this.sparesService.searchSparesByMainPartAndShip(
      searchDto.shipId,
      searchDto.mainPartId,
      searchDto.query,
    );
  }

  @Post('/search-store')
  @ApiOperation({ summary: 'Search gstore items by ship and description' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        shipId: { type: 'number', description: 'ID of the ship' },
        query: {
          type: 'string',
          description: 'Search term for the description',
        },
      },
      required: ['shipId', 'query'],
    },
  })
  async searchStoreByShip(
    @Body() searchDto: SearchGstoreDto,
  ): Promise<SpareEntity[]> {
    return this.sparesService.searchStoreByShip(
      searchDto.shipId,
      searchDto.query,
    );
  }
}
