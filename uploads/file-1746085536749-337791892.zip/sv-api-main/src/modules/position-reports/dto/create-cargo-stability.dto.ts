import { IsNumber, IsOptional } from 'class-validator';

export class CreateCargoStabilityDto {
  @IsOptional()
  @IsNumber()
  displacement?: number;

  @IsOptional()
  @IsNumber()
  gm?: number;

  @IsOptional()
  @IsNumber()
  draft_fwd?: number;

  @IsOptional()
  @IsNumber()
  draft_aft?: number;

  @IsOptional()
  @IsNumber()
  containerCount?: number;

  @IsOptional()
  @IsNumber()
  referContainers?: number;
}
