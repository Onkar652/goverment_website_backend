import {
  IsNotEmpty,
  IsString,
  IsOptional,
  IsNumber,
  IsDateString,
  ValidateNested,
  IsBoolean,
  IsArray,
  Matches,
} from 'class-validator';
import { Type } from 'class-transformer';
import { CreateCargoStabilityDto } from './create-cargo-stability.dto';
import { CreateEngineDataDto } from './create-engine-data.dto';
import { CreateSpeedDistanceWeatherDto } from './create-speed-distance-weather.dto';
import { CreateCargoDetailsDto } from './create-cargo-details.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreatePositionBookReportDto {
  @ApiProperty({ example: '12345' })
  @IsNotEmpty()
  @IsString()
  reportId: string;

  @ApiProperty({ example: 1 })
  @IsNotEmpty()
  @IsNumber()
  shipId: number;

  @ApiProperty({
    description: 'The date of the report in ISO format (YYYY-MM-DD)',
    example: '2025-01-11',
  })
  @IsDateString(
    { strict: true },
    { message: 'reportDate must be a valid ISO date string (YYYY-MM-DD).' },
  )
  reportDate: string;

  @ApiProperty({
    description:
      'The time of the report in HHmm format (e.g., 2130 for 9:30 PM)',
    example: '2130',
  })
  @IsString()
  @Matches(/^\d{4}$/, { message: 'Time must be in HHmm format (e.g., 2130).' })
  reportTime: string;

  @ApiProperty({ example: 'Daily Report' })
  @IsNotEmpty()
  @IsString()
  report_name: string;

  @ApiProperty({ example: 'UTC+1' })
  @IsNotEmpty()
  @IsString()
  timezone: string;

  @ApiProperty({ example: 'Port A' })
  @IsNotEmpty()
  @IsString()
  from_port: string;

  @ApiProperty({ example: 'Port B' })
  @IsNotEmpty()
  @IsString()
  to_port: string;

  @ApiPropertyOptional({ example: 'Berth 1' })
  @IsOptional()
  @IsString()
  berth?: string;

  @ApiPropertyOptional({ example: 'Docked' })
  @IsOptional()
  @IsString()
  vessel_location?: string;

  @ApiPropertyOptional({ example: '12.3456' })
  @IsOptional()
  @IsString()
  latitude?: string;

  @ApiPropertyOptional({ example: '65.4321' })
  @IsOptional()
  @IsString()
  longitude?: string;

  @ApiPropertyOptional({ example: true })
  @IsOptional()
  @IsBoolean()
  isShore?: boolean;

  @ApiPropertyOptional({ example: 'In Transit' })
  @IsOptional()
  @IsString()
  status?: string;

  @ApiPropertyOptional({ example: 'No issues' })
  @IsOptional()
  @IsString()
  remarks?: string;

  @ApiPropertyOptional({
    type: () => CreateSpeedDistanceWeatherDto,
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => CreateSpeedDistanceWeatherDto)
  speedDistanceWeather?: CreateSpeedDistanceWeatherDto;

  @ApiPropertyOptional({ type: () => CreateEngineDataDto })
  @IsOptional()
  @ValidateNested()
  @Type(() => CreateEngineDataDto)
  engineData?: CreateEngineDataDto;

  @ApiPropertyOptional({ type: () => CreateCargoStabilityDto })
  @IsOptional()
  @ValidateNested()
  @Type(() => CreateCargoStabilityDto)
  cargoStability?: CreateCargoStabilityDto;

  @ApiPropertyOptional({ type: [CreateCargoDetailsDto] })
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => CreateCargoDetailsDto)
  @IsArray()
  cargoDetails?: CreateCargoDetailsDto[];
}
