import { IsNotEmpty, IsOptional, IsString, IsNumber } from 'class-validator';

export class CreateCargoDetailsDto {
  @IsNotEmpty()
  @IsString()
  cargoName: string;

  @IsNotEmpty()
  @IsString()
  storageUnitName: string;

  @IsNotEmpty()
  @IsNumber()
  maximumCapacity: number;

  @IsOptional()
  @IsNumber()
  initialQuantity?: number;

  @IsOptional()
  @IsNumber()
  loaded?: number;

  @IsOptional()
  @IsNumber()
  discharged?: number;

  @IsOptional()
  @IsNumber()
  totalCargo?: number;
}
