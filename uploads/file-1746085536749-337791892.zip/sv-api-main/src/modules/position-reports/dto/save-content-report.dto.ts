import {
  IsArray,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export enum ReportStatus {
  DRAFT = 'draft',
  APPROVED = 'approved',
}
class TankConsumptionDto {
  @ApiProperty({
    description: 'Unique code for the tank',
    example: 'TANK001',
  })
  @IsNotEmpty()
  @IsString()
  tankCode: string;

  @ApiProperty({
    description: 'Opening ROB of the tank',
    example: 100,
  })
  @IsNotEmpty()
  @IsNumber()
  openingROB: number;

  @ApiProperty({
    description: 'Closing ROB of the tank',
    example: 80,
  })
  @IsNotEmpty()
  @IsNumber()
  closingROB: number;

  @ApiProperty({
    description: 'Comments related to the tank consumption',
    example: 'Tank used during voyage.',
    required: false,
  })
  @IsString()
  @IsOptional()
  comments?: string;
}

class EquipmentConsumptionDto {
  @ApiProperty({
    description: 'ID of the equipment',
    example: 1,
  })
  @IsNotEmpty()
  @IsNumber()
  equipmentId: number;

  @ApiProperty({
    description: 'Amount of fuel consumed by the equipment',
    example: 20,
  })
  @IsNotEmpty()
  @IsNumber()
  consumptionAmount: number;

  @ApiProperty({
    description: 'Comments related to the equipment consumption',
    example: 'Main engine consumption.',
    required: false,
  })
  @IsString()
  @IsOptional()
  comments?: string;
}

export class ContentConsumptionDto {
  @ApiProperty({
    description: 'Unique code for the content (e.g., fuel, lube, water)',
    example: 'FUEL001',
  })
  @IsNotEmpty()
  @IsString()
  contentCode: string;

  @ApiProperty({
    description: 'List of tank consumption details',
    type: [TankConsumptionDto],
  })
  @ValidateNested({ each: true })
  @Type(() => TankConsumptionDto)
  @IsArray()
  tankConsumptions: TankConsumptionDto[];

  @ApiProperty({
    description: 'List of equipment consumption details',
    type: [EquipmentConsumptionDto],
  })
  @ValidateNested({ each: true })
  @Type(() => EquipmentConsumptionDto)
  @IsArray()
  equipmentConsumptions: EquipmentConsumptionDto[];
}

export class SaveContentReportDto {
  @ApiProperty({
    description: 'ID of the position book report',
    example: 'REPORT123',
  })
  @IsNotEmpty()
  @IsString()
  reportId: string;

  @ApiProperty({
    description: 'Status of the report',
    example: ReportStatus.DRAFT,
    enum: ReportStatus, // Enum with possible values
  })
  @IsNotEmpty()
  @IsEnum(ReportStatus, {
    message: 'Status must be either "draft" or "approved".',
  })
  status: ReportStatus;

  @ApiProperty({
    description: 'List of content consumptions to be saved',
    type: [ContentConsumptionDto],
  })
  @ValidateNested({ each: true })
  @Type(() => ContentConsumptionDto)
  @IsArray()
  contentConsumptions: ContentConsumptionDto[];
}
