import { IsOptional, IsString, IsNumber } from 'class-validator';

export class CreateSpeedDistanceWeatherDto {
  @IsOptional()
  @IsString()
  trueCourse?: string;

  @IsOptional()
  @IsNumber()
  engine_distance?: number;

  @IsOptional()
  @IsNumber()
  observed_distance?: number;

  @IsOptional()
  @IsNumber()
  steaming_time?: number;

  @IsOptional()
  @IsNumber()
  time_spent_at_anchorage?: number;

  @IsOptional()
  @IsNumber()
  speed?: number;

  @IsOptional()
  @IsNumber()
  slip?: number;

  @IsOptional()
  @IsNumber()
  distance_to_go?: number;

  @IsOptional()
  @IsNumber()
  distanceTraveled?: number;

  @IsOptional()
  @IsString()
  windDirection?: string;

  @IsOptional()
  @IsNumber()
  windForce?: number;

  @IsOptional()
  @IsString()
  true_wind?: string;

  @IsOptional()
  @IsString()
  weatherCondition?: string;

  @IsOptional()
  @IsString()
  swell_direction?: string;

  @IsOptional()
  @IsString()
  swell_height?: string;

  @IsOptional()
  @IsString()
  visibility?: string;
}
