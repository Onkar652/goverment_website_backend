import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsNumber, IsOptional } from 'class-validator';

export class CreateEngineDataDto {
  @ApiPropertyOptional({ description: 'RPM of Main Engine 1', example: 85 })
  @IsOptional()
  @IsNumber()
  me1_rpm?: number;

  @ApiPropertyOptional({ description: 'RPM of Main Engine 2', example: 80 })
  @IsOptional()
  @IsNumber()
  me2_rpm?: number;

  @ApiPropertyOptional({
    description: 'RPM of Main Engine Turbocharger 1',
    example: 12000,
  })
  @IsOptional()
  @IsNumber()
  me_tc1_rpm?: number;

  @ApiPropertyOptional({
    description: 'RPM of Main Engine Turbocharger 2',
    example: 11500,
  })
  @IsOptional()
  @IsNumber()
  me_tc2_rpm?: number;

  @ApiPropertyOptional({
    description: 'RPM of Main Engine Turbocharger 3',
    example: 11800,
  })
  @IsOptional()
  @IsNumber()
  me_tc3_rpm?: number;

  @ApiPropertyOptional({
    description: 'RPM of Main Engine Turbocharger 4',
    example: 12200,
  })
  @IsOptional()
  @IsNumber()
  me_tc4_rpm?: number;

  @ApiPropertyOptional({
    description: 'Maximum exhaust temperature',
    example: 450,
  })
  @IsOptional()
  @IsNumber()
  exhaust_max_temp?: number;

  @ApiPropertyOptional({
    description: 'Minimum exhaust temperature',
    example: 250,
  })
  @IsOptional()
  @IsNumber()
  exhaust_min_temp?: number;

  @ApiPropertyOptional({ description: 'Actual Main Engine MCR', example: 85 })
  @IsOptional()
  @IsNumber()
  actual_mcr?: number;

  @ApiPropertyOptional({ description: 'Actual RPM', example: 90 })
  @IsOptional()
  @IsNumber()
  actual_rpm?: number;

  @ApiPropertyOptional({
    description: 'Main Engine Daily Running Hours',
    example: 24,
  })
  @IsOptional()
  @IsNumber()
  me_daily_rh?: number;

  @ApiPropertyOptional({
    description: 'Main Engine Output by Fuel Oil Consumption',
    example: 85.5,
  })
  @IsOptional()
  @IsNumber()
  me_output_by_foc?: number;

  @ApiPropertyOptional({ description: 'Adjusted Speed', example: 14.5 })
  @IsOptional()
  @IsNumber()
  speed_adjusted?: number;

  @ApiPropertyOptional({ description: 'Thermal Load', example: 75 })
  @IsOptional()
  @IsNumber()
  thermal_load?: number;

  @ApiPropertyOptional({
    description: 'Quantity of ballast water',
    example: 1200,
  })
  @IsOptional()
  @IsNumber()
  ballas_water_quantity?: number;

  @ApiPropertyOptional({ description: 'Scavenge Pressure', example: 1.8 })
  @IsOptional()
  @IsNumber()
  scavenge_pressure?: number;

  @ApiPropertyOptional({ description: 'Main Engine Output', example: 90 })
  @IsOptional()
  @IsNumber()
  me_output?: number;

  @ApiPropertyOptional({
    description: 'Running hours of Auxiliary Engine 1',
    example: 12,
  })
  @IsOptional()
  @IsNumber()
  ae1_rh?: number;

  @ApiPropertyOptional({
    description: 'Running hours of Auxiliary Engine 2',
    example: 10,
  })
  @IsOptional()
  @IsNumber()
  ae2_rh?: number;

  @ApiPropertyOptional({
    description: 'Running hours of Auxiliary Engine 3',
    example: 8,
  })
  @IsOptional()
  @IsNumber()
  ae3_rh?: number;
}
