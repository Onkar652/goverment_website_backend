import { Module } from '@nestjs/common';
import { PositionReportsService } from './position-reports.service';
import { PositionReportsController } from './position-reports.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CargoStabilityEntity } from 'src/entities/postion-book-reports/cargo-stability.entity';
import { CargoDetailsEntity } from 'src/entities/postion-book-reports/cargo_details.entity';
import { EngineDataEntity } from 'src/entities/postion-book-reports/engine-data.entity';
import { PositionBookReportEntity } from 'src/entities/postion-book-reports/postion-report.entity';
import { SpeedDistanceWeatherEntity } from 'src/entities/postion-book-reports/speed-distance-weather.entity';
import { VoyageEntity } from 'src/entities/voyage/voyage.entity';
import { ShipValidationService } from '../common/ship-validation.service';
import { TankConfigurationEntity } from 'src/entities/tank-config/tank-config.entity';
import { ROBTrackingEntity } from 'src/entities/tank-config/rob-tank-tracking.entity';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { ContentEntity } from 'src/entities/tank-config/content.entity';
import { MainPart } from 'src/entities/shipParts/main-parts.entity';
import { ContentROBTrackingEntity } from 'src/entities/tank-config/content-rob-tracking.entity';
import { MainPartContentConsumptionEntity } from 'src/entities/tank-config/main-part-consumption.entity';
import { ActiveEventReportEntity } from 'src/entities/postion-book-reports/active-event-reports.entity';
import { TimezoneEntity } from 'src/entities/master-configs/timezone.entity';
import { ItineraryPortEntity } from 'src/entities/voyage/itinerary-port.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      PositionBookReportEntity,
      VoyageEntity,
      SpeedDistanceWeatherEntity,
      EngineDataEntity,
      CargoStabilityEntity,
      CargoDetailsEntity,
      TankConfigurationEntity,
      ROBTrackingEntity,
      FileStorageEntity,
      ContentEntity,
      ContentROBTrackingEntity,
      MainPart,
      MainPartContentConsumptionEntity,
      ActiveEventReportEntity,
      TimezoneEntity,
      ItineraryPortEntity,
    ]),
  ],
  controllers: [PositionReportsController],
  providers: [PositionReportsService, ShipValidationService],
})
export class PositionReportsModule {}
