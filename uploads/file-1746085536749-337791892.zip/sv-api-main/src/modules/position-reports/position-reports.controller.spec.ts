import { Test, TestingModule } from '@nestjs/testing';
import { PositionReportsController } from './position-reports.controller';
import { PositionReportsService } from './position-reports.service';

describe('PositionReportsController', () => {
  let controller: PositionReportsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PositionReportsController],
      providers: [PositionReportsService],
    }).compile();

    controller = module.get<PositionReportsController>(PositionReportsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
