import { Test, TestingModule } from '@nestjs/testing';
import { PositionReportsService } from './position-reports.service';

describe('PositionReportsService', () => {
  let service: PositionReportsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PositionReportsService],
    }).compile();

    service = module.get<PositionReportsService>(PositionReportsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
