import {
  Body,
  Controller,
  Get,
  Param,
  ParseIntPipe,
  Post,
  Query,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import {
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { PositionBookReportEntity } from 'src/entities/postion-book-reports/postion-report.entity';
import { CreatePositionBookReportDto } from './dto/create-pbook.dto';
import { InitiatePositionBookReportDto } from './dto/postion-book-initiate.dto';
import { PositionReportsService } from './position-reports.service';
import { SaveContentReportDto } from './dto/save-content-report.dto';
import { ActiveEventReportEntity } from 'src/entities/postion-book-reports/active-event-reports.entity';

@ApiTags('Position Book Reports')
@Controller('position-reports')
export class PositionReportsController {
  constructor(
    private readonly positionReportsService: PositionReportsService,
  ) {}

  @Post()
  @ApiOperation({ summary: 'Update a Position Book Report' })
  @ApiResponse({
    status: 201,
    description: 'Position book report created successfully.',
  })
  @ApiBody({
    description: 'The data to create a Position Book Report',
    type: CreatePositionBookReportDto, // Ensure this points to your DTO class
  })
  async createPositionBookReport(
    @Body() createReportDto: CreatePositionBookReportDto,
  ): Promise<PositionBookReportEntity> {
    return await this.positionReportsService.createPositionBookReport(
      createReportDto,
    );
  }

  @Get(':reportId')
  @ApiOperation({ summary: 'Get a Position Book Report by ID' })
  @ApiResponse({
    status: 200,
    description: 'Position book report retrieved successfully.',
  })
  async getPositionBookReportById(
    @Param('reportId') reportId: string,
  ): Promise<PositionBookReportEntity> {
    return await this.positionReportsService.getPositionBookReportById(
      reportId,
    );
  }

  @Post('/initiate')
  @ApiOperation({ summary: 'Initiate a position book report' })
  @ApiResponse({ status: 201, description: 'Report initiated successfully.' })
  @ApiBody({ type: InitiatePositionBookReportDto })
  async initiateReport(
    @Body() initiateReportDto: InitiatePositionBookReportDto,
  ): Promise<PositionBookReportEntity> {
    return await this.positionReportsService.initiatePositionBookReport(
      initiateReportDto,
    );
  }

  @Post(':reportId/cargo/documents')
  @ApiOperation({
    summary: 'Upload documents for Cargo Stability by Report ID',
  })
  @ApiConsumes('multipart/form-data')
  @ApiResponse({
    status: 201,
    description: 'Documents uploaded successfully.',
  })
  @ApiBody({
    description: 'File upload',
    required: true,
    schema: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  @UseInterceptors(FilesInterceptor('files'))
  async uploadDocumentsByReportId(
    @Param('reportId') reportId: string,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<{ message: string }> {
    await this.positionReportsService.uploadDocumentsByReportId(
      reportId,
      files,
    );
    return { message: 'Documents uploaded successfully' };
  }

  @Get('ship/:shipId')
  @ApiOperation({
    summary: 'Get all reports by Ship ID with pagination & search',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    type: Number,
    description: 'Page number (default: 1)',
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    description: 'Items per page (default: 10)',
  })
  @ApiQuery({
    name: 'search',
    required: false,
    type: String,
    description: 'Search by reportId or report_name',
  })
  @ApiQuery({
    name: 'status',
    required: false,
    type: String,
    description: 'Filter by status (e.g., draft, submitted, completed)',
  })
  @ApiResponse({
    status: 200,
    description:
      'List of position book reports for the specified ship with pagination',
    type: [PositionBookReportEntity],
  })
  async getReportsByShipId(
    @Param('shipId', ParseIntPipe) shipId: number,
    @Query('status') status?: string,
    @Query('search') search?: string,
    @Query('page') page = 1,
    @Query('limit') limit = 10,
  ): Promise<{
    data: PositionBookReportEntity[];
    total: number;
    page: number;
    limit: number;
  }> {
    return await this.positionReportsService.getReportsByShipId(
      shipId,
      status,
      search,
      page,
      limit,
    );
  }

  @Get('content-reporting/:shipId')
  @ApiOperation({ summary: 'Get Content Reporting Data' })
  @ApiResponse({
    status: 200,
    description: 'Content reporting data fetched successfully.',
  })
  async getContentReporting(@Param('shipId') shipId: number): Promise<any> {
    return await this.positionReportsService.getContentReporting(shipId);
  }

  @Post('/save-content-report')
  @ApiOperation({ summary: 'Save Content Report' })
  @ApiResponse({
    status: 201,
    description: 'Content report saved successfully.',
    schema: {
      type: 'object',
      properties: {
        message: {
          type: 'string',
          example: 'Content report saved successfully.',
        },
      },
    },
  })
  async saveContentReport(
    @Body() saveContentReportDto: SaveContentReportDto,
  ): Promise<{ message: string }> {
    return await this.positionReportsService.saveContentReport(
      saveContentReportDto,
    );
  }

  @Get('tracking/:shipId')
  @ApiOperation({ summary: 'Get Report Tracking for a Ship' })
  @ApiParam({ name: 'shipId', type: Number, description: 'ID of the ship' })
  @ApiResponse({
    status: 200,
    description: 'List of active event reports',
    type: ActiveEventReportEntity,
    isArray: true,
  })
  @ApiResponse({ status: 404, description: 'Ship not found' })
  async getReportTracking(
    @Param('shipId', ParseIntPipe) shipId: number,
  ): Promise<ActiveEventReportEntity[]> {
    return this.positionReportsService.getReportTracking(shipId);
  }
}
