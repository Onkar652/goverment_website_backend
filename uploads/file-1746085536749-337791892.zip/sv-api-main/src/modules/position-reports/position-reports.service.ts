import {
  BadRequestException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { CargoStabilityEntity } from 'src/entities/postion-book-reports/cargo-stability.entity';
import { CargoDetailsEntity } from 'src/entities/postion-book-reports/cargo_details.entity';
import { EngineDataEntity } from 'src/entities/postion-book-reports/engine-data.entity';
import { PositionBookReportEntity } from 'src/entities/postion-book-reports/postion-report.entity';
import { SpeedDistanceWeatherEntity } from 'src/entities/postion-book-reports/speed-distance-weather.entity';
import { ContentEntity } from 'src/entities/tank-config/content.entity';
import { ROBTrackingEntity } from 'src/entities/tank-config/rob-tank-tracking.entity';
import { TankConfigurationEntity } from 'src/entities/tank-config/tank-config.entity';
import { VoyageEntity } from 'src/entities/voyage/voyage.entity';
import { Repository } from 'typeorm';
import { ShipValidationService } from '../common/ship-validation.service';
import { CreatePositionBookReportDto } from './dto/create-pbook.dto';
import { InitiatePositionBookReportDto } from './dto/postion-book-initiate.dto';
import {
  ContentConsumptionDto,
  SaveContentReportDto,
} from './dto/save-content-report.dto';
import { MainPart } from 'src/entities/shipParts/main-parts.entity';
import { ContentROBTrackingEntity } from 'src/entities/tank-config/content-rob-tracking.entity';
import { MainPartContentConsumptionEntity } from 'src/entities/tank-config/main-part-consumption.entity';
import { TimezoneEntity } from 'src/entities/master-configs/timezone.entity';
import { ActiveEventReportEntity } from 'src/entities/postion-book-reports/active-event-reports.entity';
import * as moment from 'moment';
import { ItineraryPortEntity } from 'src/entities/voyage/itinerary-port.entity';

@Injectable()
export class PositionReportsService {
  private readonly logger = new Logger(PositionReportsService.name);
  constructor(
    @InjectRepository(PositionBookReportEntity)
    private readonly positionBookReportRepository: Repository<PositionBookReportEntity>,

    @InjectRepository(SpeedDistanceWeatherEntity)
    private readonly speedDistanceWeatherRepository: Repository<SpeedDistanceWeatherEntity>,
    @InjectRepository(EngineDataEntity)
    private readonly engineDataRepository: Repository<EngineDataEntity>,
    @InjectRepository(CargoStabilityEntity)
    private readonly cargoStabilityRepository: Repository<CargoStabilityEntity>,
    @InjectRepository(CargoDetailsEntity)
    private readonly cargoDetailsRepository: Repository<CargoDetailsEntity>,
    @InjectRepository(VoyageEntity)
    private readonly voyageRepository: Repository<VoyageEntity>,
    @InjectRepository(TankConfigurationEntity)
    private readonly tankConfigRepository: Repository<TankConfigurationEntity>,
    @InjectRepository(ROBTrackingEntity)
    private readonly robTrackingRepository: Repository<ROBTrackingEntity>,
    @InjectRepository(FileStorageEntity)
    private readonly fileStorageRepository: Repository<FileStorageEntity>,
    @InjectRepository(ContentEntity)
    private readonly contentRepository: Repository<ContentEntity>,
    @InjectRepository(MainPart)
    private readonly mainPartRepository: Repository<MainPart>,
    @InjectRepository(ContentROBTrackingEntity)
    private readonly contentROBTrackingRepository: Repository<ContentROBTrackingEntity>,
    private shipValidationService: ShipValidationService,
    @InjectRepository(TimezoneEntity)
    private readonly timezoneRepository: Repository<TimezoneEntity>,

    @InjectRepository(MainPartContentConsumptionEntity)
    private readonly mainPartContentConsumptionRepository: Repository<MainPartContentConsumptionEntity>,
    @InjectRepository(ActiveEventReportEntity)
    private readonly activeReportRepo: Repository<ActiveEventReportEntity>,
    @InjectRepository(ItineraryPortEntity)
    private readonly itineraryPortRepository: Repository<ItineraryPortEntity>,
  ) {}

  async createPositionBookReport(
    createReportDto: CreatePositionBookReportDto,
  ): Promise<PositionBookReportEntity> {
    const {
      shipId,
      reportId,
      speedDistanceWeather,
      engineData,
      cargoStability,
      cargoDetails,
      report_name,
      reportDate,
      reportTime,
    } = createReportDto;
    const ship = await this.shipValidationService.getShipById(shipId);
    const existingReport = await this.positionBookReportRepository.findOne({
      where: { reportId },
      relations: [
        'voyage',
        'speedDistanceWeather',
        'engineData',
        'cargoStability',
        'cargoDetails',
      ],
    });

    if (!existingReport) {
      throw new NotFoundException(`Report with ID ${reportId} not found.`);
    }

    this.positionBookReportRepository.merge(existingReport, {
      ...createReportDto,
      ship,
    });

    if (speedDistanceWeather) {
      existingReport.speedDistanceWeather =
        this.speedDistanceWeatherRepository.merge(
          existingReport.speedDistanceWeather ||
            this.speedDistanceWeatherRepository.create(),
          speedDistanceWeather,
        );
    }
    if (engineData) {
      existingReport.engineData = this.engineDataRepository.merge(
        existingReport.engineData || this.engineDataRepository.create(),
        engineData,
      );
    }
    if (cargoStability) {
      existingReport.cargoStability = this.cargoStabilityRepository.merge(
        existingReport.cargoStability || this.cargoStabilityRepository.create(),
        cargoStability,
      );
    }

    const updatedReport =
      await this.positionBookReportRepository.save(existingReport);

    // Handle cargo details if provided
    if (cargoDetails && cargoDetails.length > 0) {
      // Remove old cargo details linked to the report
      await this.cargoDetailsRepository.delete({ report: updatedReport });

      // Add new cargo details
      const cargoEntities = cargoDetails.map((cargo) => ({
        ...cargo,
        report: updatedReport,
      }));
      await this.cargoDetailsRepository.save(cargoEntities);
    }

    const timeZoneData = await this.timezoneRepository.findOne({
      where: { timezone_id: createReportDto.timezone },
    });
    let utcOffset = 0;
    if (timeZoneData) {
      utcOffset = timeZoneData.utcOffset;
    }

    if (report_name && existingReport.status === 'approved') {
      const voyage = existingReport.voyage;
      voyage.lastReportType = report_name;
      await this.voyageRepository.save(voyage);
      await this.updateVoyageItineraryForReport(
        existingReport,
        new Date(reportDate).toISOString().split('T')[0],
        reportTime,
        utcOffset,
      );
      await this.shipValidationService.completeActiveReport(
        reportId,
        new Date(reportDate).toISOString().split('T')[0],
        reportTime,
        utcOffset,
      );
    }

    return updatedReport;
  }

  private getItineraryFieldsByReportName(reportName: string): {
    fromPortField: string | null;
    toPortField: string | null;
  } {
    const reportFieldMap: Record<
      string,
      { fromPortField: string | null; toPortField: string | null }
    > = {
      eosp: { fromPortField: 'arrivalDate', toPortField: null }, // EOSP updates arrivalDate for from port
      arrival_at_port: { fromPortField: null, toPortField: 'actualArrival' }, // Arrival at port updates actualArrival for to port
      departure_berth: { fromPortField: 'departureDate', toPortField: null }, // Departure from berth updates departureDate for from port
      cosp: { fromPortField: null, toPortField: 'actualDeparture' }, // COSP updates actualDeparture for to port
    };

    return (
      reportFieldMap[reportName] || { fromPortField: null, toPortField: null }
    );
  }

  private async calculateLocalTime(
    utcTime: Date,
    timezoneId: string,
  ): Promise<Date> {
    const timezoneData = await this.timezoneRepository.findOne({
      where: { timezone_id: timezoneId },
    });

    if (!timezoneData) {
      throw new NotFoundException(`Timezone with ID ${timezoneId} not found.`);
    }

    const localTime = moment(utcTime)
      .utcOffset(timezoneData.utcOffset)
      .toDate();
    return localTime;
  }

  async updateVoyageItineraryForReport(
    report: PositionBookReportEntity,
    reportDate: string,
    reportTime: string,
    utcOffset: number,
  ): Promise<void> {
    // Fetch the active voyage linked to the report with itinerary ports
    const voyage = await this.voyageRepository.findOne({
      where: { id: report.voyage.id },
      relations: ['ports', 'ship', 'ports.port'],
    });

    if (!voyage) {
      throw new NotFoundException(
        `Voyage not found for report ID: ${report.reportId}`,
      );
    }

    // Calculate UTC time from report date, time, and offset
    const reportDateTime = `${reportDate} ${reportTime.slice(0, 2)}:${reportTime.slice(2)}`;
    const localTime = moment(reportDateTime, 'YYYY-MM-DD HH:mm');
    const utcTime = localTime.utcOffset(utcOffset).utc().toDate();

    // Find the from_port and to_port in the itinerary
    const fromPort = voyage.ports.find(
      (port) => port.port.code === report.from_port,
    );
    const toPort = voyage.ports.find(
      (port) => port.port.code === report.to_port,
    );

    if (!fromPort || !toPort) {
      throw new NotFoundException(
        `Ports not found in the itinerary: ${report.from_port}, ${report.to_port}`,
      );
    }

    // Determine which fields to update based on the report name
    const { fromPortField, toPortField } = this.getItineraryFieldsByReportName(
      report.report_name,
    );

    // Update fromPort field with the correct local time
    if (fromPortField) {
      const fromPortLocalTime = this.calculateLocalTime(
        utcTime,
        fromPort.timezone,
      );
      fromPort[fromPortField] = fromPortLocalTime;
    }

    // Update toPort field with the correct local time
    if (toPortField) {
      const toPortLocalTime = this.calculateLocalTime(utcTime, toPort.timezone);
      toPort[toPortField] = toPortLocalTime;
    }

    // Save the updated ports
    await this.itineraryPortRepository.save([fromPort, toPort]);
  }

  async getPositionBookReportById(
    reportId: string,
  ): Promise<PositionBookReportEntity> {
    const report = await this.positionBookReportRepository.findOne({
      where: { reportId },
      relations: [
        'voyage',
        'voyage.ports',
        'voyage.ports.port',
        'ship',
        'speedDistanceWeather',
        'engineData',
        'cargoStability',
        'cargoDetails',
      ],
    });

    if (!report) {
      throw new NotFoundException(
        `Position Book Report with ID ${reportId} not found.`,
      );
    }

    return report;
  }

  async initiatePositionBookReport(
    initiateReportDto: InitiatePositionBookReportDto,
  ): Promise<PositionBookReportEntity> {
    const { shipId } = initiateReportDto;

    // Validate ship
    const ship = await this.shipValidationService.getShipById(shipId);
    await this.shipValidationService.validateNoActiveReport(shipId);

    // Validate voyage
    const voyage = await this.voyageRepository.findOne({
      where: { ship: { id: shipId }, status: 'active', disabled: false },
      select: ['id', 'voyageId', 'lastReportType', 'voyageNumber'],
      relations: ['ports', 'ports.port'],
    });

    if (!voyage) {
      throw new NotFoundException(`No active Voyage found.`);
    }

    const existingDraftReport = await this.positionBookReportRepository.findOne(
      {
        where: { voyage: { id: voyage.id }, status: 'draft' },
      },
    );

    if (existingDraftReport) {
      throw new BadRequestException(
        `A draft report already exists for the voyage. Complete the draft report before initiating a new one.`,
      );
    }
    // Generate a unique report ID
    const reportId = await this.generateUniqueReportId(ship.code);

    // Create a new report with default or partially filled values
    const newReport = this.positionBookReportRepository.create({
      reportId,
      ship,
      voyage,
      reportDate: new Date(), // Default to current date
      report_name: '', // Default value, if required
      timezone: '', // Default to voyage timezone
      from_port: '',
      to_port: '',
      berth: null,
      vessel_location: null,
      latitude: null, // Corrected spelling
      longitude: null,
      isShore: false,
      status: 'draft',
      remarks: null,
    });

    await this.shipValidationService.createActiveReport(
      shipId,
      reportId,
      'position_book_report',
    );

    // Save and return the report
    return await this.positionBookReportRepository.save(newReport);
  }

  async generateUniqueReportId(shipCode: string): Promise<string> {
    const prefix = `${shipCode}-PE-`; // Prefix with ship code and "VI-"
    let uniqueNumber;

    while (true) {
      // Generate a random number in the desired range (e.g., 100000 to 999999)
      uniqueNumber = Math.floor(100000 + Math.random() * 900000);

      // Combine prefix and unique number
      const candidateId = `${prefix}${uniqueNumber}`;
      const existingReport = await this.positionBookReportRepository.findOne({
        where: { reportId: candidateId },
      });

      // If it doesn't exist, return it as the unique ID
      if (!existingReport) {
        return candidateId;
      }
    }
  }

  async uploadDocumentsByReportId(
    reportId: string,
    files: Express.Multer.File[],
  ): Promise<void> {
    // Step 1: Find the report by ID
    const report = await this.positionBookReportRepository.findOne({
      where: { reportId },
      relations: ['cargoStability'],
    });

    if (!report) {
      throw new NotFoundException(`Report with ID ${reportId} not found.`);
    }

    // Step 2: Validate CargoStabilityEntity existence
    if (!report.cargoStability) {
      throw new NotFoundException(
        `Cargo Stability data not found for Report ID ${reportId}.`,
      );
    }

    // Step 3: Map and save documents
    const documentEntities = files.map((file) =>
      this.fileStorageRepository.create({
        data: file.buffer,
        mimeType: file.mimetype,
        fileName: file.originalname,
        cargo: report.cargoStability,
      }),
    );

    await this.fileStorageRepository.save(documentEntities);
  }

  async getReportsByShipId(
    shipId: number,
    status?: string,
    search?: string,
    page: number = 1,
    limit: number = 10,
  ): Promise<{
    data: PositionBookReportEntity[];
    total: number;
    page: number;
    limit: number;
  }> {
    // Validate ship existence
    const ship = await this.shipValidationService.getShipById(shipId);

    if (!ship) {
      throw new NotFoundException(`Ship with ID ${shipId} not found.`);
    }

    const queryBuilder = this.positionBookReportRepository
      .createQueryBuilder('report')
      .leftJoinAndSelect('report.voyage', 'voyage')
      .leftJoinAndSelect('report.ship', 'ship')
      .where('ship.id = :shipId', { shipId });

    // Filter by status if provided
    if (status) {
      queryBuilder.andWhere('report.status = :status', { status });
    }

    // Search filter for reportId & report_name
    if (search) {
      queryBuilder.andWhere(
        '(report.reportId ILIKE :search OR report.report_name ILIKE :search)',
        { search: `%${search}%` },
      );
    }

    // Pagination logic
    const [data, total] = await queryBuilder
      .orderBy('report.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return {
      data,
      total,
      page,
      limit,
    };
  }

  async getContentReporting(shipId: number): Promise<any> {
    const ship = await this.shipValidationService.getShipById(shipId);

    // Fetch Content Data
    const contents = await this.contentRepository.find({
      where: { ship, disabled: false },
      relations: [
        'mainPartConsumptions',
        'mainPartConsumptions.mainPart',
        'tanks',
      ], // Fetch linked equipment
      order: { typeOrder: 'ASC', order: 'ASC' },
    });

    // Fetch Tanks Linked to Each Content
    const contentData = await Promise.all(
      contents.map(async (content) => {
        const tanks = await this.tankConfigRepository.find({
          where: {
            content: { contentCode: content.contentCode },
            ship: { id: ship.id },
          },
        });

        return {
          content: {
            id: content.id,
            contentCode: content.contentCode,
            name: content.name,
            type: content.type,
            currentROB: content.currentROB,
            lastROB: content.lastROB,
            sulphurContent: content.sulphurContent,
            viscosity: content.viscosity,
          },
          tanks: tanks.map((tank) => ({
            id: tank.id,
            tankCode: tank.tankCode,
            tankName: tank.tankName,
            currentROB: tank.currentROB,
            lastReportROB: tank.lastReportROB,
            capacity: tank.capacity,
          })),
          equipments:
            content.type === 'FUEL'
              ? content.mainPartConsumptions.map((consumption) => ({
                  id: consumption.mainPart.id,
                  name: consumption.mainPart.name,
                  prevRob: consumption.previousConsumption,
                  currentRob: consumption.currentConsumption,
                }))
              : [],
        };
      }),
    );

    // Step 4: Group Data by Content Type
    const groupedData = {
      fuels: contentData.filter((data) => data.content.type === 'FUEL'),
      lubes: contentData.filter((data) => data.content.type === 'LUBE'),
      freshwater: contentData.filter((data) => data.content.type === 'WATER'),
    };

    return groupedData;
  }

  async saveContentReport(saveContentReportDto: SaveContentReportDto): Promise<{
    message: string;
  }> {
    const { reportId, status, contentConsumptions } = saveContentReportDto;

    // Validate Report
    const report = await this.positionBookReportRepository.findOne({
      where: { reportId },
      relations: ['voyage', 'ship'],
    });
    if (!report) {
      throw new NotFoundException(`Report with ID ${reportId} not found.`);
    }

    if (status === 'draft') {
      this.saveDraftContentReport(contentConsumptions);
    } else if (status === 'approved') {
      this.saveApprovedContentReport(contentConsumptions, report);
    }

    return {
      message: 'Content report saved successfully.',
    };
  }

  private async saveDraftContentReport(
    contentConsumptions: ContentConsumptionDto[],
  ): Promise<void> {
    for (const contentData of contentConsumptions) {
      const { contentCode, tankConsumptions, equipmentConsumptions } =
        contentData;

      // Validate Content
      const content = await this.contentRepository.findOne({
        where: { contentCode },
        relations: [
          'tanks',
          'mainPartConsumptions',
          'mainPartConsumptions.mainPart',
        ],
      });

      if (!content) {
        throw new NotFoundException(
          `Content with code ${contentCode} not found.`,
        );
      }
      let totalTankClosingROB = 0;
      // Update Tank ROB for Draft
      if (tankConsumptions && tankConsumptions.length > 0) {
        for (const tankData of tankConsumptions) {
          const tank = content.tanks.find(
            (t) => t.tankCode === tankData.tankCode,
          );

          if (!tank) {
            throw new NotFoundException(
              `Tank with code ${tankData.tankCode} not linked to content ${contentCode}.`,
            );
          }

          // Update only currentROB for Draft
          tank.currentROB = tankData.closingROB;
          totalTankClosingROB += tank.currentROB;
          await this.tankConfigRepository.save(tank);
        }
      }
      content.currentROB = totalTankClosingROB;
      await this.contentRepository.save(content);
      // Update Equipment Consumption for Draft
      if (equipmentConsumptions && equipmentConsumptions.length > 0) {
        for (const equipment of equipmentConsumptions) {
          const consumptionRecord = content.mainPartConsumptions.find(
            (consumption) => consumption.mainPart.id === equipment.equipmentId,
          );

          if (!consumptionRecord) {
            throw new NotFoundException(
              `Equipment with ID ${equipment.equipmentId} not linked to content ${contentCode}.`,
            );
          }

          // Update only currentConsumption for Draft in MainPartContentConsumption entity
          consumptionRecord.currentConsumption = equipment.consumptionAmount;
          await this.mainPartContentConsumptionRepository.save(
            consumptionRecord,
          );
        }
      }
    }
  }

  private async saveApprovedContentReport(
    contentConsumptions: ContentConsumptionDto[],
    report: PositionBookReportEntity,
  ): Promise<void> {
    for (const contentData of contentConsumptions) {
      const { contentCode, tankConsumptions, equipmentConsumptions } =
        contentData;

      // Validate Content
      const content = await this.contentRepository.findOne({
        where: { contentCode },
        relations: [
          'tanks',
          'mainPartConsumptions',
          'mainPartConsumptions.mainPart',
        ],
      });
      if (!content) {
        throw new NotFoundException(
          `Content with code ${contentCode} not found.`,
        );
      }

      // Handle Equipment Consumptions
      if (equipmentConsumptions && equipmentConsumptions.length > 0) {
        for (const equipment of equipmentConsumptions) {
          const consumptionRecord = content.mainPartConsumptions.find(
            (consumption) => consumption.mainPart.id === equipment.equipmentId,
          );

          if (!consumptionRecord) {
            throw new NotFoundException(
              `Equipment with ID ${equipment.equipmentId} not linked to content ${contentCode}.`,
            );
          }

          // Update MainPart Consumption
          consumptionRecord.previousConsumption = equipment.consumptionAmount;
          consumptionRecord.currentConsumption = equipment.consumptionAmount;
          await this.mainPartContentConsumptionRepository.save(
            consumptionRecord,
          );

          // Save to Content ROB Tracking
          const contentROBTracking = this.contentROBTrackingRepository.create({
            content,
            report,
            consumed: equipment.consumptionAmount,
            comments: equipment.comments || null,
          });

          await this.contentROBTrackingRepository.save(contentROBTracking);
        }

        await this.contentRepository.save(content);
      }
      let totalTankClosingROB = 0;
      // Handle Tank Consumptions
      if (tankConsumptions && tankConsumptions.length > 0) {
        for (const tankData of tankConsumptions) {
          const tank = content.tanks.find(
            (t) => t.tankCode === tankData.tankCode,
          );
          if (!tank) {
            throw new NotFoundException(
              `Tank with code ${tankData.tankCode} not linked to content ${contentCode}.`,
            );
          }

          // Update both currentROB and lastReportROB for Approved
          tank.currentROB = tankData.closingROB;
          tank.lastReportROB = tankData.closingROB;
          totalTankClosingROB += tank.currentROB;
          await this.tankConfigRepository.save(tank);

          // Save to Tank ROB Tracking
          const robTracking = this.robTrackingRepository.create({
            tank,
            report,
            openingBalance: tankData.openingROB,
            closingBalance: tankData.closingROB,
            consumed: tankData.openingROB - tankData.closingROB,
            comments: tankData.comments || null,
          });
          await this.robTrackingRepository.save(robTracking);
        }

        content.lastROB = totalTankClosingROB; // Move currentROB to lastROB before updating
        content.currentROB = totalTankClosingROB;
        await this.contentRepository.save(content);
      }
    }
  }

  async getReportTracking(shipId: number): Promise<ActiveEventReportEntity[]> {
    return await this.activeReportRepo.find({
      where: { ship: { id: shipId } },
      order: { reportStage: 'ASC' },
    });
  }
}
