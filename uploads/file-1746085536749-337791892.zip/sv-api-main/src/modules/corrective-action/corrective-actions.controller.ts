import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import {
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiQuery,
  ApiResponse,
} from '@nestjs/swagger';
import { CorrectiveActionEntity } from 'src/entities/qhse-reports/corrective-measure.entity';
import { CorrectiveActionsService } from './corrective-actions.service';
import { CreateCorrectiveActionDto } from './dto/create-corrective-measure.dto';

@Controller('corrective-measure-action')
export class CorrectiveActionController {
  constructor(
    private readonly correctiveActionService: CorrectiveActionsService,
  ) {}

  @Get()
  @ApiOperation({ summary: 'Get a list of corrective Action list' })
  @ApiResponse({
    status: 200,
    description: 'List of corrective Action with pagination details',
    schema: {
      type: 'object',
      properties: {
        data: {
          type: 'array',
          items: { $ref: '#/components/schemas/Re' },
        },
        total: {
          type: 'number',
          description: 'Total number of corrective Action matching the query',
        },
      },
    },
  })
  @ApiQuery({
    name: 'shipId',
    required: true,
    type: Number,
    description: 'The ID of the ship to filter corrective Action by',
    example: 1,
  })
  @ApiQuery({
    name: 'status',
    required: false,
    type: String,
    description:
      'Filter corrective Action by their status (e.g., active, draft)',
    example: 'active',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    type: Number,
    description: 'The page number for pagination',
    example: 1,
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    description: 'The number of corrective Action to return per page',
    example: 10,
  })
  async getCorrectiveActions(
    @Query('shipId') shipId?: number,
    @Query('status') status?: string,
    @Query('page') page = 1,
    @Query('limit') limit = 10,
  ): Promise<{ data: CorrectiveActionEntity[]; total: number }> {
    if (!shipId) {
      throw new BadRequestException('shipId is required');
    }
    return await this.correctiveActionService.getCorrectiveActions({
      shipId,
      status,
      page,
      limit,
    });
  }

  @Get(':correctiveActionId')
  @ApiOperation({ summary: 'Get corrective Action info by ID' })
  @ApiResponse({
    status: 200,
    description: 'corrective Action info',
    type: CorrectiveActionEntity,
  })
  @ApiResponse({ status: 404, description: 'corrective Action not found' })
  async getCorrectiveActionById(
    @Param('correctiveActionId') correctiveActionId: string,
  ): Promise<CorrectiveActionEntity> {
    return await this.correctiveActionService.getCorrectiveActionById(
      correctiveActionId,
    );
  }

  @Post(':correctiveActionId')
  @ApiOperation({ summary: 'Update Corrective Action Info' })
  @ApiResponse({
    status: 200,
    description: 'Corrective Action info updated successfully',
    type: CorrectiveActionEntity,
  })
  @ApiResponse({ status: 404, description: 'Corrective Action not found' })
  async saveCorrectiveActions(
    @Param('correctiveActionId') correctiveActionId: string,
    @Body() correctiveActionDto: CreateCorrectiveActionDto,
  ): Promise<CorrectiveActionEntity> {
    return await this.correctiveActionService.saveCorrectiveActions(
      correctiveActionId,
      correctiveActionDto,
    );
  }

  @Post(':correctiveActionId/attachments')
  @UseInterceptors(FilesInterceptor('files'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Upload multiple attachments for a Corrective Action',
    schema: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  async uploadAttachmentsForCorrectiveAction(
    @Param('correctiveActionId') correctiveActionId: string,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<{ message: string }> {
    await this.correctiveActionService.uploadAttachmentsForCorrective(
      correctiveActionId,
      files,
    );
    return { message: 'Attachments uploaded successfully' };
  }
}
