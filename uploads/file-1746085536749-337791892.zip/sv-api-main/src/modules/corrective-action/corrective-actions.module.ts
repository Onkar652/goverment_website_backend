import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';

import { CorrectiveActionController } from './corrective-actions.controller';
import { CorrectiveActionsService } from './corrective-actions.service';
import { ShipValidationService } from '../common/ship-validation.service';
import { CorrectiveActionEntity } from 'src/entities/qhse-reports/corrective-measure.entity';
import { AreaEntity } from 'src/entities/master-configs/area.entity';
import { NearMissReportEntity } from 'src/entities/qhse-reports/near-miss-report.entity';
import { CertificationEntity } from 'src/entities/certifications/certification.entity';
import { WorkOrder } from 'src/entities/shipActions/work-order.entity';
import { RequisitionEntity } from 'src/entities/requisitions/requisition.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      FileStorageEntity,
      CorrectiveActionEntity,
      AreaEntity,
      NearMissReportEntity,
      CertificationEntity,
      WorkOrder,
      RequisitionEntity,
    ]),
  ],
  controllers: [CorrectiveActionController],
  providers: [CorrectiveActionsService, ShipValidationService],
  exports: [CorrectiveActionsService],
})
export class CorrectiveActionModule {}
