import { Test, TestingModule } from '@nestjs/testing';
import { CorrectiveActionsService } from './corrective-actions.service';
describe('CorrectiveActionsService', () => {
  let service: CorrectiveActionsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CorrectiveActionsService],
    }).compile();

    service = module.get<CorrectiveActionsService>(CorrectiveActionsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
