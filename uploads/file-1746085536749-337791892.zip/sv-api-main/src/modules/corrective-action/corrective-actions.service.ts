import {
  BadRequestException,
  ConflictException,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { CertificationEntity } from 'src/entities/certifications/certification.entity';
import { FileStorageEntity } from 'src/entities/fileStorage/file-storage.entity';
import { CorrectiveActionEntity } from 'src/entities/qhse-reports/corrective-measure.entity';
import { RequisitionEntity } from 'src/entities/requisitions/requisition.entity';
import { WorkOrder } from 'src/entities/shipActions/work-order.entity';
import { CertificateStatus } from 'src/utils/models/common.types';
import { DataSource, EntityManager, Like, Repository } from 'typeorm';
import { ShipValidationService } from '../common/ship-validation.service';
import { CreateCorrectiveActionDto } from './dto/create-corrective-measure.dto';
import { InitiateCorrectiveReportDto } from './dto/initiate-corrective-measure.dto';
@Injectable()
export class CorrectiveActionsService {
  private correctiveActionRepository: Repository<CorrectiveActionEntity>;
  private fileStorageRepository: Repository<FileStorageEntity>;
  private workOrderRepository: Repository<WorkOrder>;
  private certificationRepository: Repository<CertificationEntity>;
  private requisitionRepository: Repository<RequisitionEntity>;
  constructor(
    private readonly dataSource: DataSource,
    private shipValidationService: ShipValidationService,
  ) {
    this.correctiveActionRepository = this.dataSource.getRepository(
      CorrectiveActionEntity,
    );
    this.fileStorageRepository =
      this.dataSource.getRepository(FileStorageEntity);
    this.workOrderRepository = this.dataSource.getRepository(WorkOrder);
    this.certificationRepository =
      this.dataSource.getRepository(CertificationEntity);
    this.requisitionRepository =
      this.dataSource.getRepository(RequisitionEntity);
  }

  async saveCorrectiveActions(
    correctiveActionId: string,
    correctiveActionDto: CreateCorrectiveActionDto,
  ): Promise<CorrectiveActionEntity> {
    if (!correctiveActionDto.correctiveActionId) {
      throw new BadRequestException(
        'Corrective Action ID is required for updating a correction Action info.',
      );
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Fetch the existing corrective actions
      const correctiveAction = await this.correctiveActionRepository.findOne({
        where: { correctiveActionId },
        relations: ['workOrders', 'certificate', 'attachments', 'requisition'],
      });

      if (!correctiveAction) {
        throw new NotFoundException(
          `correctiveAction with ID ${correctiveAction} not found.`,
        );
      }

      // Use shared logic for updating the report
      const updatedCorrectiveAction = await this.updatedCorrectiveAction(
        correctiveAction,
        correctiveActionDto,
        queryRunner.manager,
      );

      await queryRunner.commitTransaction();
      return updatedCorrectiveAction;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw new InternalServerErrorException(
        `Failed to update CorrectiveAction: ${error.message}`,
      );
    } finally {
      await queryRunner.release();
    }
  }

  async generateUniqueCorrectionId(shipCode: string): Promise<string> {
    const currentYear = new Date().getFullYear().toString().slice(-2);

    const latestReport = await this.correctiveActionRepository.findOne({
      where: { correctiveActionId: Like(`CA-${shipCode}-${currentYear}%`) },
      order: { correctiveActionId: 'DESC' },
    });

    let serialNumber = 1; // Default if no previous ID exists

    if (latestReport) {
      const lastIdParts = latestReport.correctiveActionId.split('-');
      const lastYear = lastIdParts[2].substring(0, 2); // Extract year
      const lastSerial = parseInt(lastIdParts[2].substring(2), 10); // Extract serial number

      if (lastYear === currentYear) {
        serialNumber = lastSerial + 1; // Increment if same year
      }
    }

    // Ensure serial number is 4-digit padded
    const paddedSerial = serialNumber.toString().padStart(4, '0');
    return `CA-${shipCode}-${currentYear}${paddedSerial}`;
  }

  private async updatedCorrectiveAction(
    correctiveAction: CorrectiveActionEntity,
    correctiveActionDto: CreateCorrectiveActionDto,
    manager: EntityManager,
  ): Promise<CorrectiveActionEntity> {
    const workOrder = correctiveActionDto.workOrderId
      ? await this.workOrderRepository.findOne({
          where: { id: correctiveActionDto.workOrderId },
        })
      : null;
    // const certificate = correctiveActionDto.certificateId
    //   ? await this.certificationRepository.findOne({
    //       where: { id: correctiveActionDto.certificateId },
    //     })
    //   : null;
    const requisition = correctiveActionDto.requisitionId
      ? await this.requisitionRepository.findOne({
          where: { id: correctiveActionDto.requisitionId },
        })
      : null;
    const updatedCorrectiveAction = this.correctiveActionRepository.create({
      ...correctiveAction,
      ...correctiveActionDto,
      workOrder: workOrder,
      purchaseRequisitions: requisition,
    });
    return await manager.save(CorrectiveActionEntity, updatedCorrectiveAction);
  }

  async getCorrectiveActionById(
    correctiveActionId: string,
  ): Promise<CorrectiveActionEntity> {
    const correctiveAction = await this.correctiveActionRepository
      .createQueryBuilder('corrective_action') // Use a consistent alias
      .leftJoinAndSelect('corrective_action.ship', 'ship') // Correctly joining ship
      .leftJoin('corrective_action.attachments', 'attachments') // Join attachments once
      .leftJoinAndSelect('corrective_action.requisition', 'requisition')
      .leftJoinAndSelect('corrective_action.workOrders', 'workOrders')
      .leftJoinAndSelect('corrective_action.certificate', 'certificate')
      .addSelect([
        'attachments.id',
        'attachments.fileName',
        'attachments.mimeType',
        'attachments.createdOn',
      ])
      .where('corrective_action.correctiveActionId = :correctiveActionId', {
        correctiveActionId,
      })
      .getOne();

    if (!correctiveAction) {
      throw new NotFoundException(
        `Corrective Action with ID ${correctiveActionId} not found.`,
      );
    }

    return correctiveAction;
  }

  async uploadAttachmentsForCorrective(
    correctiveActionId: string,
    files: Express.Multer.File[],
  ): Promise<void> {
    const correctiveAction = await this.correctiveActionRepository.findOne({
      where: { correctiveActionId },
    });

    if (!correctiveAction) {
      throw new NotFoundException(
        `Corrective Measure with ID ${correctiveActionId} not found.`,
      );
    }

    const attachments = files.map((file) =>
      this.fileStorageRepository.create({
        data: file.buffer,
        mimeType: file.mimetype,
        fileName: file.originalname,
        correctiveAction,
      }),
    );

    await this.fileStorageRepository.save(attachments);
  }

  async initiateCorrectiveActionReport(
    queryParams: InitiateCorrectiveReportDto,
  ): Promise<CreateCorrectiveActionDto> {
    const { shipId } = queryParams;

    // Step 1: Validate the ship ID.
    if (!shipId) {
      throw new BadRequestException('Ship ID is missing');
    }

    // Step 2: Fetch ship details by ID.
    const ship = await this.shipValidationService.getShipById(shipId);

    // Step 3: Check if there is an existing draft corrective action report.
    const existingDraft = await this.correctiveActionRepository.findOne({
      where: { ship: { id: shipId }, status: CertificateStatus.Draft },
    });

    if (existingDraft) {
      throw new ConflictException(
        'There is already a draft report in progress. Please complete it before creating a new one.',
      );
    }

    // Step 4: Generate a unique Corrective Action report ID.
    const correctiveActionReportCode = await this.generateUniqueCorrectionId(
      ship.code,
    );

    // Step 5: Create a new corrective action report.
    const draftCorrectiveActionReport: CorrectiveActionEntity =
      this.correctiveActionRepository.create({
        correctiveActionId: correctiveActionReportCode,
        ship,
        status: 'Draft',
        initiatedFrom: null,
        correctiveActionsPlan: null,
        actionCarriedOut: null,
        isEvidenceRequired: null,
        nearMissReportIncidentDate: null,
        targetDate: null,
        personInCharge: null,
        purchaseRequisitions: null,
        workOrder: null,
      });

    const savedReport = await this.correctiveActionRepository.save(
      draftCorrectiveActionReport,
    );

    // Step 6: Save the newly created draft corrective action report.
    return {
      ...savedReport,
      shipId: savedReport.ship.id,
      correctiveActionId: savedReport.correctiveActionId,
    };
  }

  async getCorrectiveActions(query: {
    shipId: number;
    status?: string;
    page: number;
    limit: number;
  }): Promise<{ data: CorrectiveActionEntity[]; total: number }> {
    const { shipId, status, page = 1, limit = 10 } = query;

    const ship = await this.shipValidationService.getShipById(shipId);

    const queryBuilder = this.correctiveActionRepository
      .createQueryBuilder('correctiveActions')
      .where('correctiveActions.shipId = :shipId', { shipId: ship.id });

    if (status) {
      queryBuilder.andWhere('correctiveActions.status = :status', { status });
    }

    const [data, total] = await queryBuilder
      .orderBy('correctiveActions.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return { data, total };
  }
}
