import { Test, TestingModule } from '@nestjs/testing';
import { CorrectiveActionController } from './corrective-actions.controller';
import { CorrectiveActionsService } from './corrective-actions.service';

describe('CorrectiveActionController', () => {
  let controller: CorrectiveActionController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CorrectiveActionController],
      providers: [CorrectiveActionsService],
    }).compile();

    controller = module.get<CorrectiveActionController>(
      CorrectiveActionController,
    );
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
