import {
  Body,
  Controller,
  Delete,
  Get,
  NotFoundException,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { TankConfigService } from './tank-config.service';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiQuery,
  ApiParam,
} from '@nestjs/swagger';
import { TankConfigurationEntity } from 'src/entities/tank-config/tank-config.entity';
import { CreateTankDto } from './dto/create-tank.dto';
import { UpdateTankDto } from './dto/update-tank.dto';
import { TankQueryDto } from './dto/tank-query.dto';
import { ContentEntity } from 'src/entities/tank-config/content.entity';
import { CreateContentDto } from './dto/create-content.dto';
import { UpdateContentDto } from './dto/update-content.dto';

@ApiTags('Tanks')
@Controller('tank-config')
export class TankConfigController {
  constructor(private readonly tankConfigService: TankConfigService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new tank configuration' })
  @ApiResponse({ status: 201, description: 'Tank created successfully.' })
  async createTank(
    @Body() createTankDto: CreateTankDto,
  ): Promise<TankConfigurationEntity> {
    return await this.tankConfigService.createTank(createTankDto);
  }

  @Get()
  @ApiOperation({ summary: 'Get all tank configurations' })
  @ApiResponse({ status: 200, description: 'List of tanks.' })
  async getAllTanks(
    @Query() query: TankQueryDto,
  ): Promise<TankConfigurationEntity[]> {
    return await this.tankConfigService.getAllTanks(query);
  }

  @Get(':tankCode')
  @ApiOperation({ summary: 'Get a specific tank configuration by tank code' })
  @ApiResponse({
    status: 200,
    description: 'Tank configuration retrieved successfully.',
  })
  @ApiResponse({ status: 404, description: 'Tank configuration not found.' })
  async getTankByCode(
    @Param('tankCode') tankCode: string,
    @Query('shipId', ParseIntPipe) shipId: number,
  ) {
    const tank = await this.tankConfigService.getTankByCode(tankCode, shipId);
    if (!tank) {
      throw new NotFoundException(`Tank with code ${tankCode} not found.`);
    }
    return tank;
  }

  @Put(':tankCode')
  @ApiOperation({ summary: 'Update a tank configuration by tank code' })
  @ApiResponse({
    status: 200,
    description: 'Tank configuration updated successfully.',
  })
  async updateTank(
    @Param('tankCode') tankCode: string,
    @Body() updateTankDto: UpdateTankDto,
  ) {
    return await this.tankConfigService.updateTank(tankCode, updateTankDto);
  }
  @Delete(':tankCode')
  @ApiOperation({ summary: 'Delete a tank configuration by tank code' })
  @ApiResponse({
    status: 200,
    description: 'Tank configuration deleted successfully.',
  })
  async deleteTank(
    @Param('tankCode') tankCode: string,
    @Query('shipId', ParseIntPipe) shipId: number,
  ) {
    return await this.tankConfigService.deleteTank(tankCode, shipId);
  }

  @Post('/content/create')
  @ApiOperation({ summary: 'Add a new content entry' })
  @ApiResponse({
    status: 201,
    description: 'The content has been successfully created.',
  })
  async addContent(
    @Body() createContentDto: CreateContentDto,
  ): Promise<ContentEntity> {
    return await this.tankConfigService.addContent(createContentDto);
  }

  @Put('/content/:contentCode')
  @ApiOperation({ summary: 'Update an existing content entry by content code' })
  @ApiResponse({
    status: 200,
    description: 'The content has been successfully updated.',
  })
  async updateContent(
    @Param('contentCode') contentCode: string,
    @Body() updateContentDto: UpdateContentDto,
  ): Promise<ContentEntity> {
    return await this.tankConfigService.updateContent(
      contentCode,
      updateContentDto,
    );
  }

  @Delete('/content/:contentCode')
  @ApiOperation({ summary: 'Delete a content entry by content code' })
  @ApiResponse({
    status: 200,
    description: 'The content has been successfully deleted.',
  })
  async deleteContent(
    @Param('contentCode') contentCode: string,
  ): Promise<void> {
    return await this.tankConfigService.deleteContent(contentCode);
  }

  @Get('/content/all-by-ship')
  @ApiOperation({ summary: 'Get all contents by ship ID' })
  @ApiQuery({
    name: 'shipId',
    type: 'number',
    required: true,
    description: 'ID of the ship',
  })
  @ApiResponse({
    status: 200,
    description: 'List of contents',
    type: [ContentEntity],
  })
  async getAllContentsByShipId(
    @Query('shipId', ParseIntPipe) shipId: number, // Use ParseIntPipe to handle conversion
  ): Promise<ContentEntity[]> {
    return this.tankConfigService.getAllContentsByShipId(shipId);
  }

  @ApiOperation({ summary: 'Get content by content code' })
  @ApiParam({
    name: 'contentCode',
    type: 'string',
    required: true,
    description: 'Code of the content',
  })
  @ApiResponse({
    status: 200,
    description: 'Content details',
    type: ContentEntity,
  })
  @Get('/content/:contentCode')
  async getContentByContentCode(
    @Param('contentCode') contentCode: string,
  ): Promise<ContentEntity> {
    return this.tankConfigService.getContentByContentCode(contentCode);
  }
}
