import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsString, IsOptional, IsNotEmpty, IsNumber } from 'class-validator';

export class TankQueryDto {
  @ApiProperty({
    description: 'Id of the ship to which the tank belongs',
    example: 1,
  })
  @IsNumber()
  @IsNotEmpty()
  @Type(() => Number)
  shipId: number;

  @ApiProperty({
    description: 'Type of content to filter tanks',
    example: 'FUEL',
    required: false,
  })
  @IsOptional()
  @IsString()
  contentType?: string;

  @ApiProperty({
    description: 'Name of the tank to search',
    example: 'Fuel Tank 1',
    required: false,
  })
  @IsOptional()
  @IsString()
  tankName?: string;
}
