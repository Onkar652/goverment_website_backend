import {
  IsString,
  IsOptional,
  IsNumber,
  IsBoolean,
  IsNotEmpty,
  IsArray,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateContentDto {
  @ApiProperty({
    description: 'Ship ID to which the content belongs',
    example: 1,
  })
  @IsNotEmpty()
  @IsNumber()
  shipId: number;

  @ApiProperty({
    description: 'Name of the content (e.g., HSFO, Lube Oil)',
    example: 'HSFO',
  })
  @IsString()
  name: string;

  @ApiProperty({
    description: 'Type of the content (e.g., FUEL, LUBE, WATER)',
    example: 'FUEL',
  })
  @IsString()
  type: string;

  @ApiProperty({
    description: 'Sulphur content of the material',
    example: 0.5,
    required: false,
  })
  @IsOptional()
  @IsNumber()
  sulphurContent?: number;

  @ApiProperty({
    description: 'Viscosity of the material',
    example: 10,
    required: false,
  })
  @IsOptional()
  @IsNumber()
  viscosity?: number;

  @ApiProperty({
    description: 'Density of the material',
    example: 10,
    required: false,
  })
  @IsOptional()
  @IsNumber()
  density?: number;

  @ApiProperty({
    description: 'Initial ROB value',
    example: 1000,
    required: false,
  })
  @IsOptional()
  @IsNumber()
  currentROB?: number;

  @ApiProperty({
    description: 'Disabled status',
    example: false,
    required: false,
  })
  @IsOptional()
  @IsBoolean()
  disabled?: boolean;

  @ApiProperty({
    description: 'Array of Main Part IDs linked to this content',
    example: [1, 2, 3],
    required: false,
  })
  @IsOptional()
  @IsArray()
  @IsNumber({}, { each: true })
  mainPartIds?: number[];
}
