import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsNumber,
  IsOptional,
  IsObject,
  IsNotEmpty,
  IsDateString,
} from 'class-validator';

export class CreateTankDto {
  @ApiProperty({
    description: 'Id of the ship to which the tank belongs',
    example: 1,
  })
  @IsNumber()
  @IsNotEmpty()
  shipId: number;

  // @ApiProperty({
  //   description: 'Code representing the tank',
  //   example: 'CASSTK0001',
  // })
  // @IsString()
  // @IsOptional()
  // tankCode: string;

  @ApiProperty({
    description: 'Human-readable name for the tank',
    example: 'Cargo Tank 1',
  })
  @IsString()
  tankName: string;

  @ApiProperty({ description: 'Total capacity of the tank', example: 1000 })
  @IsNumber()
  capacity: number;

  @ApiProperty({
    description: 'Content Code to associate with the tank',
    example: 'FUEL001',
  })
  @IsString()
  @IsNotEmpty()
  contentCode: string;

  @ApiProperty({ description: 'Unit of measure', example: 'MT' })
  @IsString()
  unitOfMeasure: string;

  @ApiProperty({ description: 'Comments', example: 'Fuel tank added' })
  @IsString()
  @IsOptional()
  comment: string;

  @ApiProperty({
    description: 'Additional metadata for the tank',
    required: false,
  })
  @IsOptional()
  @IsObject()
  additionalInfo?: Record<string, any>;

  @ApiProperty({
    description: 'ROB date for the tank',
    example: '2024-12-25T10:30:00Z',
  })
  @IsDateString()
  robDate: Date;

  @ApiProperty({
    description: 'Viscosity of the content',
    example: 50,
    required: false,
  })
  @IsOptional()
  @IsNumber()
  openingBalance?: number;
}
