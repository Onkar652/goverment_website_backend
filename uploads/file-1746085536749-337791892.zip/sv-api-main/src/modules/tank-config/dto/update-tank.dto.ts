import {
  IsOptional,
  IsNumber,
  IsString,
  IsNotEmpty,
  IsDateString,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateTankDto {
  @ApiProperty({
    description: 'Id of the ship to which the tank belongs',
    example: 1,
  })
  @IsNumber()
  @IsNotEmpty()
  shipId: number;

  @ApiProperty({
    description: 'Name of the tank',
    example: 'Fuel Tank 1',
    required: false,
  })
  @IsOptional()
  @IsString()
  tankName?: string;

  @ApiProperty({
    description: 'Total capacity of the tank',
    example: 1000.0,
    required: false,
  })
  @IsOptional()
  @IsNumber()
  capacity?: number;

  @ApiProperty({
    description: 'Content Code to associate with the tank',
    example: 'FUEL001',
    required: false,
  })
  @IsOptional()
  @IsString()
  contentCode?: string;

  @ApiProperty({
    description: 'Unit of measure for the tank content',
    example: 'MT',
    required: false,
  })
  @IsOptional()
  @IsString()
  unitOfMeasure?: string;

  @ApiProperty({
    description: 'Additional metadata for tank customization',
    required: false,
    type: 'object',
  })
  @IsOptional()
  additionalInfo?: Record<string, any>;

  @ApiProperty({
    description: 'ROB date for the tank',
    example: '2024-12-25T10:30:00Z',
    required: false,
  })
  @IsOptional()
  @IsDateString()
  robDate?: Date;

  @ApiProperty({
    description: 'Opening balance of the tank',
    example: 50,
    required: false,
  })
  @IsOptional()
  @IsNumber()
  openingBalance?: number;
}
