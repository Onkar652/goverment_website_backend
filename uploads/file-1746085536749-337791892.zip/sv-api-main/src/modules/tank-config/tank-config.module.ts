import { Module } from '@nestjs/common';
import { TankConfigService } from './tank-config.service';
import { TankConfigController } from './tank-config.controller';
import { CommonModule } from '../common/common.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TankConfigurationEntity } from 'src/entities/tank-config/tank-config.entity';
import { ContentEntity } from 'src/entities/tank-config/content.entity';
import { MainPart } from 'src/entities/shipParts/main-parts.entity';
import { MainPartContentConsumptionEntity } from 'src/entities/tank-config/main-part-consumption.entity';

@Module({
  imports: [
    CommonModule,
    TypeOrmModule.forFeature([
      TankConfigurationEntity,
      ContentEntity,
      MainPart,
      MainPartContentConsumptionEntity,
    ]),
  ],
  controllers: [TankConfigController],
  providers: [TankConfigService],
})
export class TankConfigModule {}
