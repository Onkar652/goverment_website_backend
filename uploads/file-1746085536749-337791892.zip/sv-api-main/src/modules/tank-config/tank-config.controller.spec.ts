import { Test, TestingModule } from '@nestjs/testing';
import { TankConfigController } from './tank-config.controller';
import { TankConfigService } from './tank-config.service';

describe('TankConfigController', () => {
  let controller: TankConfigController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TankConfigController],
      providers: [TankConfigService],
    }).compile();

    controller = module.get<TankConfigController>(TankConfigController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
