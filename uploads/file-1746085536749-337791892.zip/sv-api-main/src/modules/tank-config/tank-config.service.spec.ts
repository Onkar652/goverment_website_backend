import { Test, TestingModule } from '@nestjs/testing';
import { TankConfigService } from './tank-config.service';

describe('TankConfigService', () => {
  let service: TankConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [TankConfigService],
    }).compile();

    service = module.get<TankConfigService>(TankConfigService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
