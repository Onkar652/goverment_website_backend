import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TankConfigurationEntity } from 'src/entities/tank-config/tank-config.entity';
import { In, Repository } from 'typeorm';
import { CreateTankDto } from './dto/create-tank.dto';
import { UpdateTankDto } from './dto/update-tank.dto';
import { ShipValidationService } from '../common/ship-validation.service';
import { TankQueryDto } from './dto/tank-query.dto';
import { ContentEntity } from 'src/entities/tank-config/content.entity';
import { CreateContentDto } from './dto/create-content.dto';
import { UpdateContentDto } from './dto/update-content.dto';
import { MainPart } from 'src/entities/shipParts/main-parts.entity';
import { MainPartContentConsumptionEntity } from 'src/entities/tank-config/main-part-consumption.entity';

@Injectable()
export class TankConfigService {
  constructor(
    @InjectRepository(TankConfigurationEntity)
    private readonly tankRepository: Repository<TankConfigurationEntity>,
    private shipValidationService: ShipValidationService,
    @InjectRepository(ContentEntity)
    private readonly contentRepository: Repository<ContentEntity>,
    @InjectRepository(MainPart)
    private readonly mainPartRepository: Repository<MainPart>,
    @InjectRepository(MainPartContentConsumptionEntity)
    private readonly mainPartContentConsumptionRepository: Repository<MainPartContentConsumptionEntity>,
  ) {}

  private async generateTankCode(
    shipCode: string,
    shipId: number,
  ): Promise<string> {
    const tankCount = await this.tankRepository.count({
      where: { ship: { id: shipId } },
    });

    // Generate the tank code with format: SHIPCODE_TK_<NUMBER>
    const tankNumber = String(tankCount + 1).padStart(3, '0'); // Pad number to 3 digits
    return `${shipCode}_TK_${tankNumber}`;
  }

  async createTank(
    createTankDto: CreateTankDto,
  ): Promise<TankConfigurationEntity> {
    const {
      shipId,
      contentCode,
      capacity,
      unitOfMeasure,
      additionalInfo,
      openingBalance,
      robDate,
      comment,
    } = createTankDto;

    // Step 1: Validate Ship
    const ship = await this.shipValidationService.getShipById(shipId);

    // Step 2: Validate Content
    const content = await this.contentRepository.findOne({
      where: { contentCode },
    });
    if (!content) {
      throw new NotFoundException(
        `Content with code ${contentCode} not found.`,
      );
    }

    // Step 3: Generate Unique Tank Code
    const tankCode = await this.generateTankCode(ship.code, ship.id);

    // Step 4: Create Tank Entity
    const tank = this.tankRepository.create({
      tankCode,
      tankName: createTankDto.tankName,
      capacity,
      unitOfMeasure,
      additionalInfo,
      ship,
      content,
      openingBalance,
      currentROB: openingBalance,
      lastReportROB: openingBalance,
      robDate,
      comment,
      isInitialized: false, // Default value for initialization
    });

    // Step 5: Save Tank Entity
    return await this.tankRepository.save(tank);
  }

  async getAllTanks(query: TankQueryDto) {
    const { shipId, contentType, tankName } = query;

    // Validate ship
    await this.shipValidationService.getShipById(shipId);

    const queryBuilder = this.tankRepository
      .createQueryBuilder('tank')
      .leftJoinAndSelect('tank.content', 'content')
      .where('tank.ship_id = :shipId', { shipId });

    if (contentType) {
      queryBuilder.andWhere('tank.contentType = :contentType', { contentType });
    }

    if (tankName) {
      queryBuilder.andWhere('tank.tankName ILIKE :tankName', {
        tankName: `%${tankName}%`,
      });
    }

    queryBuilder
      .orderBy('content.typeOrder', 'ASC')
      .addOrderBy('content.order', 'ASC');

    return await queryBuilder.getMany();
  }

  async getTankByCode(tankCode: string, shipId: number) {
    // Validate ship
    await this.shipValidationService.getShipById(shipId);

    const tank = await this.tankRepository.findOne({
      where: { tankCode, ship: { id: shipId } },
      relations: ['content'],
    });

    if (!tank) {
      throw new NotFoundException(`Tank with code ${tankCode} not found.`);
    }

    return tank;
  }

  async updateTank(
    tankCode: string,
    updateTankDto: UpdateTankDto,
  ): Promise<TankConfigurationEntity> {
    const { shipId, contentCode } = updateTankDto;
    const tank = await this.getTankByCode(tankCode, shipId);

    //  Validate Content Code (if updated)
    if (contentCode && contentCode !== tank.content?.contentCode) {
      const newContent = await this.contentRepository.findOne({
        where: { contentCode },
      });

      if (!newContent) {
        throw new NotFoundException(
          `Content with code ${contentCode} not found.`,
        );
      }

      // Update the tank's associated content
      tank.content = newContent;
    }

    // Merge and Save Tank Data
    const updatedTank = this.tankRepository.merge(tank, updateTankDto);
    return await this.tankRepository.save(updatedTank);
  }

  async deleteTank(tankCode: string, shipId: number) {
    // Validate ship
    await this.shipValidationService.getShipById(shipId);

    const tank = await this.getTankByCode(tankCode, shipId);

    return await this.tankRepository.remove(tank);
  }

  private async generateContentCode(type: string): Promise<string> {
    const count = await this.contentRepository.count({ where: { type } });
    const paddedCount = String(count + 1).padStart(3, '0');
    return `${type.toUpperCase()}_${paddedCount}`;
  }

  async addContent(createContentDto: CreateContentDto): Promise<ContentEntity> {
    const { shipId, type, name, mainPartIds } = createContentDto;

    // Validate ship
    const ship = await this.shipValidationService.getShipById(shipId);

    // Check if content with the same name already exists
    const existingContent = await this.contentRepository.findOne({
      where: { name, type, ship: { id: ship.id } },
    });
    if (existingContent) {
      throw new ConflictException(
        `Content with name ${name} and type ${type} already exists.`,
      );
    }

    // Generate contentCode
    const contentCode = await this.generateContentCode(type);

    const newContent = this.contentRepository.create({
      ...createContentDto,
      contentCode,
      ship,
    });

    const savedContent = await this.contentRepository.save(newContent);

    // Update main parts if specified
    if (mainPartIds && mainPartIds.length > 0) {
      // Fetch main parts linked to this content
      const mainParts = await this.mainPartRepository.findBy({
        id: In(mainPartIds),
      });

      // Validate if all provided mainPartIds exist in the database
      const foundIds = mainParts.map((mp) => mp.id);
      const missingIds = mainPartIds.filter((id) => !foundIds.includes(id));

      if (missingIds.length > 0) {
        throw new NotFoundException(
          `Some Main Parts not found: ${missingIds.join(', ')}`,
        );
      }

      // Link main parts with content via the new many-to-many relationship
      const contentConsumptions: MainPartContentConsumptionEntity[] =
        mainParts.map((mainPart) => {
          return this.mainPartContentConsumptionRepository.create({
            mainPart,
            content: savedContent,
            previousConsumption: 0,
            currentConsumption: 0,
          });
        });

      await this.mainPartContentConsumptionRepository.save(contentConsumptions);
    }

    return savedContent;
  }

  async updateContent(
    contentCode: string,
    updateContentDto: UpdateContentDto,
  ): Promise<ContentEntity> {
    const { mainPartIds } = updateContentDto;

    const content = await this.contentRepository.findOne({
      where: { contentCode },
      relations: ['mainPartConsumptions', 'mainPartConsumptions.mainPart'],
    });

    if (!content) {
      throw new NotFoundException(
        `Content with code ${contentCode} not found.`,
      );
    }

    Object.assign(content, updateContentDto);
    const savedContent = await this.contentRepository.save(content);

    // Update main parts if specified
    if (mainPartIds && mainPartIds.length > 0) {
      // Fetch all existing main parts linked to this content
      const existingConsumptions =
        await this.mainPartContentConsumptionRepository.find({
          where: { content: { id: savedContent.id } },
        });

      // Delete old associations if any
      if (existingConsumptions.length > 0) {
        await this.mainPartContentConsumptionRepository.remove(
          existingConsumptions,
        );
      }

      // Fetch main parts by provided IDs
      const mainParts = await this.mainPartRepository.findBy({
        id: In(mainPartIds),
      });

      // Validate if all provided mainPartIds exist in the database
      const foundIds = mainParts.map((mp) => mp.id);
      const missingIds = mainPartIds.filter((id) => !foundIds.includes(id));

      if (missingIds.length > 0) {
        throw new NotFoundException(
          `Some Main Parts not found: ${missingIds.join(', ')}`,
        );
      }

      // Create new associations
      const newConsumptions = mainParts.map((mainPart) =>
        this.mainPartContentConsumptionRepository.create({
          mainPart,
          content: savedContent,
          previousConsumption: 0, // Default initial value
          currentConsumption: 0,
        }),
      );

      await this.mainPartContentConsumptionRepository.save(newConsumptions);
    }

    return savedContent;
  }

  async deleteContent(contentCode: string): Promise<void> {
    const content = await this.contentRepository.findOne({
      where: { contentCode },
    });

    if (!content) {
      throw new NotFoundException(
        `Content with code ${contentCode} not found.`,
      );
    }

    await this.contentRepository.remove(content);
  }

  async getAllContentsByShipId(shipId: number): Promise<ContentEntity[]> {
    // Validate the ship first
    const ship = await this.shipValidationService.getShipById(shipId);

    // Fetch all contents linked to the ship, including tanks and main part consumptions
    const contents = await this.contentRepository.find({
      where: { ship: { id: ship.id }, disabled: false },
      relations: ['mainPartConsumptions', 'mainPartConsumptions.mainPart'],
      order: { typeOrder: 'ASC', order: 'ASC' },
    });

    return contents;
  }

  async getContentByContentCode(contentCode: string): Promise<ContentEntity> {
    // Fetch the content along with its relations
    const content = await this.contentRepository.findOne({
      where: { contentCode },
      relations: [
        'ship',
        'tanks',
        'mainPartConsumptions',
        'mainPartConsumptions.mainPart',
      ],
    });

    if (!content) {
      throw new NotFoundException(
        `Content with code ${contentCode} not found.`,
      );
    }

    return content;
  }
}
