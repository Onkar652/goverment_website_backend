import { Module } from '@nestjs/common';
import { ShipValidationService } from './ship-validation.service';
import { Ship } from 'src/entities/ships/ships.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([Ship])],
  providers: [ShipValidationService],
  exports: [ShipValidationService],
})
export class CommonModule {}
