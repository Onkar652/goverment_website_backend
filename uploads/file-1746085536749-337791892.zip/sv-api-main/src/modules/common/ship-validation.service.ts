import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { ActiveEventReportEntity } from 'src/entities/postion-book-reports/active-event-reports.entity';
import { Ship } from 'src/entities/ships/ships.entity';
import { Repository, DataSource } from 'typeorm';
import * as moment from 'moment';

@Injectable()
export class ShipValidationService {
  private shipRepo: Repository<Ship>;
  private activeReportRepo: Repository<ActiveEventReportEntity>;

  constructor(private readonly dataSource: DataSource) {
    this.shipRepo = this.dataSource.getRepository(Ship);
    this.activeReportRepo = this.dataSource.getRepository(
      ActiveEventReportEntity,
    );
  }

  async getShipById(shipId: number): Promise<Ship> {
    console.log(shipId, 'dnskdvs');
    const ship = await this.shipRepo.findOne({
      where: { id: shipId, disabled: false },
      select: ['id', 'name', 'code'],
    });
    if (!ship) {
      throw new NotFoundException('Ship not found');
    }
    return ship;
  }

  async validateNoActiveReport(shipId: number): Promise<void> {
    const activeReport = await this.activeReportRepo.findOne({
      where: { ship: { id: shipId }, reportStage: 'active' },
      select: ['id', 'reportType', 'reportId'],
    });

    if (activeReport) {
      throw new ConflictException(
        `An active ${activeReport.reportType} is already in progress with Report ID: ${activeReport.reportId}.`,
      );
    }
  }

  /**
   * Create or update the active report for the ship.
   * If an active report exists, it will throw a conflict exception.
   */
  async createActiveReport(
    shipId: number,
    reportId: string,
    reportType: 'bunker_report' | 'position_book_report',
  ): Promise<void> {
    const ship = await this.getShipById(shipId);

    // Check if an active report already exists
    const existingActiveReport = await this.activeReportRepo.findOne({
      where: { ship, reportStage: 'active' },
    });

    if (existingActiveReport) {
      throw new ConflictException(
        `An active ${existingActiveReport.reportType} report already exists with ID: ${existingActiveReport.reportId}.`,
      );
    }

    // Create a new active report entry
    const newActiveReport = this.activeReportRepo.create({
      ship,
      reportId,
      reportType,
      reportStage: 'active',
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    await this.activeReportRepo.save(newActiveReport);
  }

  /**
   * Complete the active report.
   * Deletes any previous completed report and updates the active report.
   */
  async completeActiveReport(
    reportId: string,
    reportDate: string, // Report date string (YYYY-MM-DD)
    reportTime: string, // Report time in HHmm format (e.g., '2130')
    utcOffset: number, // UTC offset (e.g., -5.5, 2.25)
  ): Promise<void> {
    const activeReport = await this.activeReportRepo.findOne({
      where: { reportId, reportStage: 'active' },
    });

    if (!activeReport) {
      throw new NotFoundException(
        `Active report with ID ${reportId} not found.`,
      );
    }

    // Step 1: Calculate UTC time using report date, time, and UTC offset
    const reportDateTime = `${reportDate} ${reportTime.slice(0, 2)}:${reportTime.slice(2)}`;
    const localTime = moment(reportDateTime, 'YYYY-MM-DD HH:mm');

    const utcTime = localTime.utcOffset(utcOffset).utc().toDate();

    // Step 2: Remove previous completed report for the ship
    await this.activeReportRepo.delete({
      ship: activeReport.ship,
      reportStage: 'completed',
    });

    // Step 3: Update the current active report to completed and set utcTime
    activeReport.reportStage = 'completed';
    activeReport.utcTime = utcTime;
    activeReport.updatedAt = new Date();

    await this.activeReportRepo.save(activeReport);
  }

  /**
   * Remove a report entry (optional)
   */
  async removeReportEntry(reportId: string): Promise<void> {
    await this.activeReportRepo.delete({ reportId });
  }

  /**
   * Get both active and completed reports for a ship
   */

  async validateNoBackdatedReport(
    shipId: number,
    reportDate: string,
    reportTime: string,
    utcOffset: number,
  ): Promise<void> {
    // Fetch the latest completed report
    const lastCompletedReport = await this.activeReportRepo.findOne({
      where: { ship: { id: shipId }, reportStage: 'completed' },
      select: ['utcTime'],
      order: { updatedAt: 'DESC' },
    });

    if (lastCompletedReport && lastCompletedReport.utcTime) {
      // Calculate the current report's UTC time
      const reportDateTime = `${reportDate} ${reportTime.slice(0, 2)}:${reportTime.slice(2)}`;
      const localTime = moment(reportDateTime, 'YYYY-MM-DD HH:mm');
      const currentUtcTime = localTime.utcOffset(utcOffset).utc().toDate();

      // Compare times
      if (currentUtcTime <= lastCompletedReport.utcTime) {
        throw new ConflictException(
          'Cannot create a report with a backdated UTC time. The new report must be after the last completed report.',
        );
      }
    }
  }
}
