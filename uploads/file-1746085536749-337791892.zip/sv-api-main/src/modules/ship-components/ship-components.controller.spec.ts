import { Test, TestingModule } from '@nestjs/testing';
import { ShipComponentsController } from './ship-components.controller';
import { ShipComponentsService } from './ship-components.service';

describe('ShipComponentsController', () => {
  let controller: ShipComponentsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ShipComponentsController],
      providers: [ShipComponentsService],
    }).compile();

    controller = module.get<ShipComponentsController>(ShipComponentsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
