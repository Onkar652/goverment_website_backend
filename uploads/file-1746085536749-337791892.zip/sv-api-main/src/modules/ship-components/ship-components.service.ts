import { Injectable, NotFoundException } from '@nestjs/common';
import { MainPartComponent } from 'src/entities/shipParts/main-part-components.entity';
import { MainPart } from 'src/entities/shipParts/main-parts.entity';
import { Ship } from 'src/entities/ships/ships.entity';
import { DataSource, Repository } from 'typeorm';

@Injectable()
export class ShipComponentsService {
  private mainPartRepository: Repository<MainPart>;
  private shipRepo: Repository<Ship>;
  private mainPartComponentRepository: Repository<MainPartComponent>;
  constructor(private readonly dataSource: DataSource) {
    this.mainPartRepository = this.dataSource.getRepository(MainPart);
    this.shipRepo = this.dataSource.getRepository(Ship);

    this.mainPartComponentRepository =
      this.dataSource.getRepository(MainPartComponent);
  }

  async findMainPartByShipId(shipId: number) {
    const ship = await this.getShipById(shipId);
    const parts = await this.mainPartRepository.find({
      where: {
        ship: { id: ship.id },
        disabled: false,
      },
    });

    return parts;
  }

  async findComponentsByShipAndPart(
    shipId: number,
    mainPartId: number,
  ): Promise<MainPartComponent[]> {
    await this.getShipById(shipId);
    return await this.mainPartComponentRepository
      .createQueryBuilder('component')
      .innerJoin('component.mainPart', 'mainPart')
      .where('mainPart.id = :mainPartId', { mainPartId })
      .andWhere('mainPart.shipId = :shipId', { shipId })
      .getMany();
  }

  async getShipById(shipId: number): Promise<Ship> {
    const ship = await this.shipRepo.findOne({
      where: { id: shipId, disabled: false },
      relations: ['client', 'voyages', 'userDetails', 'mainParts'], // Include any relations needed
    });
    if (!ship) {
      throw new NotFoundException('Ship not found');
    }
    return ship;
  }
}
