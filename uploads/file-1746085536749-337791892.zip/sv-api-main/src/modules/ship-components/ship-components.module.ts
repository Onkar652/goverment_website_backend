import { Module } from '@nestjs/common';
import { ShipComponentsService } from './ship-components.service';
import { ShipComponentsController } from './ship-components.controller';

@Module({
  controllers: [ShipComponentsController],
  providers: [ShipComponentsService],
})
export class ShipComponentsModule {}
