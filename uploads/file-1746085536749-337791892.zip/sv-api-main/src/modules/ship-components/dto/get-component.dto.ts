import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsNotEmpty } from 'class-validator';

export class ComponentQueryDto {
  @ApiProperty({ description: 'Unique identifier of the ship', example: 1 })
  @IsNumber()
  @IsNotEmpty()
  shipId: number;

  @ApiProperty({
    description: 'Unique identifier of the main part',
    example: 1,
  })
  @IsNumber()
  @IsNotEmpty()
  mainPartId: number;
}
