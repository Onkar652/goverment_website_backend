import { Test, TestingModule } from '@nestjs/testing';
import { ShipComponentsService } from './ship-components.service';

describe('ShipComponentsService', () => {
  let service: ShipComponentsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ShipComponentsService],
    }).compile();

    service = module.get<ShipComponentsService>(ShipComponentsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
