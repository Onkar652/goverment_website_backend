import {
  Body,
  Controller,
  Get,
  HttpException,
  HttpStatus,
  Param,
  ParseIntPipe,
  Post,
} from '@nestjs/common';
import { MainPart } from 'src/entities/shipParts/main-parts.entity';
import { ShipComponentsService } from './ship-components.service';
import {
  ApiBody,
  ApiOperation,
  ApiParam,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { ComponentQueryDto } from './dto/get-component.dto';
import { MainPartComponent } from 'src/entities/shipParts/main-part-components.entity';

@ApiTags('ship-parts')
@Controller('ship-components')
export class ShipComponentsController {
  constructor(private readonly shipComponentsService: ShipComponentsService) {}

  @Get('main-components/:shipId')
  @ApiOperation({ summary: 'Retrieve all main parts by ship ID' })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved main parts',
    type: [MainPart],
  })
  @ApiResponse({ status: 404, description: 'Ship not found' })
  @ApiResponse({ status: 500, description: 'Internal server error' })
  @ApiParam({
    name: 'shipId',
    type: 'number',
    description: 'Unique identifier of the ship',
  })
  async getMainPartsByShipId(
    @Param('shipId', ParseIntPipe) shipId: number,
  ): Promise<MainPart[]> {
    try {
      return await this.shipComponentsService.findMainPartByShipId(shipId);
    } catch (error) {
      throw new HttpException(
        'Failed to retrieve main parts',
        HttpStatus.INTERNAL_SERVER_ERROR,
        {
          cause: error,
        },
      );
    }
  }

  @Post('get-components')
  @ApiOperation({ summary: 'Retrieve components by ship ID and main part ID' })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved components',
  })
  @ApiResponse({ status: 400, description: 'Invalid input data' })
  @ApiResponse({ status: 500, description: 'Internal server error' })
  @ApiBody({ type: ComponentQueryDto })
  async getComponentsByShipAndPart(
    @Body() queryDto: ComponentQueryDto,
  ): Promise<MainPartComponent[]> {
    try {
      return await this.shipComponentsService.findComponentsByShipAndPart(
        queryDto.shipId,
        queryDto.mainPartId,
      );
    } catch (error) {
      throw new HttpException(
        'Failed to retrieve components',
        HttpStatus.INTERNAL_SERVER_ERROR,
        {
          cause: error,
        },
      );
    }
  }
}
