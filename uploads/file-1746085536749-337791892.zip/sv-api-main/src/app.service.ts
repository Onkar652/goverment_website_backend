import { Injectable, OnModuleInit } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { Connection } from 'typeorm';

@Injectable()
export class AppService implements OnModuleInit {
  constructor(@InjectConnection() private readonly connection: Connection) {}

  async onModuleInit() {
    const isConnected = this.connection.isConnected; // TypeORM v2
    // const isConnected = this.connection.isInitialized; // TypeORM v3
    console.log(
      `Database connection status: ${isConnected ? 'Connected' : 'Not connected'}`,
    );
  }
  getHello(): string {
    return 'Hey Backend is alive!';
  }
}
