import { randomBytes } from 'crypto';

export function convertReminderToHours(
  reminderValue: number,
  reminderUnit: string,
): number {
  switch (reminderUnit) {
    case 'H': // Hours
      return reminderValue;
    case 'D': // Days
      return reminderValue * 24; // Assuming 24 hours in a day
    case 'W': // Weeks
      return reminderValue * 24 * 7; // Assuming 7 days in a week, 24 hours in a day
    default:
      return 0; // Default case if unit is unrecognized
  }
}

export function generateJobId(
  shipCode: string,
  jobId: string | number,
): string {
  // Construct the jobId using the shipCode, componentId (if available), and config.jobId
  const uniquePart = randomBytes(2).toString('hex').substring(0, 4);
  const timestamp = Date.now().toString().slice(-2); // Last 2 digits of the timestamp
  return `${shipCode}.${jobId}.${uniquePart}${timestamp}`;
}
