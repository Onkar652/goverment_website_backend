export enum UserRanks {
  SECOND_ENGINEER = '2E',
  THIRD_ENGINEER = '3E',
  FOURTH_ENGINEER = '4E',
  CHIEF_ENGINEER = 'CE',
  ELECT_ENGINEER = 'EE',
  GAS_ENGINEER = 'GE',
  THIRD_OFFICER = '3O',
  SECOND_OFFICER = '2O',
  SAFETY_OFFICER = 'SO',
  CHIEF_OFFICER = 'CO',
  MASTER = 'M',
}

export enum CertificateStatus {
  Draft = 'Draft',
  PendingApproval = 'Pending Approval',
  Approved = 'Approved',
  Rejected = 'Rejected',
  Active = 'Active',
  Open = 'Open',
  ExtensionRequest = 'Extension Request',
  ClosureVerification = 'Closure Verification',
  Closed = 'Closed',
  Expired = 'Expired',
  UnderAmendment = 'Under Amendment',
  InWindow = 'In-Window',
  Extended = 'Extended',
  RequestSubmittedVessel = 'Request Submitted (Vessel)',
  RequestSubmittedShore = 'Request Submitted (Shore)',
  ReviewInProgressShore = 'Review In Progress (Shore)',
  ReviewInProgressVessel = 'Review In Progress (Vessel)',
  Returned = 'Returned',
  ExtensionReviewInProgress = 'Extension Review In Progress',
}

export enum SurveyStatus {
  OPEN = 'Open',
  COMPLETE = 'Complete',
  DUE = 'Due',
}

export enum SpareCategory {
  NORMAL = 'normal',
  CRITICAL = 'critical',
}

export enum InventoryType {
  SPARE = 'spare',
  GSTORE = 'gstore',
}

export enum RequisitionPriority {
  CRITICAL = 'critical',
  MAINTENANCE = 'routine_maintenance',
  NORMAL = 'normal',
  RECOMMENDED = 'recommended_stock',
  URGENT = 'urgent_immediate',
}

export enum RequisitionStatus {
  APPROVED = 'approved',
  SUBMITTED = 'submitted',
  DRAFT = 'draft',
}

export enum BunkerTransactionType {
  BUNKERING = 'bunkering',
  BUNKER_SURVEY = 'bunker_survey',
  CORRECTION = 'correction',
  TANK_TRANSFER = 'tank_transfer',
}
