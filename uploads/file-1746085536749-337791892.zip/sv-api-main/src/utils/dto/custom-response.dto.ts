export class CustomResponse {
  statusCode: number;
  message: string;
  result?: any;
}
