export const portList = [
  {
    portName: 'AABENRAA, DENMARK',
    portCode: 'DK AAB',
    country: 'Denmark',
  },
  {
    portName: 'ABERDEEN, WA',
    portCode: 'US GHR',
    country: 'United States of America',
  },
  {
    portName: "ABIDJAN, COTE D'IVOIRE",
    portCode: 'CI ABJ',
    country: "Cote D'ivoire",
  },
  {
    portName: 'ABU KAMMASH, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY ABK',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'ACAJUTLA, EL SALVADOR',
    portCode: 'SV AQJ',
    country: 'El Salvador',
  },
  {
    portName: 'ACAPULCO, MEXICO',
    portCode: 'MX ACA',
    country: 'Mexico',
  },
  {
    portName: 'ADELAIDE, AUSTRALIA',
    portCode: 'AU ADL',
    country: 'Australia',
  },
  {
    portName: 'ADEN, YEMEN',
    portCode: 'YM ADE',
    country: 'Yemen',
  },
  {
    portName: 'AL BAYDA, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY ABA',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'AL KHUMS, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY KHO',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'ALAMEDA, CA',
    portCode: 'US NGZ',
    country: 'United States of America',
  },
  {
    portName: "AL'AQABAH, JORDAN",
    portCode: 'JO AQJ',
    country: 'Jordan',
  },
  {
    portName: 'ALBANY, AUSTRALIA',
    portCode: 'AU ALH',
    country: 'Australia',
  },
  {
    portName: 'AMPALA, HONDURAS',
    portCode: 'HN AMP',
    country: 'Honduras',
  },
  {
    portName: 'AMSTERDAM, NETHERLANDS',
    portCode: 'NL AMS',
    country: 'Netherlands',
  },
  {
    portName: 'AMUAY, VENEZUELA',
    portCode: 'VE AMY',
    country: 'Venezuela',
  },
  {
    portName: 'ANACORTES, WA',
    portCode: 'US OTS',
    country: 'United States of America',
  },
  {
    portName: 'ANCHORAGE, AK',
    portCode: 'US ANC',
    country: 'United States of America',
  },
  {
    portName: 'ANGRA DOS REIS, BRAZIL',
    portCode: 'BR ADR',
    country: 'Brazil',
  },
  {
    portName: 'ANTWERP, BELGIUM',
    portCode: 'BE ANR',
    country: 'Belgium',
  },
  {
    portName: 'AOMORI, JAPAN',
    portCode: 'JP AOJ',
    country: 'Japan',
  },
  {
    portName: 'APIA, WESTERN SAMOA',
    portCode: 'WS APW',
    country: 'Samoa',
  },
  {
    portName: 'APOLLONIA, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY APO',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'ARICA, CHILE',
    portCode: 'CL ARI',
    country: 'Chile',
  },
  {
    portName: 'AS SIDR, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY ESI',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'ASSENS, DENMARK',
    portCode: 'DK ASN',
    country: 'Denmark',
  },
  {
    portName: 'ASTORIA, OR',
    portCode: 'US AST',
    country: 'United States of America',
  },
  {
    portName: 'ASUNCION, PARAGUAY',
    portCode: 'PY ASU',
    country: 'Paraguay',
  },
  {
    portName: 'AUCKLAND, NEW ZEALAND',
    portCode: 'NZ AKL',
    country: 'New Zealand',
  },
  {
    portName: 'AVILA BEACH, CA',
    portCode: 'US CSL',
    country: 'United States of America',
  },
  {
    portName: 'AZ ZAWIYAH, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY ZAW',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'BACOLOD, PHILIPPINES',
    portCode: 'PH BCD',
    country: 'Philippines',
  },
  {
    portName: 'BAHIA BLANCA, ARGENTINA',
    portCode: 'AR BHI',
    country: 'Argentina',
  },
  {
    portName: 'BALAO, ECUADOR',
    portCode: 'EC EBL',
    country: 'Ecuador',
  },
  {
    portName: 'BALBOA, PANAMA',
    portCode: 'PA BLB',
    country: 'Panama',
  },
  {
    portName: 'BALTIMORE, MD',
    portCode: 'US BAL',
    country: 'United States of America',
  },
  {
    portName: 'BANGALORE, INDIA',
    portCode: 'IN BLR',
    country: 'India',
  },
  {
    portName: 'BARBERS POINT, HI',
    portCode: 'US NAX',
    country: 'United States of America',
  },
  {
    portName: 'BARCELONA, SPAIN',
    portCode: 'ES BCN',
    country: 'Spain',
  },
  {
    portName: 'BARDIYAH, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY BAR',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'BARRANQUILLA, COLOMBIA',
    portCode: 'CO BAQ',
    country: 'Colombia',
  },
  {
    portName: 'BATON ROUGE, LA',
    portCode: 'US BTR',
    country: 'United States of America',
  },
  {
    portName: 'BAYOVAR, PERU',
    portCode: 'PE PUB',
    country: 'Peru',
  },
  {
    portName: 'BAYPORT, TX',
    portCode: 'US BPX',
    country: 'United States of America',
  },
  {
    portName: 'BAYTOWN, TX',
    portCode: 'US HPY',
    country: 'United States of America',
  },
  {
    portName: 'BAYUQUAN, CHINA',
    portCode: 'CN BYQ',
    country: "People's Republic of China",
  },
  {
    portName: 'BEAUFORT, NC',
    portCode: 'US BFO',
    country: 'United States of America',
  },
  {
    portName: 'BEAUMONT, TX',
    portCode: 'US BPT',
    country: 'United States of America',
  },
  {
    portName: 'BEIRUT, LEBANON',
    portCode: 'LB BEY',
    country: 'Lebanon',
  },
  {
    portName: 'BELEM, BRAZIL',
    portCode: 'BR BEL',
    country: 'Brazil',
  },
  {
    portName: 'BELLINGHAM, WA',
    portCode: 'US BLI',
    country: 'United States of America',
  },
  {
    portName: 'BENICA, CA',
    portCode: 'US BNC',
    country: 'United States of America',
  },
  {
    portName: 'BINGAZI, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY BEN',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'BITUNG, INDONESIA',
    portCode: 'ID BIT',
    country: 'Indonesia',
  },
  {
    portName: 'BONTANG, INDONESIA',
    portCode: 'ID BXT',
    country: 'Indonesia',
  },
  {
    portName: 'BOSTON, MA',
    portCode: 'US BOS',
    country: 'United States of America',
  },
  {
    portName: 'BREMERTON, WA',
    portCode: 'US PWT',
    country: 'United States of America',
  },
  {
    portName: 'BRISBANE, AUSTRALIA',
    portCode: 'AU BNE',
    country: 'Australia',
  },
  {
    portName: 'BROWNSVILLE, TX',
    portCode: 'US BRO',
    country: 'United States of America',
  },
  {
    portName: 'BRUNSWICK, GA',
    portCode: 'US SSI',
    country: 'United States of America',
  },
  {
    portName: "BU'AYRAT AL HASUN, LIBYAN ARAB JAMAHIRIYA",
    portCode: 'LY BUA',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'BUENAVENTURA, COLOMBIA',
    portCode: 'CO BUN',
    country: 'Colombia',
  },
  {
    portName: 'BUENOS AIRES, ARGENTINA',
    portCode: 'AR BUE',
    country: 'Argentina',
  },
  {
    portName: 'BUNDABERG, AUSTRALIA',
    portCode: 'AU BDB',
    country: 'Australia',
  },
  {
    portName: 'BURNABY, CANADA',
    portCode: 'CA BUB',
    country: 'Canada',
  },
  {
    portName: 'BUSAN, SOUTH KOREA',
    portCode: 'KR PUS',
    country: 'Republic of Korea',
  },
  {
    portName: 'BUTTERWORTH, MALAYSIA',
    portCode: 'MY WOT',
    country: 'Malaysia',
  },
  {
    portName: 'CABO SAN LUCAS, MEXICO',
    portCode: 'MX CSL',
    country: 'Mexico',
  },
  {
    portName: 'CALBAYOG, PHILIPPINES',
    portCode: 'PH CBY',
    country: 'Philippines',
  },
  {
    portName: 'CALDERA, CHILE',
    portCode: 'CL CLD',
    country: 'Chile',
  },
  {
    portName: 'CALDERA, COSTA RICA',
    portCode: 'CR CAL',
    country: 'Costa Rica',
  },
  {
    portName: 'CALETA CORDOBA, ARGENTINA',
    portCode: 'AR CLC',
    country: 'Argentina',
  },
  {
    portName: 'CALETA PATILLOS, CHILE',
    portCode: 'CL CAL',
    country: 'Chile',
  },
  {
    portName: 'CALLAO, PERU',
    portCode: 'PE CLL',
    country: 'Peru',
  },
  {
    portName: 'CAM PHA, VIET NAM',
    portCode: 'VN CPH',
    country: 'Viet Nam',
  },
  {
    portName: 'CAMDEN, NJ',
    portCode: 'US CDE',
    country: 'United States of America',
  },
  {
    portName: 'CAPE CANAVERAL, FL',
    portCode: 'US CPV',
    country: 'United States of America',
  },
  {
    portName: 'CARPINTERIA, CA',
    portCode: 'US CPT',
    country: 'United States of America',
  },
  {
    portName: 'CARTAGENA, COLOMBIA',
    portCode: 'CO CTG',
    country: 'Colombia',
  },
  {
    portName: 'CATALINA ISLAND, CA',
    portCode: 'US CKI',
    country: 'United States of America',
  },
  {
    portName: 'CEBU, PHILIPPINES',
    portCode: 'PH CEB',
    country: 'Philippines',
  },
  {
    portName: 'CEDROS ISLAND, MEXICO',
    portCode: 'MX CRI',
    country: 'Mexico',
  },
  {
    portName: 'CEDROS, MEXICO',
    portCode: 'MX CED',
    country: 'Mexico',
  },
  {
    portName: 'CHANGSHU POINT, CHINA',
    portCode: 'CN CGS',
    country: "People's Republic of China",
  },
  {
    portName: 'CHANGZHOU, CHINA',
    portCode: 'CN CZX',
    country: "People's Republic of China",
  },
  {
    portName: 'CHAOZHOU, CHINA',
    portCode: 'CN COZ',
    country: "People's Republic of China",
  },
  {
    portName: 'CHARLESTON, SC',
    portCode: 'US CHS',
    country: 'United States of America',
  },
  {
    portName: 'CHEMAINUS, CANADA',
    portCode: 'CA CHM',
    country: 'Canada',
  },
  {
    portName: 'CHENNAI, INDIA',
    portCode: 'IN MAA',
    country: 'India',
  },
  {
    portName: 'CHIBA, JAPAN',
    portCode: 'JP CHB',
    country: 'Japan',
  },
  {
    portName: 'CHIMBOTE, PERU',
    portCode: 'PE CHM',
    country: 'Peru',
  },
  {
    portName: 'CHITA, JAPAN',
    portCode: 'JP CTA',
    country: 'Japan',
  },
  {
    portName: 'CHITTAGONG, BANGLADESH',
    portCode: 'BD CGP',
    country: 'Bangladesh',
  },
  {
    portName: 'CIENFUEGOS, CUBA',
    portCode: 'CU CFG',
    country: 'Cuba',
  },
  {
    portName: 'CLATSKANIE, OR',
    portCode: 'US YCK',
    country: 'United States of America',
  },
  {
    portName: 'COMODORO RIVADAVIA, ARGENTINA',
    portCode: 'AR CRD',
    country: 'Argentina',
  },
  {
    portName: 'CONCHAN, PERU',
    portCode: 'PE CON',
    country: 'Peru',
  },
  {
    portName: 'CONVENT, LA',
    portCode: 'US CEN',
    country: 'United States of America',
  },
  {
    portName: 'COOS BAY, OR',
    portCode: 'US COB',
    country: 'United States of America',
  },
  {
    portName: 'COPENHAGEN, DENMARK',
    portCode: 'DK CPH',
    country: 'Denmark',
  },
  {
    portName: 'CORINTO, NICARAGUA',
    portCode: 'NI CIO',
    country: 'Nicaragua',
  },
  {
    portName: 'CORONEL, CHILE',
    portCode: 'CL CNL',
    country: 'Chile',
  },
  {
    portName: 'CORPUS CHRISTI, TX',
    portCode: 'US CRP',
    country: 'United States of America',
  },
  {
    portName: 'COVENAS, COLOMBIA',
    portCode: 'CO COV',
    country: 'Colombia',
  },
  {
    portName: 'CROFTON, CANADA',
    portCode: 'CA CRO',
    country: 'Canada',
  },
  {
    portName: 'CURACAO, NETHERLANDS ANTILLES',
    portCode: 'AN CUR',
    country: 'Netherlands Antilles',
  },
  {
    portName: 'DALIAN, CHINA',
    portCode: 'CN DLC',
    country: "People's Republic of China",
  },
  {
    portName: 'DANGJIN-GUN, SOUTH KOREA',
    portCode: 'KR TJI',
    country: 'Republic of Korea',
  },
  {
    portName: 'DARNAH, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY DRX',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'DARWIN, AUSTRALIA',
    portCode: 'AU DRW',
    country: 'Australia',
  },
  {
    portName: 'DAVAO, PHILIPPINES',
    portCode: 'PH DVO',
    country: 'Philippines',
  },
  {
    portName: 'DEMOCRATIC REPUBLIC',
    portCode: 'OF THE',
    country: 'CONGO',
  },
  {
    portName: 'DIEGO GARCIA, BRITISH INDIAN OCEAN TERRITORY',
    portCode: 'IO DGA',
    country: 'British Indian Ocean Territory',
  },
  {
    portName: 'DILISKELESI, TURKEY',
    portCode: 'TR DIL',
    country: 'Turkey',
  },
  {
    portName: 'DONALDSONVILLE, LA',
    portCode: 'US DNA',
    country: 'United States of America',
  },
  {
    portName: 'DONGHAE, SOUTH KOREA',
    portCode: 'KR TGH',
    country: 'Republic of Korea',
  },
  {
    portName: 'DRIFT RIVER, AK',
    portCode: 'US DRF',
    country: 'United States of America',
  },
  {
    portName: 'DUMAI, INDONESIA',
    portCode: 'ID DUM',
    country: 'Indonesia',
  },
  {
    portName: 'DUNCAN BAY, CANADA',
    portCode: 'CA DCN',
    country: 'Canada',
  },
  {
    portName: 'DUTCH HARBOR, AK',
    portCode: 'US DUT',
    country: 'United States of America',
  },
  {
    portName: 'EDMONDS, WA',
    portCode: 'US EOW',
    country: 'United States of America',
  },
  {
    portName: 'EL BOURI, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY BOU',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'EL CHOMS, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY ELK',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'EL SEGUNDO, CA',
    portCode: 'US ELS',
    country: 'United States of America',
  },
  {
    portName: 'ENSENADA, MEXICO',
    portCode: 'MX ESE',
    country: 'Mexico',
  },
  {
    portName: 'EREGLI, TURKEY',
    portCode: 'TR ELI',
    country: 'Turkey',
  },
  {
    portName: 'ESMERALDAS, ECUADOR',
    portCode: 'EC ESM',
    country: 'Ecuador',
  },
  {
    portName: 'ESTERO BAY, CA',
    portCode: 'US ESB',
    country: 'United States of America',
  },
  {
    portName: 'EUREKA, CA',
    portCode: 'US EKA',
    country: 'United States of America',
  },
  {
    portName: 'EVERETT, WA',
    portCode: 'US PAE',
    country: 'United States of America',
  },
  {
    portName: 'FANGCHENG, CHINA',
    portCode: 'CN FAN',
    country: "People's Republic of China",
  },
  {
    portName: 'FERNDALE, WA',
    portCode: 'US FDT',
    country: 'United States of America',
  },
  {
    portName: 'FORT LAUDERDALE, FL',
    portCode: 'US FLL',
    country: 'United States of America',
  },
  {
    portName: 'FORT PIERCE, FL',
    portCode: 'US FPR',
    country: 'United States of America',
  },
  {
    portName: 'FREEPORT, BAHAMAS',
    portCode: 'BS FPO',
    country: 'Bahamas',
  },
  {
    portName: 'FREEPORT, TX',
    portCode: 'US FPO',
    country: 'United States of America',
  },
  {
    portName: 'FREMANTLE, AUSTRALIA',
    portCode: 'AU FRE',
    country: 'Australia',
  },
  {
    portName: 'FUJI, JAPAN',
    portCode: 'JP FUI',
    country: 'Japan',
  },
  {
    portName: 'FUKISHIMA, JAPAN',
    portCode: 'JP FKF',
    country: 'Japan',
  },
  {
    portName: 'FUKUYAMA, JAPAN',
    portCode: 'JP FKY',
    country: 'Japan',
  },
  {
    portName: 'FUQING, CHINA',
    portCode: 'CN FUG',
    country: "People's Republic of China",
  },
  {
    portName: 'FUZHOU, CHINA',
    portCode: 'CN FOC',
    country: "People's Republic of China",
  },
  {
    portName: 'GALVESTON, TX',
    portCode: 'US GLS',
    country: 'United States of America',
  },
  {
    portName: 'GAMBA, GABON',
    portCode: 'GA GAX',
    country: 'Gabon',
  },
  {
    portName: 'GAOGANG, CHINA',
    portCode: 'CN GAO',
    country: "People's Republic of China",
  },
  {
    portName: 'GDANSK, POLAND',
    portCode: 'PL GDN',
    country: 'Poland',
  },
  {
    portName: 'GEELONG, AUSTRALIA',
    portCode: 'AU GEX',
    country: 'Australia',
  },
  {
    portName: 'GERALDTON, AUSTRALIA',
    portCode: 'AU GET',
    country: 'Australia',
  },
  {
    portName: 'GHENT, BELGIUM',
    portCode: 'BE GNE',
    country: 'Belgium',
  },
  {
    portName: 'GOLD RIVER, CANADA',
    portCode: 'CA GOR',
    country: 'Canada',
  },
  {
    portName: 'GRAMERCY, LA',
    portCode: 'US GRY',
    country: 'United States of America',
  },
  {
    portName: 'GRAYS HARBOR, WA',
    portCode: 'US GHC',
    country: 'United States of America',
  },
  {
    portName: 'GREYS HARBOR, WA',
    portCode: 'US GHC',
    country: 'United States of America',
  },
  {
    portName: 'GUANGZHOU, CHINA',
    portCode: 'CN CAN',
    country: "People's Republic of China",
  },
  {
    portName: 'GUAYAQUIL, ECUADOR',
    portCode: 'EC GYE',
    country: 'Ecuador',
  },
  {
    portName: 'GUAYMAS, MEXICO',
    portCode: 'MX GYM',
    country: 'Mexico',
  },
  {
    portName: 'GULFITO, COSTA RICA',
    portCode: 'CR GLF',
    country: 'Costa Rica',
  },
  {
    portName: 'GULFPORT, MS',
    portCode: 'US GPT',
    country: 'United States of America',
  },
  {
    portName: 'GUNSAN, SOUTH KOREA',
    portCode: 'KR KUV',
    country: 'Republic of Korea',
  },
  {
    portName: 'GWANGYANG, SOUTH KOREA',
    portCode: 'KR KAN',
    country: 'Republic of Korea',
  },
  {
    portName: 'HACHINOHE, JAPAN',
    portCode: 'JP HHE',
    country: 'Japan',
  },
  {
    portName: 'HAINES, AK',
    portCode: 'US HNS',
    country: 'United States of America',
  },
  {
    portName: 'HAKATA, JAPAN',
    portCode: 'JP HTD',
    country: 'Japan',
  },
  {
    portName: 'HALIFAX, CANADA',
    portCode: 'CA HAL',
    country: 'Canada',
  },
  {
    portName: 'HAMPTON ROADS, VA',
    portCode: 'US PHF',
    country: 'United States of America',
  },
  {
    portName: 'HARMAC, CANADA',
    portCode: 'CA HMC',
    country: 'Canada',
  },
  {
    portName: 'HAWK INLET, AK',
    portCode: 'US HZZ',
    country: 'United States of America',
  },
  {
    portName: 'HIGASHIHARIMA, JAPAN',
    portCode: 'JP HHR',
    country: 'Japan',
  },
  {
    portName: 'HIKOSHIMA, JAPAN',
    portCode: 'JP HIS',
    country: 'Japan',
  },
  {
    portName: 'HILO, HI',
    portCode: 'US ITO',
    country: 'United States of America',
  },
  {
    portName: 'HIROSHIMA, JAPAN',
    portCode: 'JP HIJ',
    country: 'Japan',
  },
  {
    portName: 'HITACHINAKA, JAPAN',
    portCode: 'JP HIC',
    country: 'Japan',
  },
  {
    portName: 'HOKUTO, JAPAN',
    portCode: 'JP HOO',
    country: 'Japan',
  },
  {
    portName: 'HOMER, AK',
    portCode: 'US HOM',
    country: 'United States of America',
  },
  {
    portName: 'HONOLULU, HI',
    portCode: 'US HNL',
    country: 'United States of America',
  },
  {
    portName: 'HOQUIAM, WA',
    portCode: 'US HQM',
    country: 'United States of America',
  },
  {
    portName: 'HOUSTON, TX',
    portCode: 'US HOU',
    country: 'United States of America',
  },
  {
    portName: 'HUNGNAM, NORTH KOREA',
    portCode: 'KP HGM',
    country: "Korea, Democratic People's Republic of",
  },
  {
    portName: 'ICHIHARA, JAPAN',
    portCode: 'JP ICH',
    country: 'Japan',
  },
  {
    portName: 'HOONAH, AK',
    portCode: 'US HNH',
    country: 'United States of America',
  },
  {
    portName: 'ILIGAN, PHILIPPINES',
    portCode: 'PH IGN',
    country: 'Philippines',
  },
  {
    portName: 'INCHEON, SOUTH KOREA',
    portCode: 'KR ICH',
    country: 'Republic of Korea',
  },
  {
    portName: 'IQUIQUE, CHILE',
    portCode: 'CL IQQ',
    country: 'Chile',
  },
  {
    portName: 'IRAGO, JAPAN',
    portCode: 'JP IRK',
    country: 'Japan',
  },
  {
    portName: 'ISHINOMAKI, JAPAN',
    portCode: 'JP ISM',
    country: 'Japan',
  },
  {
    portName: 'ISLA SAN MARCOS, MEXICO',
    portCode: 'MX SMI',
    country: 'Mexico',
  },
  {
    portName: 'ISLE',
    portCode: 'OF MAN',
    country: 'IM',
  },
  {
    portName: 'IWAKUNI, JAPAN',
    portCode: 'JP  IWK',
    country: 'Japan',
  },
  {
    portName: 'IYOMISHIMA, JAPAN',
    portCode: 'JP IYM',
    country: 'Japan',
  },
  {
    portName: 'JACKSONVILLE, FL',
    portCode: 'US JAX',
    country: 'United States of America',
  },
  {
    portName: 'JAKARTA, INDONESIA',
    portCode: 'ID JKT',
    country: 'Indonesia',
  },
  {
    portName: 'JIANGYIN, CHINA',
    portCode: 'CN JIA',
    country: "People's Republic of China",
  },
  {
    portName: 'MINOR OUTLYING ISLANDS',
    portCode: 'UM JON',
    country: 'United States Minor Outlying Islands',
  },
  {
    portName: 'JUBAIL, SAUDI ARABIA',
    portCode: 'SA JUB',
    country: 'Saudi Arabia',
  },
  {
    portName: 'JUNEAU, AK',
    portCode: 'US JNU',
    country: 'United States of America',
  },
  {
    portName: 'KAGOSHIMA, JAPAN',
    portCode: 'JP KOJ',
    country: 'Japan',
  },
  {
    portName: 'KAHULUI, HI',
    portCode: 'US OGG',
    country: 'United States of America',
  },
  {
    portName: 'KAKOGAWA, JAPAN',
    portCode: 'JP KGA',
    country: 'Japan',
  },
  {
    portName: 'KALAMA, WA',
    portCode: 'US KAM',
    country: 'United States of America',
  },
  {
    portName: 'KALUNDBORG, DENMARK',
    portCode: 'DK KAL',
    country: 'Denmark',
  },
  {
    portName: 'KANDA, JAPAN',
    portCode: 'JP KND',
    country: 'Japan',
  },
  {
    portName: 'KANMON, JAPAN',
    portCode: 'JP KNM',
    country: 'Japan',
  },
  {
    portName: 'KAOHSIUNG, TAIWAN',
    portCode: 'TW KHH',
    country: 'Taiwan',
  },
  {
    portName: 'KARACHI CONTAINER TERMINAL, PAKISTAN',
    portCode: 'PK KCT',
    country: 'Pakistan',
  },
  {
    portName: 'KARACHI, PAKISTAN',
    portCode: 'PK KHI',
    country: 'Niue',
  },
  {
    portName: 'KASHIMA, JAPAN',
    portCode: 'JP KSM',
    country: 'Japan',
  },
  {
    portName: 'KAWAIHAE, HI',
    portCode: 'US KWH',
    country: 'United States of America',
  },
  {
    portName: 'KAWANOE, JAPAN',
    portCode: 'JP KWN',
    country: 'Japan',
  },
  {
    portName: 'KAWASAKI, JAPAN',
    portCode: 'JP KWS',
    country: 'Japan',
  },
  {
    portName: 'KEELUNG, TAIWAN',
    portCode: 'TW KEL',
    country: 'Taiwan',
  },
  {
    portName: 'KELANG',
    portCode: 'MY KEL',
    country: 'Malaysia',
  },
  {
    portName: 'KENAI, AK',
    portCode: 'US ENA',
    country: 'United States of America',
  },
  {
    portName: 'KETCHIKAN, AK',
    portCode: 'US KTN',
    country: 'United States of America',
  },
  {
    portName: 'KIMITSU, JAPAN',
    portCode: 'JP KMT',
    country: 'Japan',
  },
  {
    portName: 'KINGSTON, JAMAICA',
    portCode: 'JM KIN',
    country: 'Jamaica',
  },
  {
    portName: 'KINUURA, JAPAN',
    portCode: 'JP KNU',
    country: 'Japan',
  },
  {
    portName: 'KISKA ISLAND, AK',
    portCode: 'US KIS',
    country: 'United States of America',
  },
  {
    portName: 'KITIMAT, CANADA',
    portCode: 'CA KTM',
    country: 'Canada',
  },
  {
    portName: 'KLAIPEDIA, LITHUANIA',
    portCode: 'LT KLI',
    country: 'Lithuania',
  },
  {
    portName: 'KOBE, JAPAN',
    portCode: 'JP UKB',
    country: 'Japan',
  },
  {
    portName: 'KODIAK, AK',
    portCode: 'US ADQ',
    country: 'United States of America',
  },
  {
    portName: 'KOMATSUSHIMA, JAPAN',
    portCode: 'JP KOM',
    country: 'Japan',
  },
  {
    portName: 'KOTA KINABALU, MALAYSIA',
    portCode: 'MY BKI',
    country: 'Malaysia',
  },
  {
    portName: 'KOZMINO PORT, RUSSIAN FEDERATION',
    portCode: 'RU KZM',
    country: 'Russian Federation',
  },
  {
    portName: 'KUANTAN, MALAYSIA',
    portCode: 'MY KUA',
    country: 'Malaysia',
  },
  {
    portName: 'KURE, JAPAN',
    portCode: 'JP KRE',
    country: 'Japan',
  },
  {
    portName: 'KWANGYANG, SOUTH KOREA',
    portCode: 'KR KWA',
    country: 'Republic of Korea',
  },
  {
    portName: 'KWINANA, AUSTRALIA',
    portCode: 'AU KWI',
    country: 'Australia',
  },
  {
    portName: 'LA LIBERTAD, ECUADOR',
    portCode: 'EC LLD',
    country: 'Ecuador',
  },
  {
    portName: 'LA PALOMA, URAGUAY',
    portCode: 'UY LAP',
    country: 'Uruguay',
  },
  {
    portName: 'LA PAMPILLA, PERU',
    portCode: 'PE LPP',
    country: 'Peru',
  },
  {
    portName: 'LA PAZ, MEXICO',
    portCode: 'MX LAP',
    country: 'Mexico',
  },
  {
    portName: 'LAE, PAPUA NEW GUINEA',
    portCode: 'PG LAE',
    country: 'Papua New Guinea',
  },
  {
    portName: 'LAEM CHABANG, THAILAND',
    portCode: 'TH LCH',
    country: 'Thailand',
  },
  {
    portName: 'LAHAD DATU, MALAYSIA',
    portCode: 'MY LDU',
    country: 'Malaysia',
  },
  {
    portName: 'LAHAINA, HI',
    portCode: 'US LHN',
    country: 'United States of America',
  },
  {
    portName: 'LAIZHOU, CHINA',
    portCode: 'CN LZO',
    country: "People's Republic of China",
  },
  {
    portName: 'LAKE CHARLES, LA',
    portCode: 'US LCH',
    country: 'United States of America',
  },
  {
    portName: 'LANSHAN, CHINA',
    portCode: 'CN LSN',
    country: "People's Republic of China",
  },
  {
    portName: 'LAS VENTANAS, CHILE',
    portCode: 'CL LVS',
    country: 'Chile',
  },
  {
    portName: 'LAUTOKA, FIJI',
    portCode: 'FJ LTK',
    country: 'Fiji',
  },
  {
    portName: 'LAZARO CARDENAS, MEXICO',
    portCode: 'MX LZC',
    country: 'Mexico',
  },
  {
    portName: 'LE HAVRE, FRANCE',
    portCode: 'FR LEH',
    country: 'France',
  },
  {
    portName: 'LIANYUNGANG, CHINA',
    portCode: 'CN LYG',
    country: "People's Republic of China",
  },
  {
    portName: 'LIMBOH TERMINAL, CAMEROON',
    portCode: 'CM LIT',
    country: 'Cameroon',
  },
  {
    portName: 'LIVERPOOL, UNITED KINGDOM',
    portCode: 'GB LIV',
    country: 'United Kingdom',
  },
  {
    portName: 'LONDON, UNITED KINGDOM',
    portCode: 'GB LON',
    country: 'United Kingdom',
  },
  {
    portName: 'LONG BEACH, CA',
    portCode: 'US LGB',
    country: 'United States of America',
  },
  {
    portName: 'LONGVIEW, WA',
    portCode: 'US LOG',
    country: 'United States of America',
  },
  {
    portName: 'LOS ANGELES, CA',
    portCode: 'US LAX',
    country: 'United States of America',
  },
  {
    portName: 'LUCINDA, AUSTRALIA',
    portCode: 'AU LUC',
    country: 'Australia',
  },
  {
    portName: 'LYTTELTON, NEW ZEALAND',
    portCode: 'NZ LYT',
    country: 'New Zealand',
  },
  {
    portName: 'MACKAY, AUSTRALIA',
    portCode: 'AU MKY',
    country: 'Australia',
  },
  {
    portName: 'MAI-LIAO, TAIWAN',
    portCode: 'TW MLI',
    country: 'Taiwan',
  },
  {
    portName: 'MAIZURU, JAPAN',
    portCode: 'JP MAI',
    country: 'Japan',
  },
  {
    portName: 'MAJURO, MARSHALL ISLANDS',
    portCode: 'MH MAJ',
    country: 'Marshall Islands',
  },
  {
    portName: 'MANCHESTER, WA',
    portCode: 'US MCR',
    country: 'United States of America',
  },
  {
    portName: 'MANILA, PHILIPPINES',
    portCode: 'PH MNL',
    country: 'Philippines',
  },
  {
    portName: 'MANTA, ECUADOR',
    portCode: 'EC MEC',
    country: 'Ecuador',
  },
  {
    portName: 'MANZANILLO, MEXICO',
    portCode: 'MX ZLO',
    country: 'Mexico',
  },
  {
    portName: 'MARSA BREGA, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY LMQ',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'MARSA EL HANIA, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY MEH',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'MARSA EL HARIGA, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY MHR',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'MARTINEZ, CA',
    portCode: 'US MRZ',
    country: 'United States of America',
  },
  {
    portName: 'MASAN, SOUTH KOREA',
    portCode: 'KR MAS',
    country: 'Republic of Korea',
  },
  {
    portName: 'MATSUURA, JAPAN',
    portCode: 'JP MTS',
    country: 'Japan',
  },
  {
    portName: 'MATSUYAMA, JAPAN',
    portCode: 'JP MYJ',
    country: 'Japan',
  },
  {
    portName: 'MAZATLAN, MEXICO',
    portCode: 'MX MZT',
    country: 'Mexico',
  },
  {
    portName: 'MEJILLONES, CHILE',
    portCode: 'CL MJS',
    country: 'Chile',
  },
  {
    portName: 'MELBOURNE, AUSTRALIA',
    portCode: 'AU MEL',
    country: 'Australia',
  },
  {
    portName: 'MELITTAH, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY MTH',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'MERAK, INDONESIA',
    portCode: 'ID MRK',
    country: 'Indonesia',
  },
  {
    portName: 'MERSIN, TURKEY',
    portCode: 'TR MER',
    country: 'Turkey',
  },
  {
    portName: 'METLAKATLA, AK',
    portCode: 'US MTM',
    country: 'United States of America',
  },
  {
    portName: 'MIAMI, FL',
    portCode: 'US MIA',
    country: 'United States of America',
  },
  {
    portName: 'MIIKE, JAPAN',
    portCode: 'JP MII',
    country: 'Japan',
  },
  {
    portName: 'MIKAWA, JAPAN',
    portCode: 'JP MKW',
    country: 'Japan',
  },
  {
    portName: 'MISHIMA, JAPAN',
    portCode: 'JP MKX',
    country: 'Japan',
  },
  {
    portName: 'MISUMI, JAPAN',
    portCode: 'JP MMI',
    country: 'Japan',
  },
  {
    portName: 'MISURATA, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY MRA',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'MIYAZAKI, JAPAN',
    portCode: 'JP KMI',
    country: 'Japan',
  },
  {
    portName: 'MIZUSHIMA, JAPAN',
    portCode: 'JP MIZ',
    country: 'Japan',
  },
  {
    portName: 'MOBILE, AL',
    portCode: 'US MOB',
    country: 'United States of America',
  },
  {
    portName: 'MOKPO, SOUTH KOREA',
    portCode: 'KR MOK',
    country: 'Republic of Korea',
  },
  {
    portName: 'MONROE, MI',
    portCode: 'US MOI',
    country: 'United States of America',
  },
  {
    portName: 'MORRO BAY, CA',
    portCode: 'US MJK',
    country: 'United States of America',
  },
  {
    portName: 'MOSS LANDING, CA',
    portCode: 'US MLG',
    country: 'United States of America',
  },
  {
    portName: 'MOURILYAN, AUSTRALIA',
    portCode: 'AU MOU',
    country: 'Australia',
  },
  {
    portName: 'MUKILTEO, WA',
    portCode: 'US MKI',
    country: 'United States of America',
  },
  {
    portName: 'MURORAN, JAPAN',
    portCode: 'JP MUR',
    country: 'Japan',
  },
  {
    portName: 'MUUGA, ESTONIA',
    portCode: 'EE MUG',
    country: 'Estonia',
  },
  {
    portName: 'NADAHAMA, JAPAN',
    portCode: 'JP NAD',
    country: 'Japan',
  },
  {
    portName: 'NAGAHAMA, JAPAN',
    portCode: 'JP NGH',
    country: 'Japan',
  },
  {
    portName: 'NAGASAKI, JAPAN',
    portCode: 'JP NGS',
    country: 'Japan',
  },
  {
    portName: 'NAGOYA, JAPAN',
    portCode: 'JP NGY',
    country: 'Japan',
  },
  {
    portName: 'NAHA, JAPAN',
    portCode: 'JP NAH',
    country: 'Japan',
  },
  {
    portName: 'NAKHODKA, RUSSIAN FEDERATION',
    portCode: 'RU NJK',
    country: 'Russian Federation',
  },
  {
    portName: 'NANAIMO, CANADA',
    portCode: 'CA NNO',
    country: 'Canada',
  },
  {
    portName: 'NANJING, CHINA',
    portCode: 'CN NJG',
    country: "People's Republic of China",
  },
  {
    portName: 'NANSHA, CHINA',
    portCode: 'CN NSA',
    country: "People's Republic of China",
  },
  {
    portName: 'NANTONG, CHINA',
    portCode: 'CN NTG',
    country: "People's Republic of China",
  },
  {
    portName: 'NAOETSU, JAPAN',
    portCode: 'JP NAO',
    country: 'Japan',
  },
  {
    portName: 'NAPLES, ITALY',
    portCode: 'IT NAP',
    country: 'Italy',
  },
  {
    portName: 'NAWILIWILI, HI',
    portCode: 'US NIJ',
    country: 'United States of America',
  },
  {
    portName: 'NEMRUT BAY, TURKEY',
    portCode: 'TR NEM',
    country: 'Turkey',
  },
  {
    portName: 'NEW LONDON, CT',
    portCode: 'US NLO',
    country: 'United States of America',
  },
  {
    portName: 'NEW ORLEANS, LA',
    portCode: 'US MSY',
    country: 'United States of America',
  },
  {
    portName: 'NEW WESTMINSTER, CANADA',
    portCode: 'CA NWE',
    country: 'Canada',
  },
  {
    portName: 'NEW YORK CITY, NY',
    portCode: 'US NYC',
    country: 'United States of America',
  },
  {
    portName: 'NEWARK, NJ',
    portCode: 'US EWR',
    country: 'United States of America',
  },
  {
    portName: 'NEWPORT NEWS, VA',
    portCode: 'US NNS',
    country: 'United States of America',
  },
  {
    portName: 'NEWPORT, OR',
    portCode: 'US NPO',
    country: 'United States of America',
  },
  {
    portName: 'NIIGATA, JAPAN',
    portCode: 'JP KIJ',
    country: 'Japan',
  },
  {
    portName: 'NIIHAMA, JAPAN',
    portCode: 'JP IHA',
    country: 'Japan',
  },
  {
    portName: 'NIKISKI, AK',
    portCode: 'US NIK',
    country: 'United States of America',
  },
  {
    portName: 'NINGBO, CHINA',
    portCode: 'CN NGB',
    country: "People's Republic of China",
  },
  {
    portName: 'NORFOLK, VA',
    portCode: 'US ORF',
    country: 'United States of America',
  },
  {
    portName: 'NOVGOROD, RUSSIAN FEDERATION',
    portCode: 'RU NVR',
    country: 'Russian Federation',
  },
  {
    portName: 'NOVOROSSISK, RUSSIAN FEDERATION',
    portCode: 'RU NVS',
    country: 'Russian Federation',
  },
  {
    portName: 'NUEVA PALMIRA, URUGUAY',
    portCode: 'UY NVP',
    country: 'Uruguay',
  },
  {
    portName: 'OAKLAND, CA',
    portCode: 'US OAK',
    country: 'United States of America',
  },
  {
    portName: 'OCEAN FALLS, CANADA',
    portCode: 'CA OFA',
    country: 'Canada',
  },
  {
    portName: 'OFUNATO, JAPAN',
    portCode: 'JP OFT',
    country: 'Japan',
  },
  {
    portName: 'OGDENSBURG, NY',
    portCode: 'US OGS',
    country: 'United States of America',
  },
  {
    portName: 'OITA, JAPAN',
    portCode: 'JP OIT',
    country: 'Japan',
  },
  {
    portName: 'OKINAWA, JAPAN',
    portCode: 'JP OKA',
    country: 'Japan',
  },
  {
    portName: 'OLYMPIA, WA',
    portCode: 'US OLM',
    country: 'United States of America',
  },
  {
    portName: 'ONAHAMA, JAPAN',
    portCode: 'JP ONA',
    country: 'Japan',
  },
  {
    portName: 'ONOMICHI, JAPAN',
    portCode: 'JP ONO',
    country: 'Japan',
  },
  {
    portName: 'ORANGE, TX',
    portCode: 'US ORG',
    country: 'United States of America',
  },
  {
    portName: 'OSAKA, JAPAN',
    portCode: 'JP OSA',
    country: 'Japan',
  },
  {
    portName: 'OSWEGO, NY',
    portCode: 'US OSW',
    country: 'United States of America',
  },
  {
    portName: 'OTARU, JAPAN',
    portCode: 'JP OTR',
    country: 'Japan',
  },
  {
    portName: 'PALM BEACH, FL',
    portCode: 'US PAB',
    country: 'United States of America',
  },
  {
    portName: 'PANAMA CITY, FL',
    portCode: 'US PFN',
    country: 'United States of America',
  },
  {
    portName: 'PAPEETE, TAHITI, FRENCH POLYNESIA',
    portCode: 'PF PPT',
    country: 'French Polynesia',
  },
  {
    portName: 'PASCAGOULA, MS',
    portCode: 'US PGL',
    country: 'United States of America',
  },
  {
    portName: 'PEARL HARBOR, HI',
    portCode: 'US PEA',
    country: 'United States of America',
  },
  {
    portName: 'PENANG, MALAYSIA',
    portCode: 'MY PEN',
    country: 'Malaysia',
  },
  {
    portName: 'PENSACOLA, FL',
    portCode: 'US PNS',
    country: 'United States of America',
  },
  {
    portName: 'PHILADELPHIA, PA',
    portCode: 'US PHL',
    country: 'United States of America',
  },
  {
    portName: 'PHU MY, VIET NAM',
    portCode: 'VN PHU',
    country: 'Viet Nam',
  },
  {
    portName: 'PITTSBURG, CA',
    portCode: 'US PBG',
    country: 'United States of America',
  },
  {
    portName: 'PLAQUEMINE, LA',
    portCode: 'US PLQ',
    country: 'United States of America',
  },
  {
    portName: 'POHANG, SOUTH KOREA',
    portCode: 'KR KPO',
    country: 'Republic of Korea',
  },
  {
    portName: 'POHNPEI, FEDERATED STATES OF MICRONESIA',
    portCode: 'FM PNI',
    country: 'Micronesia, Federated States of',
  },
  {
    portName: 'POINT COMFORT, TX',
    portCode: 'US PCR',
    country: 'United States of America',
  },
  {
    portName: 'POINT LISAS, TRINIDAD AND TOBAGO',
    portCode: 'TT PTS',
    country: 'Trinidad and Tobago',
  },
  {
    portName: 'PORT ALBERNI, CANADA',
    portCode: 'CA PAB',
    country: 'Canada',
  },
  {
    portName: 'PORT ALICE, CANADA',
    portCode: 'CA PAC',
    country: 'Canada',
  },
  {
    portName: 'PORT ANGELES, WA',
    portCode: 'US CLM',
    country: 'United States of America',
  },
  {
    portName: 'PORT ARTHUR, TX',
    portCode: 'US POA',
    country: 'United States of America',
  },
  {
    portName: 'PORT CLARENCE, AK',
    portCode: 'US KPC',
    country: 'United States of America',
  },
  {
    portName: 'PORT EVERGLADES, FL',
    portCode: 'US PEF',
    country: 'United States of America',
  },
  {
    portName: 'PORT GAMBLE, WA',
    portCode: 'US PGH',
    country: 'United States of America',
  },
  {
    portName: 'PORT HARDY, CANADA',
    portCode: 'CA PHY',
    country: 'Canada',
  },
  {
    portName: 'PORT HUENEME, CA',
    portCode: 'US NTD',
    country: 'United States of America',
  },
  {
    portName: 'PORT ISABEL, TX',
    portCode: 'US PIS',
    country: 'United States of America',
  },
  {
    portName: 'PORT KEMBLA, AUSTRALIA',
    portCode: 'AU PKL',
    country: 'Australia',
  },
  {
    portName: 'PORT KLANG, MALAYSIA',
    portCode: 'MY PKG',
    country: 'Malaysia',
  },
  {
    portName: 'PORT MANATEE, FL',
    portCode: 'US PME',
    country: 'United States of America',
  },
  {
    portName: 'PORT MCNEILL, CANADA',
    portCode: 'CA PMA',
    country: 'Canada',
  },
  {
    portName: 'PORT MELLON, CANADA',
    portCode: 'CA PML',
    country: 'Canada',
  },
  {
    portName: 'PORT MOODY, CANADA',
    portCode: 'CA PMO',
    country: 'Canada',
  },
  {
    portName: 'MARY, FRANKLIN, LA',
    portCode: 'US RNK',
    country: 'United States of America',
  },
  {
    portName: 'PORT TOWNSEND, WA',
    portCode: 'US TWD',
    country: 'United States of America',
  },
  {
    portName: 'PORTLAND, OR',
    portCode: 'US PDX',
    country: 'United States of America',
  },
  {
    portName: 'PORTSMOUTH, NH',
    portCode: 'US PSM',
    country: 'United States of America',
  },
  {
    portName: 'POWELL RIVER, CANADA',
    portCode: 'CA POW',
    country: 'Canada',
  },
  {
    portName: 'PRINCE RUPERT, CANADA',
    portCode: 'CA PRR',
    country: 'Canada',
  },
  {
    portName: 'PROVIDENCE, RI',
    portCode: 'US PVD',
    country: 'United States of America',
  },
  {
    portName: 'PRUDHOE BAY, AK',
    portCode: 'US SCC',
    country: 'United States of America',
  },
  {
    portName: 'PUERTO ARMUELLES, PANAMA',
    portCode: 'PA AML',
    country: 'Panama',
  },
  {
    portName: 'PUERTO MORELOS, MEXICO',
    portCode: 'MX PMS',
    country: 'Mexico',
  },
  {
    portName: 'PUERTO QUETZAL, GUATEMALA',
    portCode: 'GT PRQ',
    country: 'Guatemala',
  },
  {
    portName: 'PUERTO VALLARTA, MEXICO',
    portCode: 'MX PVR',
    country: 'Mexico',
  },
  {
    portName: 'PUNTARENAS, COSTA RICA',
    portCode: 'CR PAS',
    country: 'Costa Rica',
  },
  {
    portName: 'PYEONGTAEK, SOUTH KOREA',
    portCode: 'KR PTK',
    country: 'Republic of Korea',
  },
  {
    portName: 'QINGDAO, CHINA',
    portCode: 'CN TAO',
    country: "People's Republic of China",
  },
  {
    portName: 'QINHUANGDAO, CHINA',
    portCode: 'CN SHP',
    country: "People's Republic of China",
  },
  {
    portName: 'QUANZHOU, CHINA',
    portCode: 'CN QZL',
    country: "People's Republic of China",
  },
  {
    portName: 'QUINTERO, CHILE',
    portCode: 'CL QTV',
    country: 'Chile',
  },
  {
    portName: 'QUONSET POINT, RI',
    portCode: 'US NCO',
    country: 'United States of America',
  },
  {
    portName: 'RAINIER, OR',
    portCode: 'US RAI',
    country: 'United States of America',
  },
  {
    portName: 'RAS LANUF, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY RLA',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'RAS TANURA, SAUDI ARABIA',
    portCode: 'SA RTA',
    country: 'Saudi Arabia',
  },
  {
    portName: 'RAYONG, THAILAND',
    portCode: 'TH RYG',
    country: 'Thailand',
  },
  {
    portName: 'RECIFE, BRAZIL',
    portCode: 'BR REC',
    country: 'Brazil',
  },
  {
    portName: 'REDWOOD CITY, CA',
    portCode: 'US RWC',
    country: 'United States of America',
  },
  {
    portName: 'RICHMOND, CA',
    portCode: 'US RCH',
    country: 'United States of America',
  },
  {
    portName: 'RICHMOND, VA',
    portCode: 'US RIC',
    country: 'United States of America',
  },
  {
    portName: 'RIO DE JANIERO, BRAZIL',
    portCode: 'BR RIO',
    country: 'Brazil',
  },
  {
    portName: 'RIZHAO, CHINA',
    portCode: 'CN RZH',
    country: "People's Republic of China",
  },
  {
    portName: 'ROBERTS BANK, CANADA',
    portCode: 'CA RTB',
    country: 'Canada',
  },
  {
    portName: 'ROSARITO TERMINAL, MEXICO',
    portCode: 'MX RST',
    country: 'Mexico',
  },
  {
    portName: 'ROTTERDAM, NETHERLANDS',
    portCode: 'NL RTM',
    country: 'Netherlands',
  },
  {
    portName: 'ROXAS, PHILIPPINES',
    portCode: 'PH RXS',
    country: 'Philippines',
  },
  {
    portName: 'SACRAMENTO, CA',
    portCode: 'US SAC',
    country: 'United States of America',
  },
  {
    portName: 'SAGANOSEKI, JAPAN',
    portCode: 'JP SAG',
    country: 'Japan',
  },
  {
    portName: 'SAINT JAMES CITY, FL',
    portCode: 'US JSY',
    country: 'United States of America',
  },
  {
    portName: 'SAINT PETERSBURG PETROLESPORT',
    portCode: 'RU SPP',
    country: 'Russian Federation',
  },
  {
    portName: 'SAKAIDE, JAPAN',
    portCode: 'JP SKD',
    country: 'Japan',
  },
  {
    portName: 'SALAVERRY, PERU',
    portCode: 'PE SVY',
    country: 'Peru',
  },
  {
    portName: 'SALINA CRUZ, MEXICO',
    portCode: 'MX SCX',
    country: 'Mexico',
  },
  {
    portName: 'SAMSUN, TURKEY',
    portCode: 'TR SSX',
    country: 'Turkey',
  },
  {
    portName: 'SAN ANTONIA, CHILE',
    portCode: 'CL SAI',
    country: 'Chile',
  },
  {
    portName: 'SAN CARLOS, MEXICO',
    portCode: 'MX SCR',
    country: 'Mexico',
  },
  {
    portName: 'SAN DIEGO, CA',
    portCode: 'US SAN',
    country: 'United States of America',
  },
  {
    portName: 'SAN FRANCISCO, CA',
    portCode: 'US SFO',
    country: 'United States of America',
  },
  {
    portName: 'SAN JOSE, GUATEMALA',
    portCode: 'GT SNJ',
    country: 'Guatemala',
  },
  {
    portName: 'SAN JUAN DEL SUR',
    portCode: 'NI SJS',
    country: 'Nicaragua',
  },
  {
    portName: 'SAN JUAN, PUERTO RICO',
    portCode: 'PR SJU',
    country: 'Puerto Rico',
  },
  {
    portName: 'SAN LORENZO, ECUADOR',
    portCode: 'EC SLR',
    country: 'Ecuador',
  },
  {
    portName: 'SAN LORENZO, HOUDURAS',
    portCode: 'HN SLO',
    country: 'Honduras',
  },
  {
    portName: 'SAN NICOLAS',
    portCode: 'DE LOS',
    country: 'ARROYOS, ARGENTINA',
  },
  {
    portName: 'SAN PEDRO, ARGENTINA',
    portCode: 'AR SNP',
    country: 'Argentina',
  },
  {
    portName: 'SAN PEDRO, CA',
    portCode: 'US SPQ',
    country: 'United States of America',
  },
  {
    portName: 'SANTA BARBARA, CA',
    portCode: 'US SBA',
    country: 'United States of America',
  },
  {
    portName: 'SANTA CRUZ, CA',
    portCode: 'US SRU',
    country: 'United States of America',
  },
  {
    portName: 'SANTA ROSALIA, MEXICO',
    portCode: 'MX SRL',
    country: 'Mexico',
  },
  {
    portName: 'SANTA YNEZ, CA',
    portCode: 'US SQA',
    country: 'United States of America',
  },
  {
    portName: 'SANTOS, BRAZIL',
    portCode: 'BR SSZ',
    country: 'Brazil',
  },
  {
    portName: 'SARROCH, ITALY',
    portCode: 'IT PFX',
    country: 'Italy',
  },
  {
    portName: 'SASEBO, JAPAN',
    portCode: 'JP SSB',
    country: 'Japan',
  },
  {
    portName: 'SAVANNAH, GA',
    portCode: 'US SAV',
    country: 'United States of America',
  },
  {
    portName: 'SEATTLE, WA',
    portCode: 'US SEA',
    country: 'United States of America',
  },
  {
    portName: 'SECHELT, CANADA',
    portCode: 'CA YHS',
    country: 'Canada',
  },
  {
    portName: 'SENDAI, JAPAN',
    portCode: 'JP SDJ',
    country: 'Japan',
  },
  {
    portName: 'SEWARD, AK',
    portCode: 'US SWD',
    country: 'United States of America',
  },
  {
    portName: 'SHANGHAI, CHINA',
    portCode: 'CN SHA',
    country: "People's Republic of China",
  },
  {
    portName: 'SHEKOU, CHINA',
    portCode: 'CN SHK',
    country: "People's Republic of China",
  },
  {
    portName: 'SHENZHEN, CHINA',
    portCode: 'CN SZX',
    country: "People's Republic of China",
  },
  {
    portName: 'SHIBUSHI, JAPAN',
    portCode: 'JP SBS',
    country: 'Japan',
  },
  {
    portName: 'SHIMIZU, JAPAN',
    portCode: 'JP SMZ',
    country: 'Japan',
  },
  {
    portName: 'SHUAIBA, KUWAIT',
    portCode: 'KW SAA',
    country: 'Kuwait',
  },
  {
    portName: 'SILLAMAE, ESTONIA',
    portCode: 'EE SLM',
    country: 'Estonia',
  },
  {
    portName: 'SINT EUSTATIUS, NETHERLANDS ANTILLES',
    portCode: 'AN EUX',
    country: 'Netherlands Antilles',
  },
  {
    portName: 'SINT NICOLAAS, ARUBA',
    portCode: 'AW SNL',
    country: 'Aruba',
  },
  {
    portName: 'SINT-MAARTEN APT, NETHERLANS ANTILLES',
    portCode: 'AN SXM',
    country: 'Netherlands Antilles',
  },
  {
    portName: 'SIRTE, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY SRT',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'SISIRACHA, THAILAND',
    portCode: 'TH SRI',
    country: 'Thailand',
  },
  {
    portName: 'SITKA, AK',
    portCode: 'US SIT',
    country: 'United States of America',
  },
  {
    portName: 'SKAGWAY, AK',
    portCode: 'US SGY',
    country: 'United States of America',
  },
  {
    portName: 'SKIKDA, ALGERIA',
    portCode: 'DZ SKI',
    country: 'Algeria',
  },
  {
    portName: 'SODEGAURA, JAPAN',
    portCode: 'JP SDU',
    country: 'Japan',
  },
  {
    portName: 'SOUSSAH, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY SOU',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'SQUAMISH, CANADA',
    portCode: 'CA SQA',
    country: 'Canada',
  },
  {
    portName: 'BERNARD PARISH, LA',
    portCode: 'US SBD',
    country: 'United States of America',
  },
  {
    portName: 'JOHN, CANADA',
    portCode: 'CA YSJ',
    country: 'Canada',
  },
  {
    portName: 'PETERSBURG, RUSSIAN FEDERATION',
    portCode: 'RU LED',
    country: 'Russian Federation',
  },
  {
    portName: 'STEILACOOM, WA',
    portCode: 'US SIC',
    country: 'United States of America',
  },
  {
    portName: 'STOCKTON, CA',
    portCode: 'US SCK',
    country: 'United States of America',
  },
  {
    portName: 'SUAO, TAIWAN',
    portCode: 'TW SUO',
    country: 'Taiwan',
  },
  {
    portName: 'SUVA, FIJI',
    portCode: 'FJ SUV',
    country: 'Fiji',
  },
  {
    portName: 'SYDNEY, AUSTRALIA',
    portCode: 'AU SYD',
    country: 'Australia',
  },
  {
    portName: 'TABOGUILLA, PANAMA',
    portCode: 'PA TBG',
    country: 'Panama',
  },
  {
    portName: 'TACOMA, WA',
    portCode: 'US TIW',
    country: 'United States of America',
  },
  {
    portName: 'TAGIURA, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY TAG',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'TAHARA, JAPAN',
    portCode: 'JP TAR',
    country: 'Japan',
  },
  {
    portName: 'TAICHUNG, TAIWAN',
    portCode: 'TW TXG',
    country: 'Taiwan',
  },
  {
    portName: 'TAIPEI, TAIWAN',
    portCode: 'TW TPE',
    country: 'Taiwan',
  },
  {
    portName: 'TAIZHOU, CHINA',
    portCode: 'CN TZO',
    country: "People's Republic of China",
  },
  {
    portName: 'TAKEHARA, JAPAN',
    portCode: 'JP THR',
    country: 'Japan',
  },
  {
    portName: 'TALLINN, ESTONIA',
    portCode: 'EE TLL',
    country: 'Estonia',
  },
  {
    portName: 'TAMPA, FL',
    portCode: 'US TPA',
    country: 'United States of America',
  },
  {
    portName: 'TANGSHAN, CHINA',
    portCode: 'CN TGS',
    country: "People's Republic of China",
  },
  {
    portName: 'TARTOUS, SYRIAN ARAB REPUBLIC',
    portCode: 'SY TTS',
    country: 'Syrian Arab Republic',
  },
  {
    portName: 'TAURANGA, NEW ZEALAND',
    portCode: 'NZ TRG',
    country: 'New Zealand',
  },
  {
    portName: 'TEXAS CITY, TX',
    portCode: 'US TXT',
    country: 'United States of America',
  },
  {
    portName: 'THEODORE, AL',
    portCode: 'US TEO',
    country: 'United States of America',
  },
  {
    portName: 'TIANJIN XINGANG, CHINA',
    portCode: 'CN TXG',
    country: "People's Republic of China",
  },
  {
    portName: 'TOBRUK, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY TOB',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'TOGIAK, AK',
    portCode: 'US TGK',
    country: 'United States of America',
  },
  {
    portName: 'TOKAI, JAPAN',
    portCode: 'JP TKA',
    country: 'Japan',
  },
  {
    portName: 'TOKUYAMA, JAPAN',
    portCode: 'JP TKY',
    country: 'Japan',
  },
  {
    portName: 'TOKYO, JAPAN',
    portCode: 'JP TYO',
    country: 'Japan',
  },
  {
    portName: 'TOMAKOMAI, JAPAN',
    portCode: 'JP TMK',
    country: 'Japan',
  },
  {
    portName: 'TOPOLOBAMPO, MEXICO',
    portCode: 'MX TPB',
    country: 'Mexico',
  },
  {
    portName: 'TOULMEITHA, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY TOA',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'TOWNSVILLE, AUSTRALIA',
    portCode: 'AU TSV',
    country: 'Australia',
  },
  {
    portName: 'TOYOHASHI, JAPAN',
    portCode: 'JP THS',
    country: 'Japan',
  },
  {
    portName: 'TRENTON, NJ',
    portCode: 'US TTN',
    country: 'United States of America',
  },
  {
    portName: 'TRIPOLI, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY TIP',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'TSUKUMI, JAPAN',
    portCode: 'JP TMI',
    country: 'Japan',
  },
  {
    portName: 'TSUNEISHI, JAPAN',
    portCode: 'JP TNI',
    country: 'Japan',
  },
  {
    portName: 'TUKRAH, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY TUK',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'TUMACO, COLOMBIA',
    portCode: 'CO TCO',
    country: 'Colombia',
  },
  {
    portName: 'UBE, JAPAN',
    portCode: 'JP UBJ',
    country: 'Japan',
  },
  {
    portName: 'ULSAN, SOUTH KOREA',
    portCode: 'KR USN',
    country: 'Republic of Korea',
  },
  {
    portName: 'URAGO, JAPAN',
    portCode: 'JP UAO',
    country: 'Japan',
  },
  {
    portName: 'VALDEZ, AK',
    portCode: 'US VDZ',
    country: 'United States of America',
  },
  {
    portName: 'VALENCIA, SPAIN',
    portCode: 'ES VLC',
    country: 'Spain',
  },
  {
    portName: 'VALPARAISO, CHILE',
    portCode: 'CL VAP',
    country: 'Chile',
  },
  {
    portName: 'VANCOUVER, CANADA',
    portCode: 'CA VAN',
    country: 'Canada',
  },
  {
    portName: 'VANCOUVER, WA',
    portCode: 'US VAN',
    country: 'United States of America',
  },
  {
    portName: 'VANINO, RUSSIAN FEDERATION',
    portCode: 'RU VNN',
    country: 'Russian Federation',
  },
  {
    portName: 'VENTURA, CA',
    portCode: 'US NVT',
    country: 'United States of America',
  },
  {
    portName: 'VICTORIA, CANADA',
    portCode: 'CA VIC',
    country: 'Canada',
  },
  {
    portName: 'VLADIVOSTOK, RUSSIAN FEDERATION',
    portCode: 'RU VVO',
    country: 'Russian Federation',
  },
  {
    portName: 'VOSTOCHNYY, RUSSIAN FEDERATION',
    portCode: 'RU VYP',
    country: 'Russian Federation',
  },
  {
    portName: 'MINOR OUTLYING ISLANDS',
    portCode: 'UM AWK',
    country: 'United States Minor Outlying Islands',
  },
  {
    portName: 'WELLINGTON, NEW ZEALAND',
    portCode: 'NZ WLG',
    country: 'New Zealand',
  },
  {
    portName: 'WHITEGATE, IRISH REPUBLIC',
    portCode: 'IE WHI',
    country: 'Ireland',
  },
  {
    portName: 'WILHELMSHAVEN, GERMANY',
    portCode: 'DE  WVN',
    country: 'Germany',
  },
  {
    portName: 'WILLAPA HARBOR, WA',
    portCode: 'US WIH',
    country: 'United States of America',
  },
  {
    portName: 'WILLIAMSTON, NC',
    portCode: 'US WQX',
    country: 'United States of America',
  },
  {
    portName: 'WILMINGTON, CA',
    portCode: 'US WTN',
    country: 'United States of America',
  },
  {
    portName: 'WILMINGTON, DE',
    portCode: 'US ILG',
    country: 'United States of America',
  },
  {
    portName: 'WILMINGTON, NC',
    portCode: 'US ILM',
    country: 'United States of America',
  },
  {
    portName: 'WOODFIBRE, CANADA',
    portCode: 'CA WOO',
    country: 'Canada',
  },
  {
    portName: 'XIAMEN, CHINA',
    portCode: 'CN XMN',
    country: "People's Republic of China",
  },
  {
    portName: 'XINGANG, CHINA',
    portCode: 'CN XGG',
    country: "People's Republic of China",
  },
  {
    portName: 'XINSHA, CHINA',
    portCode: 'CN XNA',
    country: "People's Republic of China",
  },
  {
    portName: 'YANGSHAN, CHINA',
    portCode: 'CN YAN',
    country: "People's Republic of China",
  },
  {
    portName: 'YANGZHOU, CHINA',
    portCode: 'CN YZH',
    country: "People's Republic of China",
  },
  {
    portName: 'YANTAI, CHINA',
    portCode: 'CN YNT',
    country: "People's Republic of China",
  },
  {
    portName: 'YANTIAN, CHINA',
    portCode: 'CN YTN',
    country: "People's Republic of China",
  },
  {
    portName: 'YAP, FEDERATED STATES OF MICRONESIA',
    portCode: 'FM YAP',
    country: 'Micronesia, Federated States of',
  },
  {
    portName: 'YATSUSHIRO, JAPAN',
    portCode: 'JP YAT',
    country: 'Japan',
  },
  {
    portName: 'YAWATA, JAPAN',
    portCode: 'JP YWT',
    country: 'Japan',
  },
  {
    portName: 'YAWATAHAMA, JAPAN',
    portCode: 'JP YWH',
    country: 'Japan',
  },
  {
    portName: 'YEOSU, SOUTH KOREA',
    portCode: 'KR YOS',
    country: 'Republic of Korea',
  },
  {
    portName: 'YOKKAICHI, JAPAN',
    portCode: 'JP YKK',
    country: 'Japan',
  },
  {
    portName: 'YOKOHAMA, JAPAN',
    portCode: 'JP YOK',
    country: 'Japan',
  },
  {
    portName: 'YOKOSUKA, JAPAN',
    portCode: 'JP YOS',
    country: 'Japan',
  },
  {
    portName: 'ZAMBOANGA, PHILIPPINES',
    portCode: 'PH ZAM',
    country: 'Philippines',
  },
  {
    portName: 'ZHANGJIAGANG, CHINA',
    portCode: 'CN ZJG',
    country: "People's Republic of China",
  },
  {
    portName: 'ZHANJIANG, CHINA',
    portCode: 'CN ZNG',
    country: "People's Republic of China",
  },
  {
    portName: 'ZHENJIANG, CHINA',
    portCode: 'CN ZHE',
    country: "People's Republic of China",
  },
  {
    portName: 'ZHOUSHAN, CHINA',
    portCode: 'CN ZOS',
    country: "People's Republic of China",
  },
  {
    portName: 'ZHUHAI, CHINA',
    portCode: 'CN ZUH',
    country: "People's Republic of China",
  },
  {
    portName: 'ZLITEN, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY ZLI',
    country: 'Libyan Arab Jamahiriya',
  },
  {
    portName: 'ZUARA, LIBYAN ARAB JAMAHIRIYA',
    portCode: 'LY ZUA',
    country: 'Libyan Arab Jamahiriya',
  },
];
