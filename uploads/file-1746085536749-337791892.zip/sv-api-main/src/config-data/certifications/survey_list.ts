export const SurveyList = [
  'Annual Survey',
  'Dry DOcking Survey',
  'Intermediate Hull Survey',
];
